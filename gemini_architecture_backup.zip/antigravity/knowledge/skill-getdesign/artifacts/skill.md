---
name: getdesign
description: "Premium design specifications and tokens from world-class brands like Linear, Stripe, Apple, and Vercel. Includes exact hex codes, border-radii, spacing systems, and typography in Design MD format. Use to build 'wow' factor interfaces and high-end landing pages. CLI: npx getdesign@latest add <brand>."
---

# Premium Design Specs (GetDesign)

This skill provides access to the design "source code" of the world's most beautiful applications. It allows the agent to move beyond generic designs and implement interfaces that feel premium, polished, and state-of-the-art.

## Core Brands & Systems

| Brand | Vibe | Best For |
|-------|------|----------|
| **Linear** | Dark, sleek, high-precision | Developer tools, Dashboards, SaaS |
| **Stripe** | Sophisticated gradients, clean typography | Fintech, landing pages, marketing sites |
| **Apple** | Minimal, white-space heavy, premium | Consumer apps, luxury sites, landing pages |
| **Vercel** | Sharp, geometric, monochrome | Tech portfolios, documentation, modern web apps |
| **Raycast** | Command-line elegant, glassmorphism | Utilitarian tools, focus-oriented apps |
| **GitHub** | Accessible, functional, familiar | Collaborative tools, community platforms |

## Implementation Toolkit

### 1. CLI Usage
You can add a brand's design tokens directly to the current project:
```bash
npx getdesign@latest add <brand>
```
*Example: `npx getdesign@latest add linear`*

### 2. Design MD Format
The specifications follow the Google Stitch / Design MD standard. When reading a `DESIGN.md` file, look for:
- **Colors**: Primary, secondary, surface, and background tokens.
- **Typography**: Font family choices, weight scales, and line-heights.
- **Shadows**: Multi-layered shadow tokens for "premium" depth.
- **Spacing**: 4px or 8px based grids.

## When to Use This Skill

### MUST USE
- When the USER requests a **"premium," "stunning," or "wow"** design.
- When building **landing pages** or **marketing sites** that need to convert.
- When creating **dashboards** that need to feel high-end and professional.

### RECOMMENDED
- When the current UI feels "basic" or "bootstrap-y."
- When you need a cohesive color palette but don't want to guess.
- When implementing **Dark Mode** (use Linear or Raycast specs for reference).

## Strategy for "Wow" Factor

1.  **Select a Muse**: Ask the user (or decide based on the brand) which Muse to follow: "Should we go for the sleek precision of Linear or the clean minimalism of Apple?"
2.  **Pull Tokens**: Use the CLI or browse the `awesome-design-md` repo for the specific `DESIGN.md`.
3.  **Apply Hierarchically**: 
    - Apply background and surface colors first.
    - Implement the typography scale.
    - Add the "premium touches": multi-stop gradients and layered shadows (Stripe style).
    - Use the grid system for spacing.

## Anti-Patterns to Avoid
- **Generic Colors**: Avoid `bg-gray-100` or `#ffffff`. Use the specific off-white or deep-slate tones from the specs.
- **Flat Shadows**: Premium designs use 3-4 layers of shadows. Use the `shadow` tokens from the spec.
- **Standard Radius**: Don't just use `rounded-md`. Follow the spec's specific radius (e.g., Linear's 8px vs Apple's 12px+).
- **Default Fonts**: Always match the typography personality of the brand.

---
*Reference: https://github.com/VoltAgent/awesome-design-md*
