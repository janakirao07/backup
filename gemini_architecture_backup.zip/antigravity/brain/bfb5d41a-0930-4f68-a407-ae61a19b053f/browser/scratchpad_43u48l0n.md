# Login Debugging Plan
- [x] Navigate to https://bsrshoppingmall.vercel.app/admin/login
- [x] Enter credentials (admin@bsrshoppingmall.com / @bsr_admin!2026)
- [ ] Click "Sign In to Console"
- [ ] Observe errors or redirects
- [ ] Report findings

## Findings
- Supabase 400 error observed in console.
- Password field shows red border after attempt.
- No visible error text on page yet.
