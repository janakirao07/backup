# Flutter Best Practices

## Project Setup
```bash
flutter create --org com.example myapp
cd myapp && flutter run
```

## Widget Structure
```dart
import 'package:flutter/material.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Home')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Hello Flutter', style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const DetailScreen())),
              child: const Text('Go to Details'),
            ),
          ],
        ),
      ),
    );
  }
}
```

## State Management (Riverpod)
```dart
// pubspec.yaml: flutter_riverpod: ^2.4.0

import 'package:flutter_riverpod/flutter_riverpod.dart';

// Simple state
final counterProvider = StateProvider<int>((ref) => 0);

// Async data
final usersProvider = FutureProvider<List<User>>((ref) async {
  final response = await http.get(Uri.parse('https://api.example.com/users'));
  return (jsonDecode(response.body) as List).map((e) => User.fromJson(e)).toList();
});

// In widget
class CounterWidget extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final count = ref.watch(counterProvider);
    return Text('Count: $count');
  }
}
```

## Performant Lists
```dart
ListView.builder(
  itemCount: items.length,
  itemBuilder: (context, index) {
    return ListTile(
      title: Text(items[index].name),
      subtitle: Text(items[index].description),
    );
  },
)

// For grid layouts
GridView.builder(
  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
    crossAxisCount: 2,
    childAspectRatio: 0.75,
  ),
  itemCount: items.length,
  itemBuilder: (context, index) => ItemCard(item: items[index]),
)
```

## Navigation (GoRouter)
```dart
final router = GoRouter(
  routes: [
    GoRoute(path: '/', builder: (_, __) => const HomeScreen()),
    GoRoute(path: '/details/:id', builder: (_, state) =>
      DetailScreen(id: state.pathParameters['id']!)),
  ],
);

// Use: context.go('/details/123');
```

## Key Rules
- **const constructors**: Use `const` wherever possible for compile-time constants
- **Keys**: Provide keys for list items and stateful widgets in lists
- **Avoid rebuilds**: Extract widgets into separate classes, don't use functions
- **Image caching**: Use `cached_network_image` package
- **Responsive**: Use `LayoutBuilder` and `MediaQuery` for responsive layouts
- **Platform checks**: `Platform.isIOS`, `Platform.isAndroid` for platform-specific code
- **Folder structure**: `lib/models/`, `lib/screens/`, `lib/widgets/`, `lib/services/`, `lib/providers/`
