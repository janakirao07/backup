# Mobile Performance Audit: sk-degree-college-page.vercel.app

## Goals
1. [ ] Analyze PageSpeed Insights report for mobile.
2. [ ] Identify top 3 Opportunities & Diagnostics.
3. [ ] Investigate LCP, TBT, and CLS.
4. [ ] Provide detailed breakdown of fixes.

## Findings
- **LCP:** 
- **TBT:** 
- **CLS:** 

## Top 3 Opportunities
1. 
2. 
3. 

## Top 3 Diagnostics
1. 
2. 
3. 
