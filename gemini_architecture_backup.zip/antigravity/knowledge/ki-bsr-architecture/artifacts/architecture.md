# BSR Shopping Mall Architecture Map

## 1. Stack
- **Framework:** Next.js 15 (App Router)
- **Database/Auth:** Supabase
- **Styling:** Tailwind CSS + UI/UX Pro Max standards (44px touch targets)
- **Localization:** `next-intl`
- **Caching:** Next.js `unstable_cache`

## 2. Directory Structure
```
src/
├── app/
│   ├── [locale]/
│   │   ├── (storefront)/    # Public-facing shop UI
│   │   ├── admin/           # Secured admin dashboard
│   │   └── api/             # API routes (e.g. bulk-inquiry)
├── components/              # Shared UI components
├── lib/
│   ├── supabase/            # Centralized client creation
│   └── products.ts          # Cached data fetching
```

## 3. Database Schema (Key Tables)
- **`products`**: Items for sale. Read access is public.
- **`orders`**: Customer purchases. RLS: Customers can `SELECT` their own orders. Admin has `ALL` access.
- **`bulk_inquiries`**: B2B inquiries. RLS: Public `INSERT`, Admin `SELECT`.

## 4. Key Implementation Patterns

### Centralized Supabase Client
Always use the centralized singleton from `src/lib/supabase` instead of creating new instances.
```typescript
import { createClient } from '@/lib/supabase/client'; // Browser
import { createClient } from '@/lib/supabase/server'; // Server
```

### Data Fetching (unstable_cache)
Use `unstable_cache` for catalog data to prevent DB waterfalls.
```typescript
import { unstable_cache } from 'next/cache';

export const getProducts = unstable_cache(
  async () => {
    // ... DB fetch
  },
  ['products-list'],
  { revalidate: 3600 } // 1 hour cache
);
```

### Bot Protection
The `api/bulk-inquiry` route uses a honeypot field named `website`. If it is filled, silently reject the submission.
