# Kaggle Workflows

## GPU & Environment Setup
```python
# Check GPU availability
import torch
print(f"GPU: {torch.cuda.get_device_name(0)}" if torch.cuda.is_available() else "CPU only")
print(f"VRAM: {torch.cuda.get_device_properties(0).total_mem / 1e9:.1f} GB")

# Kaggle provides: P100 (16GB) or T4 (16GB), 30hrs/week GPU quota
# Tip: use GPU P100 for training, T4 for inference
```

## Kaggle API (Local Machine)
```bash
# Install
pip install kaggle

# Setup: place kaggle.json in ~/.kaggle/
# Download from kaggle.com > Account > API > Create New Token

# Download dataset
kaggle datasets download -d username/dataset-name

# Download competition data
kaggle competitions download -c competition-name

# Submit predictions
kaggle competitions submit -c competition-name -f submission.csv -m "description"

# Check leaderboard position
kaggle competitions leaderboard -c competition-name --show
```

## Notebook Structure Template
```python
# ═══ 1. Configuration ═══
class CFG:
    seed = 42
    epochs = 30
    batch_size = 64
    lr = 1e-3
    model_name = "resnet50"
    img_size = 224
    fold = 0
    n_folds = 5
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ═══ 2. Seed Everything ═══
def seed_everything(seed):
    import random, os, numpy as np
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.deterministic = True

seed_everything(CFG.seed)

# ═══ 3. Data Loading ═══
# ═══ 4. Model Definition ═══
# ═══ 5. Training Loop ═══
# ═══ 6. Inference & Submission ═══
```

## Efficient Data Handling
```python
import pandas as pd

# Read large datasets efficiently
df = pd.read_csv("/kaggle/input/dataset/train.csv",
    dtype={'id': 'int32', 'target': 'int8'},  # reduce memory
    usecols=['id', 'feature1', 'feature2', 'target']  # only needed columns
)

# Monitor memory
print(f"Memory: {df.memory_usage(deep=True).sum() / 1e6:.1f} MB")
```

## Cross-Validation Strategy
```python
from sklearn.model_selection import StratifiedKFold

skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

oof_predictions = np.zeros(len(train_df))  # out-of-fold predictions

for fold, (train_idx, val_idx) in enumerate(skf.split(train_df, train_df['target'])):
    print(f"\n{'='*30} Fold {fold+1} {'='*30}")
    X_train, X_val = train_df.iloc[train_idx], train_df.iloc[val_idx]

    # Train model...
    # Store OOF predictions
    oof_predictions[val_idx] = model.predict(X_val)

# Final CV score
cv_score = metric(train_df['target'], oof_predictions)
print(f"CV Score: {cv_score:.5f}")
```

## Submission Pipeline
```python
# Generate submission
test_predictions = []
for fold in range(CFG.n_folds):
    model.load_state_dict(torch.load(f"model_fold{fold}.pth"))
    preds = predict(model, test_loader)
    test_predictions.append(preds)

# Average across folds
final_predictions = np.mean(test_predictions, axis=0)

submission = pd.DataFrame({'id': test_df['id'], 'target': final_predictions})
submission.to_csv("submission.csv", index=False)
```

## Ensembling Strategies
```python
# 1. Simple average (most common)
final = (pred_model1 + pred_model2 + pred_model3) / 3

# 2. Weighted average (tune weights on CV)
final = 0.5 * pred_best_model + 0.3 * pred_second + 0.2 * pred_third

# 3. Rank averaging (robust to different scales)
from scipy.stats import rankdata
rank1 = rankdata(pred1) / len(pred1)
rank2 = rankdata(pred2) / len(pred2)
final = (rank1 + rank2) / 2
```

## GPU Memory Tips
- Use `torch.cuda.empty_cache()` between folds
- Reduce batch size if OOM; use gradient accumulation instead
- Use mixed precision (AMP) to halve memory usage
- Delete unused variables: `del model, optimizer; gc.collect()`
- Monitor: `torch.cuda.max_memory_allocated() / 1e9` GB

## Winning Patterns
- Always start with a strong baseline before complex models
- Focus on feature engineering for tabular data
- Use pretrained models for vision/NLP
- Ensemble diverse models (different architectures, different seeds)
- Post-processing: threshold tuning, TTA (Test Time Augmentation)
