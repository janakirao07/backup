# CMS Patterns (Sanity)

## Fetching
```ts
import { createClient } from 'next-sanity';
const client = createClient({ projectId: 'xxx', dataset: 'production', useCdn: true });
const posts = await client.fetch(`*[_type == "post"]`);
```

## Rendering Portable Text
```tsx
import { PortableText } from '@portabletext/react';
<PortableText value={post.body} components={customComponents} />
```