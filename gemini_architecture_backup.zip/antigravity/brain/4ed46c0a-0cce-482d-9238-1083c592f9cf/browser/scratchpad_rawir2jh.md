# Audit Task Checklist
- [x] Navigate to http://localhost:3000
- [ ] Run Lighthouse audit (Performance, Accessibility, Best Practices, SEO)
- [x] Check console for errors
- [x] Verify 'Notices' section visibility
- [x] Verify 'Future Starts Now' section visibility
- [ ] Provide summary of findings

## Findings
- **Console Errors/Warnings**:
  - `metadataBase` property not set (SEO/Social).
  - Supabase credentials missing (Admin module in mock mode).
  - Image `/images/logo.jpeg` missing `sizes` prop (Performance).
  - No critical JS errors or 404s found.
- **Section Visibility**:
  - 'Notice Board' is visible and populated with cards (Annual Sports Meet, Admissions Open, Semester Schedule).
  - 'Your Future Starts Now' (Admissions Open 2026-27) is visible with an 'Apply Online Now' button.

## Manual Audit Plan (Since no direct Lighthouse tool is available)
- **Accessibility**: Check `alt` attributes and ARIA labels via DOM.
- **SEO**: Verify `title`, `meta description`, `h1`, and head tags.
- **Performance**: Analyze network request count and types.
- **Best Practices**: Already identified several issues in console.
