# Mobile Banner Inspection Findings

## Observed Issues on Mobile (iPhone 12 Pro Viewport):

1.  **Severe Image Cropping**: The background images in the Hero Banner are extremely zoomed in. On desktop, they are wide and well-composed, but on mobile, they seem to use `object-fit: cover` on a container that is too tall/narrow, resulting in only the center (often just a blurry wall or a tiny piece of fabric) being visible.
2.  **Unprofessional Typography**: Some banner titles like "new offer" and "kanchipuram pattu saree" are in lowercase, which lacks the "Premium" feel the site aims for.
3.  **Glassmorphism Card Size**: The text container card is quite large on mobile, covering a significant portion of the viewport and obstructing the visual content.
4.  **Lack of Visual Context**: Because of the cropping, the banners lose their "lifestyle" appeal. The user cannot see the full saree or the model's pose, which are key for an ethnic wear store.
5.  **Text Alignment**: While the user recently added `text_position` support, on mobile, the text seems to default to a centered card which might not be the best use of space if the subject of the image is also centered.

## Comparison:
- **Desktop**: Images are wide, text is neatly tucked into a corner or side, and the composition is balanced.
- **Mobile**: Images are vertical/zoomed, text card is huge and centered, composition is lost.
