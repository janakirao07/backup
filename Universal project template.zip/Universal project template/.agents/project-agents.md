# Workspace Agents Mappings

This project utilizes specific roles mapping to global and local workspace skill definitions.

> **Setup**: Replace `[PROJECT_TYPE]` placeholders below with your actual project context (e.g., "e-commerce site", "SaaS dashboard", "portfolio website").

---

## 🎭 Agent Profiles

### 1. UI/UX Designer
* **Skills**: `design-taste-frontend`, `ui-ux-web`, `frontend-design`, `high-end-visual-design`, `ui-ux-pro-max`, `brandkit`, `minimalist-ui`, `web-design-guidelines`, `framer-motion`, `stitch-design-taste`
* **Responsibilities**: Define the grid system, spacing scales, font loader implementations, contrast ratios for theme layers, and scroll/interaction animation patterns for [PROJECT_TYPE].

### 2. Frontend Developer
* **Skills**: `ui-ux-web`, `shadcn`, `vercel-react-best-practices`, `full-output-enforcement`, `gpt-taste`, `design-taste-frontend`, `coding-standards`, `debug-optimize-lcp`, `framer-motion`, `nextjs-best-practices`
* **Responsibilities**: Build the application UI, implement modular CSS/design tokens, manage routing logic, optimize LCP and Core Web Vitals, and enforce code quality standards for [PROJECT_TYPE].

### 3. QA / Accessibility Engineer
* **Skills**: `ui-ux-web`, `ui-ux-pro-max`, `web-design-guidelines`, `a11y-debugging`, `seo-audit`, `accessibility`, `performance`, `systematic-debugging`
* **Responsibilities**: Conduct WCAG 2.2 compliance audits, run console error diagnostics, debug accessibility issues, audit SEO metadata, and verify cross-browser compatibility for [PROJECT_TYPE].

### 4. Content & Copy
* **Skills**: `copywriting`, `seo-fundamentals`
* **Responsibilities**: Write clear product/service descriptions, page copy, CTA button labels, meta descriptions, and microcopy for [PROJECT_TYPE].

### 5. Backend / API Developer
* **Skills**: `api-design`, `supabase`, `supabase-postgres-best-practices`, `backend-patterns`, `security-review`, `coding-standards`
* **Responsibilities**: Design API endpoints, manage database schema and migrations, implement authentication flows, enforce RLS policies, and handle server-side logic for [PROJECT_TYPE].

### 6. DevOps / Deployment
* **Skills**: `deploy-check`, `deploy-to-vercel`, `vercel-cli-with-tokens`, `cloudflare`, `performance`, `security-auditor`
* **Responsibilities**: Configure CI/CD pipelines, manage environment variables, run pre-deployment checks, optimize build output, and monitor production health for [PROJECT_TYPE].
