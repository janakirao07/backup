---
name: babylonjs-best-practices
description: Babylon.js game and rendering engine. Use when building 3D games, VR/AR experiences, complex simulations, or when you need physics, GUI, and audio in a 3D web app.
---

# Babylon.js Best Practices

## Installation
```bash
npm install @babylonjs/core @babylonjs/loaders @babylonjs/gui
# Optional:
npm install @babylonjs/materials @babylonjs/inspector
```

## Basic Scene
```typescript
import { Engine, Scene, ArcRotateCamera, HemisphericLight, MeshBuilder, Vector3 } from '@babylonjs/core';

const canvas = document.getElementById('renderCanvas') as HTMLCanvasElement;
const engine = new Engine(canvas, true, { preserveDrawingBuffer: true, stencil: true });

const scene = new Scene(engine);
const camera = new ArcRotateCamera('cam', Math.PI / 4, Math.PI / 3, 10, Vector3.Zero(), scene);
camera.attachControl(canvas, true);

new HemisphericLight('light', new Vector3(0, 1, 0), scene);

const sphere = MeshBuilder.CreateSphere('sphere', { diameter: 2, segments: 32 }, scene);

engine.runRenderLoop(() => scene.render());
window.addEventListener('resize', () => engine.resize());
```

## React Integration
```tsx
import { Engine, Scene } from 'react-babylonjs';
import { Vector3 } from '@babylonjs/core';

function Game() {
  return (
    <Engine antialias canvasId="babylon-canvas">
      <Scene>
        <arcRotateCamera name="cam" alpha={Math.PI / 4} beta={Math.PI / 3}
          radius={10} target={Vector3.Zero()} />
        <hemisphericLight name="light" direction={new Vector3(0, 1, 0)} intensity={0.7} />
        <sphere name="sphere" diameter={2} segments={32}>
          <standardMaterial name="mat" diffuseColor={new Color3(0.4, 0.4, 1)} />
        </sphere>
        <ground name="ground" width={10} height={10} />
      </Scene>
    </Engine>
  );
}
```

## Babylon.js vs Three.js
| Feature | Three.js | Babylon.js |
|---------|----------|------------|
| Bundle size | ~150KB | ~400KB+ |
| Learning curve | Medium | Medium-High |
| Physics engine | External (Rapier/Cannon) | Built-in (Havok/Ammo) |
| GUI system | None (use HTML/CSS) | Built-in (AdvancedDynamicTexture) |
| Audio engine | Basic | Full spatial audio |
| Inspector/Debug | Basic | Full inspector tool |
| VR/AR support | Via WebXR | First-class WebXR |
| Community | Larger | Smaller but backed by Microsoft |
| Best for | Creative/artistic 3D | Games and simulations |

## When to Choose Babylon.js over Three.js
- ✅ Building a full 3D game with physics
- ✅ Need built-in GUI overlays on 3D scenes
- ✅ VR/AR application
- ✅ Need spatial audio
- ✅ Want a full inspector/debugger
- ❌ Simple 3D decorations on websites (use Three.js)
- ❌ Need smallest possible bundle (use Three.js)

## Key Features
- **Physics**: Havok plugin (production-grade)
- **GUI**: Full 2D UI system rendered on 3D textures
- **Particles**: GPU-powered particle systems
- **Animations**: Bone/skeletal animation system
- **Materials**: PBR, Node Material Editor (visual shader editor)
- **Inspector**: Press F12 in dev mode for full scene debugging
