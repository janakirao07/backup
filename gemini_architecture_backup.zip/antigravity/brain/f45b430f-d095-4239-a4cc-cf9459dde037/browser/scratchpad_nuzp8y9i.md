# Debugging Admin Page Load Error

## Task Checklist
- [x] Navigate to https://sk-degree-college.vercel.app/admin
- [x] Observe the page behavior (redirects, error messages)
- [x] Check console logs for errors
- [x] Check network requests for failed loads (Attempted, tool failed but observed 500-like behavior)
- [ ] Report findings

## Observations
- Navigated to `/admin`, `/admin/login`, and `/admin/dashboard`. All show "This page couldn't load".
- Home page (`/`) works correctly.
- Console logs show: "Supabase credentials missing. Admin module will be in mock mode."
- The error page is a generic Next.js/Vercel error, suggesting a server-side crash or a fatal client-side error during hydration.
- Since all `/admin` routes are failing, the issue is likely in a shared component or `app/admin/layout.tsx`.
- The `_rsc` requests (Next.js server component data) for unrelated pages like `/library` are 404ing, but the main issue is the crash on the admin routes.
