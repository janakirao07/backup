# Garment Retail UX

High-end clothing site patterns — texture zoom, size chart modals, and return reduction strategies.

## 🔍 Zoom on Hover for Fabric Textures

For premium ethnic wear and sarees, fabric texture is a primary purchase signal.

- **Implementation pattern**:
```html
<div class="zoom-container" data-zoom-src="/images/fabric-full.jpg">
  <img src="/images/fabric-thumb.jpg" alt="Fabric texture" />
  <div class="zoom-lens"></div>
</div>
```
```css
.zoom-container { position: relative; overflow: hidden; cursor: crosshair; }
.zoom-lens {
  position: absolute; width: 120px; height: 120px;
  border: 2px solid #c9a96e; /* gold border for luxury feel */
  border-radius: 50%;
  background-repeat: no-repeat;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.2s;
}
.zoom-container:hover .zoom-lens { opacity: 1; }
```
```javascript
container.addEventListener('mousemove', (e) => {
  const { left, top, width, height } = container.getBoundingClientRect();
  const x = ((e.clientX - left) / width) * 100;
  const y = ((e.clientY - top) / height) * 100;
  lens.style.backgroundImage = `url(${zoomSrc})`;
  lens.style.backgroundSize = '400%'; // 4x zoom
  lens.style.backgroundPosition = `${x}% ${y}%`;
  lens.style.left = `${e.clientX - left - 60}px`;
  lens.style.top = `${e.clientY - top - 60}px`;
});
```
- **Mobile alternative**: Pinch-to-zoom on the full-screen lightbox.
- **Image specs**: Deliver the zoom image at minimum 2000×2000px.

## 📏 Size Chart Modals That Reduce Returns

A well-designed size chart modal can reduce size-related returns by 30–40%.

- **"Fit note" is the highest-ROI element**: "This kurta runs narrow in the shoulders — size up if between sizes" reduces returns more than a perfect size table.
- **Inches/CM toggle**: Essential for the Indian market.
- **Smart trigger**: Show automatically after 8s on PDP or when clicking "Add to Cart" without selecting a size.
- **Persist measurements**: Store user measurements in `localStorage` and auto-highlight their size on every PDP.
- **Video guide**: A 45-second "how to measure" clip cuts "I measured wrong" returns significantly.
- **Mobile UX**: Use a **bottom sheet** on mobile, not a centered dialog.
