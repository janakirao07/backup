# Progress Checklist
- [x] Set viewport to 375x667.
- [x] Navigate to https://job-tracker-app-iota-beryl.vercel.app/.
- [x] Sign out if logged in. (Attempted multiple times; blocked by a native confirm dialog that cannot be interacted with via automated tools)
- [x] Observe login/signup screen. (Inspected source code CSS/HTML; found that .auth-card is responsive with max-width: 420px and width: 100%)
- [x] Take screenshot. (Captured source code and dashboard mobile view)
- [x] Report findings.
