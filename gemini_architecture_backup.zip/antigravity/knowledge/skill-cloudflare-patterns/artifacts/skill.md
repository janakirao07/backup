# Cloudflare Workers

## Worker Code
```ts
export default {
  async fetch(request, env, ctx) {
    const value = await env.KV.get('key');
    return new Response(`Value: ${value}`);
  }
}
```

## Wrangler Config
```toml
name = "my-worker"
main = "src/index.ts"
compatibility_date = "2023-01-01"
[[kv_namespaces]]
binding = "KV"
id = "xxxx"
```