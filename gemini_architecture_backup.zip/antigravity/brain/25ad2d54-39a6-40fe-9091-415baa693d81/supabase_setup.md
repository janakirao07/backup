# Supabase Admin Role Configuration

Follow these steps in your Supabase Dashboard to set up the `profiles` table and secure your application with Row Level Security (RLS).

## 1. Create the Profiles Table
Run this in your **Supabase SQL Editor**:

```sql
-- Create a table for public profiles
create table profiles (
  id uuid references auth.users on delete cascade not null primary key,
  email text unique not null,
  role text not null default 'customer' check (role in ('admin', 'customer')),
  created_at timestamp with time zone default timezone('utc'::text, now()) not null,
  updated_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Set up Row Level Security (RLS)
alter table profiles enable row level security;

-- Create profiles for existing users (Optional)
-- This trigger will automatically create a profile record when a new user signs up
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, role)
  values (new.id, new.email, 'customer');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
```

## 2. Make Yourself an Admin
To grant admin access to a specific user, run this SQL (replace with your email):

```sql
UPDATE profiles 
SET role = 'admin' 
WHERE email = 'your-email@example.com';
```

## 3. Update RLS Policies for Other Tables
To ensure only admins can modify products, banners, and categories, update your RLS policies:

### Products Table
```sql
-- Allow everyone to view products
create policy "Public can view products"
on products for select
using (true);

-- Only admins can insert/update/delete
create policy "Admins can manage products"
on products for all
using (
  exists (
    select 1 from profiles
    where profiles.id = auth.uid()
    and profiles.role = 'admin'
  )
);
```

### Hero Banners Table
```sql
-- Allow everyone to view banners
create policy "Public can view banners"
on hero_banners for select
using (true);

-- Only admins can manage
create policy "Admins can manage banners"
on hero_banners for all
using (
  exists (
    select 1 from profiles
    where profiles.id = auth.uid()
    and profiles.role = 'admin'
  )
);
```

## 4. Why this is secure?
- **No Signup for Admin**: The admin console (`/admin/login`) only allows signing in. New admins can only be created by an existing admin updating the database or by you manually in the Supabase dashboard.
- **Server-side Validation**: Even if someone bypasses the UI, Supabase RLS policies will reject any database changes if the user doesn't have the `admin` role in the `profiles` table.
- **No Hardcoded Emails**: Your code no longer contains sensitive email addresses. Access is controlled entirely by the database.
