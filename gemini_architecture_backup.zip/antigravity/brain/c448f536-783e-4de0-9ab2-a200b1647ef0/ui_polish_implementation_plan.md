# UI/UX Polish & Visual Density Optimization Plan

This document outlines the systematic visual polish and layout density optimization plan for the Admin and Employee portals of the Primetek Global Solutions application.

---

## 1. Design System & Style Guide Standardization

The current dashboard interface suffers from "bubble aesthetics": oversized rounding (`rounded-[2.5rem]`), massive padding (`p-12`), giant font weights (`font-black`), and oversized buttons (`py-6`). We will align the interface with modern SaaS dashboard standards (e.g., Stripe, Vercel, Linear).

### Style Mappings

| Design Element | Current Style | Target SaaS Style | Rationale |
| :--- | :--- | :--- | :--- |
| **Card Border Radius** | `rounded-[2rem]` / `rounded-[2.5rem]` | `rounded-xl` (12px) / `rounded-2xl` (16px) | Gives a much cleaner, precise, modern, and structured visual boundary. |
| **Font Weight (Headings)** | `font-black` (900) | `font-bold` (700) / `font-semibold` (600) | Softens harsh dark typography, creating a professional editorial hierarchy. |
| **Stats Values** | `text-4xl font-black` | `text-2xl font-semibold` / `text-3xl font-bold` | Reduces oversized numbers to fit standard visual scaling. |
| **Section Spacing** | `space-y-8` / `gap-8` | `space-y-6` / `gap-4 md:gap-5` | Increases screen real estate and makes grids feel cohesive. |
| **Button Heights** | Custom padding `py-6` / `py-5` | Standard height props (`32px` to `40px`) | Standardizes touch targets and matches interactive elements with forms. |
| **Layout Width** | `max-w-5xl` | `max-w-7xl` (1280px) | Gives wide tables and grid columns more horizontal breathing room. |

---

## 2. Component Primitives Polish

### A. Shared Components (`src/components/ui/`)
- **`Card.tsx`**: Update hover effects from bouncing transitions (`hover:-translate-y-1 hover:shadow-xl`) to a subtle border glow and drop shadow.
- **`Button.tsx`**: Standardize button sizes:
  - `sm`: Height `32px`, font-size `text-xs`.
  - `md` (default): Height `40px`, font-size `text-sm`.
  - `lg`: Height `46px`, font-size `text-sm`.
  - Outline: Reduce border thickness from `border-2` to `border` with a subtle neutral-slate stroke.

### B. Global Layouts
- **`src/app/admin/layout.tsx`** & **`src/app/employee/layout.tsx`**: Replace container constraints `max-w-5xl` with `max-w-7xl` to prevent tables from being squished on desktop monitors.

---

## 3. Portal Pages Polish

### A. Admin Dashboard (`src/app/admin/dashboard/page.tsx`)
- Reduce stat card rounding from `rounded-[2rem]` to `rounded-xl`.
- Normalise numbers from `text-3xl font-black` to `text-2xl font-bold`.
- Reduce performance chart heading sizes to `text-base font-semibold`.
- Tighten the inquiries lists' cards and remove oversized sub-elements.

### B. Employee Dashboard (`src/app/employee/dashboard/page.tsx`)
- Standardize welcome card rounding and remove oversized gradient spheres.
- Replace custom hero buttons (`py-6 px-10`) with standard high-density button classes.
- Reduce stats cards rounding to `rounded-xl` and value scaling to `text-2xl font-bold`.
- Tighten attendance log items and shrink the date blocks from `w-16 h-16` to `w-12 h-12`.

---

## 4. Execution Roadmap

1. **Step 1: UI Primitives** (`Button.tsx`, `Card.tsx`).
2. **Step 2: Layout Width updates** (`layout.tsx` files).
3. **Step 3: Admin Dashboard components** (`admin/dashboard/page.tsx`).
4. **Step 4: Employee Dashboard components** (`employee/dashboard/page.tsx`).
5. **Step 5: Tabular views & Drawer spacing** (such as `InquiryTable.tsx` and employee assignments).
6. **Step 6: Validation** (run build checks and verify density).
