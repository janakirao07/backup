# Firebase Authentication — Task Tracker

- `[x]` Create `js/firebase-config.js` — Firebase project config
- `[x]` Create `js/auth.js` — Auth logic (sign up, sign in, Google OAuth, sign out, guard)
- `[x]` Create `login.html` — Glassmorphism login/register page
- `[x]` Modify `css/styles.css` — Login page + navbar user chip styles
- `[x]` Modify `index.html` — Auth guard + user info in navbar + script tags
- `[x]` Verified login page renders correctly in browser
- `[ ]` User: Set up Firebase project and paste config keys
