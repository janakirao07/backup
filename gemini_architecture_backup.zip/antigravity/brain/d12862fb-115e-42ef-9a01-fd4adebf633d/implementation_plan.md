# Implementation Plan: Robust Extension Communication Bridge

The current bridge uses `CustomEvent`, which can sometimes be blocked or restricted across Isolated Worlds in Chrome. Switching to `window.postMessage` is the standard and more reliable way to bridge the web page and the content script.

## Proposed Changes

### [Component: Extension Content Script]

#### [MODIFY] [content.js](file:///c:/Users/janak/job-tracker-app/src/scripts/content.js)
- Replace the `CustomEvent` listener with a `window` message listener (`message` event).
- Filter the messages by a unique `type` (e.g., `RJD_PROXY_REQUEST`).
- After receiving a response from `background.js`, send a message back to the page using `window.postMessage`.

### [Component: Dashboard Logic]

#### [MODIFY] [app.js](file:///c:/Users/janak/job-tracker-app/src/scripts/app.js)
- Update `callOllama` to use `window.postMessage` to send the request.
- Update the response handler to listen for `message` events from the window.
- Add logging to help the user confirm when the request is sent vs received.

## Verification Plan

### Automated/Manual Verification
- **Log Verification**: Ask the user to check the console for "AI Blaze: Sending proxy request..." and "AI Blaze: Received proxy response...".
- **Functional Check**: Verify the Ollama chat functions again from the Vercel dashboard.

## User Review Required

> [!IMPORTANT]
> After I apply these changes and deploy them, you **MUST** manually reload the AI Blaze extension in `chrome://extensions` and then refresh your Vercel dashboard. This is necessary because the extension's code on your disk must match the logic on the web page.
