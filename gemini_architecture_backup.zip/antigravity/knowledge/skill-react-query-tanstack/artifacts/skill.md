﻿# TanStack Query Patterns

## Setup
```tsx
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
const queryClient = new QueryClient({
  defaultOptions: { queries: { staleTime: 5 * 60 * 1000, retry: 2 } }
});
<QueryClientProvider client={queryClient}><App /></QueryClientProvider>
```

## Queries
```tsx
import { useQuery } from '@tanstack/react-query';

function JobList() {
  const { data, isLoading, error } = useQuery({
    queryKey: ['jobs'],
    queryFn: () => fetch('/api/jobs').then(r => r.json()),
  });
  if (isLoading) return <Spinner />;
  if (error) return <Error message={error.message} />;
  return data.map(job => <JobCard key={job.id} job={job} />);
}

// With parameters
const { data } = useQuery({
  queryKey: ['job', jobId],
  queryFn: () => fetchJob(jobId),
  enabled: !!jobId,  // only fetch when jobId exists
});
```

## Mutations
```tsx
import { useMutation, useQueryClient } from '@tanstack/react-query';

function AddJob() {
  const queryClient = useQueryClient();
  const mutation = useMutation({
    mutationFn: (newJob) => fetch('/api/jobs', { method: 'POST', body: JSON.stringify(newJob) }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['jobs'] }),
  });
  return <button onClick={() => mutation.mutate({ title: 'SDE' })} disabled={mutation.isPending}>Add</button>;
}
```

## Optimistic Updates
```tsx
const mutation = useMutation({
  mutationFn: updateJob,
  onMutate: async (updatedJob) => {
    await queryClient.cancelQueries({ queryKey: ['jobs'] });
    const previous = queryClient.getQueryData(['jobs']);
    queryClient.setQueryData(['jobs'], (old) => old.map(j => j.id === updatedJob.id ? updatedJob : j));
    return { previous };
  },
  onError: (err, vars, context) => queryClient.setQueryData(['jobs'], context.previous),
  onSettled: () => queryClient.invalidateQueries({ queryKey: ['jobs'] }),
});
```

## Infinite Scroll
```tsx
const { data, fetchNextPage, hasNextPage } = useInfiniteQuery({
  queryKey: ['jobs'],
  queryFn: ({ pageParam = 0 }) => fetchJobs({ offset: pageParam }),
  getNextPageParam: (lastPage) => lastPage.nextOffset,
});
```

## Key Rules
- queryKey must be serializable and unique
- staleTime = how long data is considered fresh
- gcTime (was cacheTime) = how long inactive data stays in cache
- Use invalidateQueries after mutations
- Use select option to transform/filter data
