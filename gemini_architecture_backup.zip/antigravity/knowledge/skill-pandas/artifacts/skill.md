# Pandas Best Practices

## Reading Data Efficiently
```python
import pandas as pd

# Optimize memory with dtypes
df = pd.read_csv('data.csv', dtype={
    'id': 'int32', 'category': 'category', 'price': 'float32'
}, parse_dates=['created_at'], usecols=['id', 'category', 'price', 'created_at'])

# Large files: read in chunks
chunks = pd.read_csv('huge.csv', chunksize=100_000)
result = pd.concat([chunk[chunk['status'] == 'active'] for chunk in chunks])

# Parquet (faster than CSV, smaller, typed)
df.to_parquet('data.parquet', index=False)
df = pd.read_parquet('data.parquet')
```

## Filtering & Selection
```python
# Boolean indexing
active = df[df['status'] == 'active']
recent = df[df['date'] >= '2026-01-01']
multi = df[(df['price'] > 100) & (df['category'] == 'tech')]

# .query() for readable complex filters
result = df.query('price > 100 and category == "tech" and status != "cancelled"')

# .loc (label-based) vs .iloc (position-based)
df.loc[df['name'] == 'John', 'salary'] = 75000  # update specific rows
first_10 = df.iloc[:10, :5]                       # first 10 rows, 5 cols
```

## GroupBy & Aggregation
```python
# Basic groupby
summary = df.groupby('category').agg(
    count=('id', 'count'),
    avg_price=('price', 'mean'),
    total_revenue=('price', 'sum'),
    max_price=('price', 'max')
).reset_index()

# Multiple groupby with named aggregation
monthly = df.groupby([df['date'].dt.to_period('M'), 'category']).agg(
    sales=('amount', 'sum'),
    orders=('id', 'nunique')
).reset_index()

# Transform (returns same shape — useful for adding group-level info)
df['category_avg'] = df.groupby('category')['price'].transform('mean')
df['pct_of_category'] = df['price'] / df.groupby('category')['price'].transform('sum')
```

## Merge & Join
```python
# Inner join (only matching rows)
merged = pd.merge(orders, customers, on='customer_id', how='inner')

# Left join (keep all orders)
merged = pd.merge(orders, customers, on='customer_id', how='left')

# Multiple keys
merged = pd.merge(df1, df2, on=['date', 'product_id'], how='left', suffixes=('_left', '_right'))
```

## Data Cleaning
```python
# Handle missing values
df['price'].fillna(df['price'].median(), inplace=True)
df.dropna(subset=['required_col'], inplace=True)

# Remove duplicates
df.drop_duplicates(subset=['email'], keep='last', inplace=True)

# String operations
df['name'] = df['name'].str.strip().str.title()
df['email'] = df['email'].str.lower()

# Type conversion
df['date'] = pd.to_datetime(df['date'], errors='coerce')
df['price'] = pd.to_numeric(df['price'], errors='coerce')
```

## Window Functions
```python
# Rolling average
df['rolling_7d'] = df.groupby('product')['sales'].transform(lambda x: x.rolling(7).mean())

# Rank within group
df['rank'] = df.groupby('category')['sales'].rank(ascending=False, method='dense')

# Cumulative sum
df['cumulative'] = df.groupby('category')['sales'].cumsum()

# Shift (lag/lead)
df['prev_day_sales'] = df.groupby('product')['sales'].shift(1)
```

## Performance Tips
- Use `category` dtype for low-cardinality string columns
- Use vectorized operations, avoid `.apply()` with row-wise functions
- Use `.values` or `.to_numpy()` for NumPy-level speed
- Prefer `pd.concat()` over repeated `df.append()`
- Use `inplace=True` sparingly — often slower, not faster
- Profile with `df.info(memory_usage='deep')`
