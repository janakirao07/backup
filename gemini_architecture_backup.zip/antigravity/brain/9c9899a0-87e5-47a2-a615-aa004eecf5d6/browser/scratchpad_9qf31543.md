# Browser Task Scratchpad - Resume Maker Testing

## Task Checklist
- [x] Open http://localhost:5500/pages/resume_maker.html
- [x] Enter 'Venkata Vinay Vamsi Yeddula' in the Name field
- [x] Reload page and verify name persists (FAILED - Name did not persist after reload)
- [x] Paste experience text into 'Tailored Content' box
- [x] Verify 'Experience' chip turns green (✓) (VERIFIED - [EXPERIENCE] ✓ appeared in label)
- [x] Click 'Download Resume .docx'
- [x] Verify '✓ Downloaded!' success message (VERIFIED - Button text changed to ✓ Downloaded!)
- [x] Report success

## Notes
- Tailored Content:
  [EXPERIENCE]
  Senior Data Analyst | Prudential Financial | 2023 - Present
  - Lead analysis of healthcare datasets.
- Name persistence fails after reload. I will try typing and clicking another field before reloading.
