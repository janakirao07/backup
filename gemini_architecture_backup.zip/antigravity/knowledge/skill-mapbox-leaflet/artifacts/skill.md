# Mapbox GL JS

## Setup (React)
```tsx
import Map, { Marker } from 'react-map-gl';

function App() {
  return (
    <Map mapboxAccessToken="TOKEN" initialViewState={{ longitude: -100, latitude: 40, zoom: 3 }} mapStyle="mapbox://styles/mapbox/streets-v9">
      <Marker longitude={-100} latitude={40} color="red" />
    </Map>
  );
}
```