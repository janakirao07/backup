# Interactive Local Deployment Script Plan

Since we've untracked the internal build and deployment tools, I will create a more robust, **interactive** local script. This script will handle everything from path synchronization to Git pushes, allowing you to provide custom commit messages each time.

## Proposed Changes

### 1. Script Creation [NEW]
I will create a new, enhanced PowerShell script for your local development.

#### [NEW] [local-deploy.ps1](file:///c:/Users/janak/job-tracker-app/local-deploy.ps1)
This script will perform the following steps:
1.  **Sync Files:** Run `node build.js` to update `index.html`.
2.  **Verify Manifest:** Check that version numbers are consistent.
3.  **Refresh Package:** Clean and recreate `production.zip` for the Chrome Store.
4.  **Interactive Git:** 
    - Display a summary of changed core files.
    - Prompt you to enter a custom commit message.
    - Perform `git add .` (which will obey your new `.gitignore`), `git commit`, and `git push`.

### 2. Guardrails Configuration
#### [MODIFY] [.gitignore](file:///c:/Users/janak/job-tracker-app/.gitignore)
- Add `local-deploy.ps1` to the ignore list to ensure it stays exclusive to your local machine.

## Verification Plan

### Manual Verification
- I will run the script once to demonstrate its interactive prompts.
- I will verify that `git status` shows no "untracked" development files being staged.
