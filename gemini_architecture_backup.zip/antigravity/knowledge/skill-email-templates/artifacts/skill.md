# React Email

## Template
```tsx
import { Html, Button } from '@react-email/components';
export default function WelcomeEmail() {
  return (
    <Html>
      <Button href="https://example.com">Click me</Button>
    </Html>
  );
}
```

## Send (Resend)
```ts
await resend.emails.send({ from: 'a@b.com', to: 'c@d.com', subject: 'Hi', react: WelcomeEmail() });
```