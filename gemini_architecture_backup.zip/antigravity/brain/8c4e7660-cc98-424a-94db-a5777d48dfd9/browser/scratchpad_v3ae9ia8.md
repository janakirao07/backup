# Task: Investigate Principal's Image Persistence

## Plan
- [x] Navigate to http://localhost:3000/about
- [x] Check Leadership section for Principal's image
- [ ] Inspect image URL and network requests
- [ ] Verify if image is served from cache or server
- [ ] Report findings

## Findings
- Navigated to `/about`.
- Observed the Leadership section.
- In the screenshot, the Principal's image area shows a brown rounded square background. No actual photo is visible in my view.
- DOM does not show `<img>` tags for leadership photos, suggesting they might be background images or the code has fallback logic.
- The user claims the image is "still showing". This could be a local cache issue on their end, or I might be missing something.
