---
name: authentication-patterns
description: Authentication and authorization patterns for web apps. Use when implementing login, signup, OAuth, JWT, session management, role-based access, or Supabase Auth.
---

# Authentication Patterns

## Auth Methods Comparison
| Method | Best for | Security | Complexity |
|--------|----------|----------|------------|
| JWT (stateless) | APIs, SPAs | Medium | Low |
| Session cookies | Server-rendered apps | High | Medium |
| OAuth 2.0 / OIDC | Social login, SSO | High | High |
| Magic links | Passwordless | High | Low |
| Passkeys/WebAuthn | Modern password-free | Very High | Medium |

## JWT Best Practices
```javascript
// Token structure: header.payload.signature

// ✅ DO
- Store access tokens in memory (JS variable)
- Store refresh tokens in httpOnly cookies
- Set short expiry for access tokens (15 min)
- Set longer expiry for refresh tokens (7 days)
- Include minimal claims (sub, role, exp)

// ❌ DON'T
- Store JWTs in localStorage (XSS vulnerable)
- Include sensitive data in JWT payload
- Use symmetric keys in production (use RS256)
- Skip token validation on the server
```

## Supabase Auth Patterns
```javascript
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(url, anonKey);

// Email/Password signup
const { data, error } = await supabase.auth.signUp({
  email: 'user@example.com',
  password: 'secure-password-here',
});

// OAuth login
const { data, error } = await supabase.auth.signInWithOAuth({
  provider: 'google',
  options: { redirectTo: 'https://yourapp.com/callback' },
});

// Get current user
const { data: { user } } = await supabase.auth.getUser();

// Listen for auth changes
supabase.auth.onAuthStateChange((event, session) => {
  if (event === 'SIGNED_IN') { /* redirect */ }
  if (event === 'SIGNED_OUT') { /* cleanup */ }
});

// Protect API route (Next.js)
import { createServerClient } from '@supabase/ssr';

export async function middleware(request) {
  const supabase = createServerClient(url, anonKey, { cookies });
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.redirect('/login');
}
```

## Row Level Security (RLS)
```sql
-- Enable RLS on table
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;

-- Users can only read their own posts
CREATE POLICY "Users read own posts" ON posts
  FOR SELECT USING (auth.uid() = user_id);

-- Users can insert their own posts
CREATE POLICY "Users insert own posts" ON posts
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Admins can read all posts
CREATE POLICY "Admins read all" ON posts
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin')
  );
```

## Role-Based Access Control (RBAC)
```typescript
type Role = 'user' | 'editor' | 'admin' | 'superadmin';

const PERMISSIONS: Record<Role, string[]> = {
  user: ['read:own'],
  editor: ['read:own', 'write:own', 'read:all'],
  admin: ['read:own', 'write:own', 'read:all', 'write:all', 'delete:own'],
  superadmin: ['*'],
};

function hasPermission(userRole: Role, permission: string): boolean {
  const perms = PERMISSIONS[userRole];
  return perms.includes('*') || perms.includes(permission);
}

// Middleware guard
function requirePermission(permission: string) {
  return (req, res, next) => {
    if (!hasPermission(req.user.role, permission)) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    next();
  };
}
```

## Security Checklist
- [ ] Passwords hashed with bcrypt/argon2 (never plain text)
- [ ] HTTPS everywhere (no HTTP)
- [ ] CSRF tokens on forms
- [ ] Rate limiting on auth endpoints (5 attempts/min)
- [ ] Account lockout after failed attempts
- [ ] Secure password reset flow (time-limited tokens)
- [ ] Input validation and sanitization
- [ ] httpOnly, Secure, SameSite flags on cookies
- [ ] Logout clears all tokens and sessions
- [ ] Audit logging for auth events
