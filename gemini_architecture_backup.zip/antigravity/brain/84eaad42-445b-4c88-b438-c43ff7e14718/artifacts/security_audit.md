# Supabase Security Audit & Hardening Report

## Current Security Posture
The Primetek Global portal follows a **Server-Side Security Pattern**:
1. **Authentication**: Handled via custom JWTs and Next.js Server Actions.
2. **Authorization**: Managed in server-side logic (`actions.ts`) before reaching the database.
3. **Database Access**: Uses `SUPABASE_SERVICE_ROLE_KEY` in `supabase-admin.ts`. This key bypasses Row Level Security (RLS) and is strictly kept on the server (never exposed to the browser).
4. **RLS Status**: Enabled on all tables, preventing direct unauthorized access from the frontend using the public `anon` key.

## Recommended Hardening (RLS Policies)
Even with a server-side pattern, it is a best practice to define explicit RLS policies to prevent data leakage in case of key misconfiguration or future frontend changes.

I have prepared the following SQL to solidify the database security:

```sql
-- 1. Hardening Inquiries Table
-- Anonymous users can only insert. Admin viewing is handled via Service Role.
DROP POLICY IF EXISTS "Public can insert inquiries" ON public.inquiries;
CREATE POLICY "Public can insert inquiries" ON public.inquiries 
    FOR INSERT WITH CHECK (true);
-- Ensure no one can view inquiries via anon key
CREATE POLICY "Anon cannot view inquiries" ON public.inquiries 
    FOR SELECT USING (false);

-- 2. Hardening Jobs Table
-- Public can only see active jobs. 
DROP POLICY IF EXISTS "Public can view active jobs" ON public.jobs;
CREATE POLICY "Public can view active jobs" ON public.jobs 
    FOR SELECT USING (is_active = true);

-- 3. Hardening Applications Table
-- Public can only submit (INSERT). No direct viewing allowed.
DROP POLICY IF EXISTS "Public can insert applications" ON public.applications;
CREATE POLICY "Public can insert applications" ON public.applications 
    FOR INSERT WITH CHECK (true);
CREATE POLICY "Anon cannot view applications" ON public.applications 
    FOR SELECT USING (false);

-- 4. Office Locations
-- Needed for the check-in component to get coordinates client-side
CREATE POLICY "Public can view office locations" ON public.office_locations
    FOR SELECT USING (is_active = true);

-- 5. Strict Lock-down for Sensitive Tables
-- These tables have NO policies for 'anon', meaning all access is blocked by default.
-- Only the SUPABASE_SERVICE_ROLE (used in our backend) can access these.
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;

-- 6. Storage Security
-- Resumes are private (no public access).
-- Avatars are public for viewing but only backend can upload.
DROP POLICY IF EXISTS "Public can view avatars" ON storage.objects;
CREATE POLICY "Public can view avatars" ON storage.objects 
    FOR SELECT USING (bucket_id = 'avatars');
```

## Security Best Practices Implemented
- [x] **Service Role Isolation**: The service key is only used in `src/lib/supabase-admin.ts`.
- [x] **Environment Variable Hygiene**: All keys are stored in `.env.local` and not committed to git.
- [x] **Explicit RLS**: Every table has RLS enabled.
- [x] **Default Deny**: For sensitive tables (employees, attendance), there are no `anon` policies, defaulting to full access denial for public users.
