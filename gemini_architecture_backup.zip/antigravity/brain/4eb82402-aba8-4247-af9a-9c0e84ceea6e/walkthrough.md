# ActionSense — Implementation Walkthrough

## Overview

Built the complete **ActionSense** human action recognition platform — a production-grade deep learning system for real-time video action classification. The platform spans **45+ files** across 11 subsystems.

## Architecture Summary

```mermaid
graph TB
    subgraph Input["📥 Data Input"]
        V[Video Files]
        R[RTSP Streams]
        W[Webcam]
    end

    subgraph Pipeline["⚙️ Data Pipeline"]
        I[Ingestion] --> P[Preprocessing]
        P --> T[Transforms]
        T --> D[Dataset / DataLoader]
    end

    subgraph Features["🔬 Feature Extraction"]
        OF[Optical Flow]
        PE[Pose Estimation]
        DE[Descriptors]
    end

    subgraph Models["🧠 Model Architectures"]
        CL[CNN + LSTM]
        R3[ResNet3D / R2+1D]
        VT[Video Transformer]
    end

    subgraph Training["🏋️ Training"]
        TR[Trainer Engine]
        EV[Evaluator]
        CB[Callbacks]
    end

    subgraph Serving["🌐 Serving"]
        IE[Inference Engine]
        SI[Stream Inference]
        API[FastAPI REST API]
        DB[Dashboard]
    end

    V --> I
    R --> SI
    W --> SI
    D --> Models
    Models --> TR
    TR --> EV
    Models --> IE
    IE --> API
    SI --> API
    API --> DB
```

---

## What Was Built

### Phase 1–2: Foundation
| File | Purpose |
|------|---------|
| [pyproject.toml](file:///C:/Users/janak/actionsense/pyproject.toml) | PEP 621 project metadata + dependency management |
| [requirements.txt](file:///C:/Users/janak/actionsense/requirements.txt) | Pinned dependencies (PyTorch, FastAPI, OpenCV, etc.) |
| [settings.py](file:///C:/Users/janak/actionsense/config/settings.py) | Pydantic settings with env-var loading |
| [constants.py](file:///C:/Users/janak/actionsense/config/constants.py) | 101 UCF + 51 HMDB action classes, normalization stats |
| [device.py](file:///C:/Users/janak/actionsense/actionsense/utils/device.py) | CUDA auto-detection, TF32 optimization, memory tracking |
| [metrics.py](file:///C:/Users/janak/actionsense/actionsense/utils/metrics.py) | Top-K accuracy, F1, confusion matrix computation |

---

### Phase 3–4: Data & Features
| File | Purpose |
|------|---------|
| [dataset.py](file:///C:/Users/janak/actionsense/actionsense/data/dataset.py) | UCF101Dataset, HMDB51Dataset with multi-strategy frame sampling |
| [transforms.py](file:///C:/Users/janak/actionsense/actionsense/data/transforms.py) | MixUp, CutMix, temporal jitter, random erasing augmentations |
| [download.py](file:///C:/Users/janak/actionsense/actionsense/data/download.py) | Automated dataset download with progress tracking |
| [optical_flow.py](file:///C:/Users/janak/actionsense/actionsense/features/optical_flow.py) | Farnebäck and TV-L1 optical flow extraction |
| [pose_estimation.py](file:///C:/Users/janak/actionsense/actionsense/features/pose_estimation.py) | MediaPipe skeleton-based pose features |

---

### Phase 5: Model Architectures (3 architectures + backbone loader + registry)

| File | Architecture | Key Features |
|------|-------------|--------------|
| [cnn_lstm.py](file:///C:/Users/janak/actionsense/actionsense/models/cnn_lstm.py) | **CNN + LSTM** | Multi-backbone (ResNet/EfficientNet), bidirectional LSTM, attention-weighted temporal pooling |
| [resnet3d.py](file:///C:/Users/janak/actionsense/actionsense/models/resnet3d.py) | **ResNet3D / R(2+1)D** | Kinetics-pretrained, 3D residual blocks, decomposed spatiotemporal convolutions |
| [transformer.py](file:///C:/Users/janak/actionsense/actionsense/models/transformer.py) | **Video Transformer** | 3D patch embedding, stochastic depth, pre-norm blocks, learned CLS token |
| [backbones.py](file:///C:/Users/janak/actionsense/actionsense/models/backbones.py) | Backbone Loader | ResNet, EfficientNet, ViT, Swin Transformer, timm fallback |
| [registry.py](file:///C:/Users/janak/actionsense/actionsense/models/registry.py) | Model Factory | `get_model("cnn_lstm", num_classes=101)` pattern |

---

### Phase 6: Training Pipeline

| File | Purpose |
|------|---------|
| [trainer.py](file:///C:/Users/janak/actionsense/actionsense/training/trainer.py) | Full training loop: AMP, MixUp, gradient accumulation, torch.compile, MLflow |
| [evaluator.py](file:///C:/Users/janak/actionsense/actionsense/training/evaluator.py) | Model evaluation, confusion matrix heatmaps, per-class bar charts |
| [callbacks.py](file:///C:/Users/janak/actionsense/actionsense/training/callbacks.py) | ModelCheckpoint (top-K management), EarlyStopping with patience |
| [optimizer.py](file:///C:/Users/janak/actionsense/actionsense/training/optimizer.py) | AdamW/SGD factory with param-group weight decay, cosine/warmup schedulers |

---

### Phase 7: Inference Engine

| File | Purpose |
|------|---------|
| [engine.py](file:///C:/Users/janak/actionsense/actionsense/inference/engine.py) | Single/batch prediction, ONNX export & runtime, torch.compile acceleration |
| [stream.py](file:///C:/Users/janak/actionsense/actionsense/inference/stream.py) | Multi-stream RTSP/webcam inference with background threads + results queue |

---

### Phase 8: REST API (FastAPI)

| File | Purpose |
|------|---------|
| [main.py](file:///C:/Users/janak/actionsense/actionsense/api/main.py) | FastAPI app with CORS, request timing, lifecycle, versioned routing |
| [auth.py](file:///C:/Users/janak/actionsense/actionsense/api/auth.py) | JWT Bearer auth, RBAC (admin/operator/viewer), bcrypt password hashing |
| [schemas.py](file:///C:/Users/janak/actionsense/actionsense/api/schemas.py) | 20+ Pydantic models for all API requests/responses |
| [predict.py](file:///C:/Users/janak/actionsense/actionsense/api/routes/predict.py) | `POST /predict` — video upload classification |
| [stream.py](file:///C:/Users/janak/actionsense/actionsense/api/routes/stream.py) | `POST /stream/start`, `DELETE /stream/{id}` — RTSP management |
| [models.py](file:///C:/Users/janak/actionsense/actionsense/api/routes/models.py) | `GET /models`, `POST /models/train` — model management |
| [health.py](file:///C:/Users/janak/actionsense/actionsense/api/routes/health.py) | `GET /health` — GPU status, uptime |

---

### Phase 9: Evaluation Dashboard

Premium dark-mode glassmorphism single-page dashboard with 5 tabs:

| Tab | Charts / Features |
|-----|-------------------|
| **Overview** | KPI metrics (animated), accuracy/loss curves, model comparison bars |
| **Performance** | Confusion matrix, confidence distribution, precision-recall scatter |
| **Per-Class** | Horizontal bar chart (color-coded by accuracy tier), search + sort |
| **Training** | LR schedule curve, GPU memory usage, training config grid |
| **Live Demo** | Video upload/webcam, real-time prediction bars, FPS/latency stats |

Design: Ambient gradient orbs, Inter + JetBrains Mono fonts, glassmorphism cards, micro-animations, responsive.

Files: [index.html](file:///C:/Users/janak/actionsense/dashboard/index.html), [dashboard.css](file:///C:/Users/janak/actionsense/dashboard/css/dashboard.css), [charts.js](file:///C:/Users/janak/actionsense/dashboard/js/charts.js), [app.js](file:///C:/Users/janak/actionsense/dashboard/js/app.js)

---

### Phase 10–11: CLI, DevOps, Tests

| File | Purpose |
|------|---------|
| [scripts/train.py](file:///C:/Users/janak/actionsense/scripts/train.py) | CLI: `python scripts/train.py --model cnn_lstm --epochs 50` |
| [scripts/infer.py](file:///C:/Users/janak/actionsense/scripts/infer.py) | CLI: `python scripts/infer.py --video clip.mp4` |
| [scripts/evaluate.py](file:///C:/Users/janak/actionsense/scripts/evaluate.py) | CLI: evaluation + report generation |
| [scripts/download_datasets.py](file:///C:/Users/janak/actionsense/scripts/download_datasets.py) | CLI: dataset download with verification |
| [Dockerfile](file:///C:/Users/janak/actionsense/Dockerfile) | Multi-stage CUDA 12.2 container |
| [docker-compose.yml](file:///C:/Users/janak/actionsense/docker-compose.yml) | Full stack: API + PostgreSQL + Redis + MLflow |
| [tests/test_models.py](file:///C:/Users/janak/actionsense/tests/test_models.py) | Architecture unit tests (forward shapes, registry) |
| [tests/test_api.py](file:///C:/Users/janak/actionsense/tests/test_api.py) | API integration tests (health, auth, models) |

---

## Quick Start Commands

```bash
# Install
pip install -r requirements.txt

# Download dataset
python scripts/download_datasets.py --dataset ucf101

# Train
python scripts/train.py --model cnn_lstm --epochs 50

# Evaluate
python scripts/evaluate.py --checkpoint data/checkpoints/best_model.pth

# Inference
python scripts/infer.py --video path/to/video.mp4

# Start API + Dashboard
python -m actionsense.api.main
# → API docs:   http://localhost:8000/docs
# → Dashboard:  http://localhost:8000/dashboard

# Docker
docker-compose up -d

# Tests
pytest tests/ -v
```
