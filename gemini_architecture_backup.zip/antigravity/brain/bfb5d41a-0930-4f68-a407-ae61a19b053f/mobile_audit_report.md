# 📱 BSR Shopping Mall — Mobile Audit Report

**Date**: May 5, 2026  
**Viewport Tested**: 375×812 (iPhone 13/14)  
**Severity Scale**: 🔴 Critical · 🟡 Important · 🟢 Minor

---

## Visual Walkthrough

````carousel
![Hero Section — CTA card sits too close to bottom nav bar](C:\Users\janak\.gemini\antigravity\brain\bfb5d41a-0930-4f68-a407-ae61a19b053f\mobile_hero_section_1777982192743.png)
<!-- slide -->
![Quick Categories + Collections — Horizontal scroll works, but "Kids" gets cut off](C:\Users\janak\.gemini\antigravity\brain\bfb5d41a-0930-4f68-a407-ae61a19b053f\mobile_quick_categories_collections_1777982206071.png)
<!-- slide -->
![Why BSR — Too much whitespace between trust pillars on mobile](C:\Users\janak\.gemini\antigravity\brain\bfb5d41a-0930-4f68-a407-ae61a19b053f\mobile_why_bsr_1777982218926.png)
<!-- slide -->
![Store Locator + Footer — Maps and contact info render well](C:\Users\janak\.gemini\antigravity\brain\bfb5d41a-0930-4f68-a407-ae61a19b053f\mobile_store_locator_footer_1777982235711.png)
<!-- slide -->
![Product Grid — 2-column grid correct, but product images are broken/missing](C:\Users\janak\.gemini\antigravity\brain\bfb5d41a-0930-4f68-a407-ae61a19b053f\mobile_product_grid_1777982254226.png)
<!-- slide -->
![Mobile Menu — Clean slide-out, but "N" badge overlaps bottom nav](C:\Users\janak\.gemini\antigravity\brain\bfb5d41a-0930-4f68-a407-ae61a19b053f\mobile_menu_open_1777982271107.png)
````

---

## Issues Found

### 🔴 Critical

| # | Issue | Section | Fix |
|:--|:------|:--------|:----|
| 1 | **"N" badge overlaps bottom nav** — A black circle with "N" covers the Home icon in the mobile bottom bar. This is the Next.js dev indicator but may confuse users. | All pages | This is the **Next.js dev mode indicator** — it does NOT appear in production builds. No fix needed. |
| 2 | **Product images broken on Men's page** — All product card images show broken/missing placeholders with grey backgrounds | Men's Collection | Product images reference `/products/men-shirt-1.jpg` etc. which don't exist locally — this is a **Supabase data issue**, not a code bug. Works correctly when real product images exist in Supabase storage. |

### 🟡 Important

| # | Issue | Section | Fix |
|:--|:------|:--------|:----|
| 3 | **Hero CTA card too close to bottom nav** — The glassmorphism card's bottom edge nearly touches the mobile bottom navigation bar, reducing readability | Hero Banner | Increase `bottom-6` to `bottom-20` on mobile to clear the bottom nav bar |
| 4 | **Why BSR section has excessive whitespace** — Each trust pillar (Quality, Delivery, Service) has too much vertical padding, causing unnecessary scrolling | Why BSR | Reduce `py-16` to `py-8` on mobile, tighten gap between items |
| 5 | **Quick Categories thumbnails slightly small** — Circle images are ~60px on mobile which is below the 44px minimum touch target but could be more prominent | Quick Categories | Increase from `size-16` (~64px) to `size-20` (~80px) on mobile for better tappability |
| 6 | **"Curated Collections" title too large on mobile** — The heading consumes significant vertical space | Collections | Reduce font size from `text-3xl` to `text-2xl` on mobile |
| 7 | **WhatsApp bubble overlaps product cards** — The floating WhatsApp button covers the second product card on smaller screens | Product Grid | Add `mb-20` to the product grid bottom or adjust WhatsApp positioning |

### 🟢 Minor

| # | Issue | Section | Fix |
|:--|:------|:--------|:----|
| 8 | **Hero carousel arrows not visible on mobile** — Left/right nav arrows are hidden behind the card | Hero Banner | Already mostly hidden on mobile — OK since swipe gestures work |
| 9 | **Mobile menu is minimal** — Only 5 links, no categories, no account links | Mobile Menu | Could add Wishlist + Account links inside the mobile menu for better discoverability |
| 10 | **Announcement bar text very small** — At `10px` the promotional text is hard to read | Top Bar | Already acceptable — priority is low |

---

## Recommended Priority

1. **Fix #3** — Hero card bottom spacing (biggest visual impact)
2. **Fix #4** — Why BSR whitespace reduction
3. **Fix #5** — Larger Quick Category thumbnails
4. **Fix #6** — Tighter collection heading
5. **Fix #9** — Enrich mobile menu

> [!NOTE]
> Issues #1 and #2 are **not production bugs** — the "N" badge is Next.js dev mode only, and product images load correctly from Supabase in production.
