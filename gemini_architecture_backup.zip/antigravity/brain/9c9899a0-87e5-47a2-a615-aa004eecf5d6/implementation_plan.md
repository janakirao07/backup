# Implementation Plan: Cloud-Synced Personal Profile

Currently, your personal details (name, email, phone, etc.) are only stored in your browser's local cache. If you clear your history or switch computers, these details are lost. I will migrate this data to your Supabase database.

## User Review Required

> [!IMPORTANT]
> **Database Column Requirement**: I will attempt to save your profile to a new column called `resume_profile` in your Supabase `user_settings` table. 
> 
> If the save fails, you may need to manually add a column named `resume_profile` (type: `jsonb` or `text`) to the `user_settings` table in your Supabase Dashboard.

## Proposed Changes

### [MODIFY] [app.js](file:///c:/Users/janak/job-tracker-app/scripts/app.js)
- Implement `saveResumeProfileDB()` and `loadResumeProfileDB()`.
- Update the "Resume Profile" settings tab to load from and save to the database.
- Ensure the extension's `chrome.storage.local` is kept in sync.

### [MODIFY] [content.js](file:///c:/Users/janak/job-tracker-app/scripts/content.js)
- Update the sidebar's settings logic to fetch the latest profile from the database upon opening, rather than relying solely on local storage.

## Verification Plan

### Automated Tests
- Syntax check on modified files.
- Test data persistence via `sbFetch` proxy if possible.

### Manual Verification
1. Save profile details in the Web Dashboard.
2. Hard-refresh the page and verify details persist.
3. Open the extension sidebar on a different page and verify the same details are loaded.
