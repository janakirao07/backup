# PyTorch Best Practices

## Tensor Basics
```python
import torch

# Device setup — always parameterize
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Create tensors on target device directly
x = torch.randn(3, 4, device=device)
y = torch.zeros(3, 4, dtype=torch.float32, device=device)

# Avoid: creating on CPU then moving
# x = torch.randn(3, 4).to(device)  # extra copy
```

## Model Architecture
```python
import torch.nn as nn

class MyModel(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, dropout=0.3):
        super().__init__()
        self.network = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.BatchNorm1d(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(inplace=True),
            nn.Linear(hidden_dim // 2, output_dim)
        )

    def forward(self, x):
        return self.network(x)

# Weight initialization
def init_weights(m):
    if isinstance(m, nn.Linear):
        nn.init.kaiming_normal_(m.weight, nonlinearity='relu')
        if m.bias is not None:
            nn.init.zeros_(m.bias)

model = MyModel(784, 256, 10).to(device)
model.apply(init_weights)
```

## DataLoader Pattern
```python
from torch.utils.data import Dataset, DataLoader

class CustomDataset(Dataset):
    def __init__(self, data, labels, transform=None):
        self.data = data
        self.labels = labels
        self.transform = transform

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        x = self.data[idx]
        if self.transform:
            x = self.transform(x)
        return x, self.labels[idx]

# Optimal DataLoader settings
train_loader = DataLoader(
    dataset,
    batch_size=64,
    shuffle=True,
    num_workers=4,        # parallel data loading
    pin_memory=True,      # faster CPU→GPU transfer
    drop_last=True,       # consistent batch sizes
    persistent_workers=True  # keep workers alive between epochs
)
```

## Training Loop (Production-Grade)
```python
def train_one_epoch(model, loader, criterion, optimizer, scheduler, device, epoch):
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0

    for batch_idx, (inputs, targets) in enumerate(loader):
        inputs, targets = inputs.to(device, non_blocking=True), targets.to(device, non_blocking=True)

        optimizer.zero_grad(set_to_none=True)  # more efficient than zero_grad()

        outputs = model(inputs)
        loss = criterion(outputs, targets)
        loss.backward()

        # Gradient clipping — prevents exploding gradients
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

        optimizer.step()

        running_loss += loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()

    if scheduler:
        scheduler.step()

    return running_loss / len(loader), 100. * correct / total

@torch.no_grad()
def evaluate(model, loader, criterion, device):
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0

    for inputs, targets in loader:
        inputs, targets = inputs.to(device, non_blocking=True), targets.to(device, non_blocking=True)
        outputs = model(inputs)
        loss = criterion(outputs, targets)

        running_loss += loss.item()
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()

    return running_loss / len(loader), 100. * correct / total
```

## Model Saving & Loading
```python
# Save best model (checkpoint)
def save_checkpoint(model, optimizer, epoch, loss, path="best_model.pth"):
    torch.save({
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'loss': loss,
    }, path)

# Load checkpoint
def load_checkpoint(model, optimizer, path="best_model.pth"):
    checkpoint = torch.load(path, map_location=device, weights_only=True)
    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    return checkpoint['epoch'], checkpoint['loss']

# Export for inference only
torch.save(model.state_dict(), "model_weights.pth")
```

## Mixed Precision Training (AMP)
```python
from torch.amp import autocast, GradScaler

scaler = GradScaler('cuda')

for inputs, targets in train_loader:
    optimizer.zero_grad(set_to_none=True)

    with autocast('cuda'):
        outputs = model(inputs)
        loss = criterion(outputs, targets)

    scaler.scale(loss).backward()
    scaler.step(optimizer)
    scaler.update()
```

## Common Pitfalls
- **Forgetting model.eval()** before inference — BatchNorm/Dropout behave differently
- **Not using torch.no_grad()** during validation — wastes memory on gradient computation
- **Data on wrong device** — always `.to(device)` both model AND data
- **Learning rate too high** — start with 1e-3 for Adam, 1e-2 for SGD
- **Not shuffling training data** — always `shuffle=True` for training, `False` for validation
- **Memory leaks** — detach tensors before logging: `loss.item()` not `loss`
