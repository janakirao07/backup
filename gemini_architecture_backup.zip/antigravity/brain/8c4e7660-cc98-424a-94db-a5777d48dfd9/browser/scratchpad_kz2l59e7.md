# Task: Verify Principal's image on About page

## Checklist
- [x] Open http://localhost:3000/about
- [x] Verify Principal's image visibility
- [x] Check for other issues

## Findings
- Principal's image (**Sri S. Appala Naidu**) is successfully displayed.
- Founder's image (**Sri M. Sanyasi Naidu**) is currently broken/missing (shows a placeholder).
- The rest of the page layout and "Trust" card points appear correct as per previous updates.
