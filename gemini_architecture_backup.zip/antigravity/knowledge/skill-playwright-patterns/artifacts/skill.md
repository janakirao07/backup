# Playwright Patterns
## Basic Test
```ts
import { test, expect } from '@playwright/test';

test('login flow', async ({ page }) => {
  await page.goto('/login');
  await page.getByLabel('Email').fill('user@test.com');
  await page.getByLabel('Password').fill('password123');
  await page.getByRole('button', { name: 'Sign In' }).click();
  await expect(page.getByText('Dashboard')).toBeVisible();
  await expect(page).toHaveURL('/dashboard');
});
```
## Page Object
```ts
class LoginPage {
  constructor(private page: Page) {}
  async login(email: string, password: string) {
    await this.page.getByLabel('Email').fill(email);
    await this.page.getByLabel('Password').fill(password);
    await this.page.getByRole('button', { name: 'Sign In' }).click();
  }
}
```
## Key Selectors (Priority Order)
1. `getByRole('button', { name: 'Submit' })` — accessible
2. `getByLabel('Email')` — form fields
3. `getByText('Welcome')` — visible text
4. `getByTestId('submit-btn')` — data-testid fallback
## Config
```ts
// playwright.config.ts
export default defineConfig({
  testDir: './tests',
  use: { baseURL: 'http://localhost:3000', screenshot: 'only-on-failure', trace: 'on-first-retry' },
  projects: [{ name: 'chromium', use: devices['Desktop Chrome'] }, { name: 'mobile', use: devices['iPhone 13'] }],
});
```
