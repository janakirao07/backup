# Task: Check Hero Banner on Mobile Viewport

## Plan
- [x] Navigate to https://bsrshoppingmall.vercel.app/
- [x] Resize window to 375x812
- [x] Capture screenshots of all banner slides
- [x] Analyze image cropping and text positioning
- [x] Report findings

## Progress
- Navigated to the site and resized to 375x812.
- Captured 3 slides:
  1. Summer Collection (up to 20% off)
  2. Men Collection 2026
  3. Kanchipuram Pattu Saree
- Observations:
  - The text card (glassmorphism) is very large on mobile, covering a significant portion of the image.
  - The images seem to be landscape (desktop) images being used on mobile, leading to severe cropping where the main subject is often obscured or cut off.
  - The text card is centered, which might not be ideal if the subject of the image is also in the center.
