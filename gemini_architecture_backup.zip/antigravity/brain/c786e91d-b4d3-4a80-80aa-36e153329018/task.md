# Home Directory Cleanup

## Home Directory (`C:\Users\janak\`)
- [ ] Create organized folders (`_PersonalDocs`, `_PythonScripts`, `_DataFiles`, `_SQLFiles`, `_Images`, `_Archives`, `_Misc`)
- [ ] Delete old installer .exe files (~1.6GB)
- [ ] Delete Splunk installer (~1GB)
- [ ] Move loose Python scripts to `_PythonScripts/`
- [ ] Move personal docs to `_PersonalDocs/`
- [ ] Move data files to `_DataFiles/`
- [ ] Move SQL files to `_SQLFiles/`
- [ ] Move images to `_Images/`
- [ ] Move archives to `_Archives/`
- [ ] Move misc files to `_Misc/`

## Downloads Folder (`C:\Users\janak\Downloads\`)
- [ ] Delete old installer .exe files
- [ ] Organize remaining files into subfolders
- [ ] Verify final state
