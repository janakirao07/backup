# BSR Shopping Mall — UI & Aesthetic Refinement Audit

Before implementing the redesign, we have audited the current storefront against modern premium luxury fashion ecommerce standards (e.g., Zara, H&M Premium, Anita Dongre, Tarun Tahiliani). 

## 1. Visual Problems
*   **Overuse of Glassmorphism:** The `HeroBanner` component relies heavily on heavily blurred, semi-transparent white boxes (`bg-white/[0.12] backdrop-blur-xl`). While trendy, luxury ecommerce typically favors clean, unboxed text directly on high-contrast imagery, or stark solid-color blocks. This "glass" effect dilutes the premium feel.
*   **Noisy Gradients & Overlays:** The hero section adds a `bg-gradient-to-br` beneath images, and a heavy bottom gradient (`from-black/70`). This muddies the photography, which should be the star in fashion ecommerce.
*   **Template-Like Components:** The Navbar uses standard `NavigationMenu` components that retain generic button-like hover states, lacking the spacious, minimalist, text-first approach of high-end brands.
*   **Cluttered Badges:** The discount badge in the hero banner features an animating green pulse dot and heavy borders, leaning more towards a discount-store aesthetic than luxury retail.

## 2. Layout Hierarchy Issues
*   **Navbar Spacing:** Navigation items are clustered together without sufficient "breathing room." Luxury design requires generous negative space.
*   **Hero Text Sizing:** The hero title scaling (`text-xl sm:text-2xl md:text-4xl lg:text-5xl`) is slightly disproportionate. High-end sites often use oversized, elegant serif typography that commands the viewport, paired with extremely crisp, small sans-serif subtitles.
*   **CTA Button Weight:** The Hero CTA is heavily styled (`shadow-lg`, `hover:scale-105`). Premium CTAs are usually flat, sharp rectangles or minimal pill shapes with subtle underline or color-invert interactions.

## 3. Branding Inconsistencies
*   **Iconography:** The Navbar mixes `lucide-react` icons with default stroke weights. A premium UI should enforce a consistent, slightly thinner stroke weight (e.g., `strokeWidth={1.5}`) for a sharper, more delicate appearance.
*   **Typography:** The font pairing (`Cormorant Garamond` + `Jost`) is excellent, but its application is inconsistent. Some elements lack the strict tracking (letter-spacing) rules needed to make uppercase sans-serifs look expensive.
*   **Color Palette:** The `brand-red` and `brand-orange` are quite vibrant. They need to be used strictly as accents against stark whites, off-whites (`slate-50`), and deep blacks/charcoals, rather than dominating large UI areas.

## 4. Mobile UX Risks
*   **Scaled-Down Desktop:** The Hero text card on mobile simply shrinks the text and drops it to the bottom. It can obstruct the focal point of mobile portrait images. It should sit elegantly at the bottom third with a very smooth, tall gradient.
*   **Touch Targets:** The Mobile Menu trigger and icons need to remain perfectly touch-friendly (min 44x44px) without looking visually bulky.

## Implementation Plan
1.  **Refine Navbar:** Remove boxed hover states, increase gap spacing, use uppercase `Jost` with wide tracking for links, thin out icon stroke weights to `1.5`, and streamline the layout.
2.  **Overhaul HeroBanner:** Remove the glassmorphism box. Let the typography breathe directly over the image with a subtle, tall gradient for contrast. Make the CTA a sharp, minimalist block or an elegant pill.
3.  **Refine Typography:** Enforce stricter tracking rules for `Jost` and let `Cormorant Garamond` shine in headings.
4.  **Polish Storefront Page:** Ensure section headers ("Curated Collections", "Why BSR") share the same minimalist luxury aesthetic.
