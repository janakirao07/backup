# Prisma ORM
## Schema
```prisma
datasource db { provider = 'postgresql' url = env('DATABASE_URL') }
generator client { provider = 'prisma-client-js' }

model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  jobs      Job[]
  createdAt DateTime @default(now())
}
model Job {
  id        String   @id @default(cuid())
  title     String
  company   String
  status    Status   @default(SAVED)
  userId    String
  user      User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  createdAt DateTime @default(now())
  @@index([userId, status])
}
enum Status { SAVED APPLIED INTERVIEW OFFER REJECTED }
```
## Queries
```ts
const jobs = await prisma.job.findMany({
  where: { userId, status: 'APPLIED' },
  orderBy: { createdAt: 'desc' },
  include: { user: { select: { name: true } } },
  take: 20,
});
const job = await prisma.job.create({ data: { title, company, userId } });
const updated = await prisma.job.update({ where: { id }, data: { status: 'INTERVIEW' } });
await prisma.job.delete({ where: { id } });
```
## Transactions
```ts
const [job, notification] = await prisma.$transaction([
  prisma.job.update({ where: { id }, data: { status: 'OFFER' } }),
  prisma.notification.create({ data: { userId, message: 'You got an offer!' } }),
]);
```
## Commands
```bash
npx prisma migrate dev --name init
npx prisma generate
npx prisma studio    # GUI browser
npx prisma db seed
```
