# Bun Runtime

## HTTP Server
```ts
Bun.serve({
  port: 3000,
  fetch(req) {
    return new Response("Hello via Bun!");
  }
});
```
## SQLite
```ts
import { Database } from 'bun:sqlite';
const db = new Database(':memory:');
db.query('SELECT 1').all();
```