---
name: goey-toast-best-practices
description: Goey Toast notification component. Use when adding gooey, morphing toast notifications to React apps using Sonner + Framer Motion.
---

# Goey Toast

## Installation
```bash
npm install goey-toast sonner framer-motion
```

## Setup
```tsx
// In your root layout (app/layout.tsx or _app.tsx)
import { GoeyToaster } from 'goey-toast';

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        {children}
        <GoeyToaster position="bottom-right" />
      </body>
    </html>
  );
}
```

## Usage
```tsx
import { toast } from 'goey-toast';

// Success
toast.success('Saved successfully!');

// Error
toast.error('Something went wrong');

// Info
toast.info('New update available');

// Warning
toast.warning('Low disk space');

// Custom
toast('Custom message', {
  description: 'With a description',
  duration: 5000,
  action: {
    label: 'Undo',
    onClick: () => handleUndo(),
  },
});

// Promise
toast.promise(saveData(), {
  loading: 'Saving...',
  success: 'Saved!',
  error: 'Failed to save',
});
```

## Features
- 🫧 Gooey morphing SVG filter effect
- 🎭 Smooth enter/exit animations (Framer Motion)
- 🎨 Built on Sonner (best toast library)
- ♿ Accessible — proper ARIA roles
- 📱 Responsive positioning
- ⏱️ Auto-dismiss with configurable duration

## Position Options
```tsx
<GoeyToaster
  position="top-right"     // top-left, top-center, top-right
                            // bottom-left, bottom-center, bottom-right
  toastOptions={{
    duration: 4000,
    style: { background: '#1a1a2e', color: '#fff' },
  }}
/>
```

## When to Use
- ✅ Any React app needing beautiful notifications
- ✅ Form submissions, save confirmations
- ✅ Error/success feedback
- ❌ Complex multi-step notifications (use a proper notification center)
