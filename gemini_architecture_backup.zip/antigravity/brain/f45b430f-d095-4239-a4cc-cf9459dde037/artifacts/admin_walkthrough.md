# Admin Dashboard & Branding Upgrade Walkthrough

This guide covers the major improvements made to the **S.K. Degree & P.G. College** platform, focusing on administrative functionality and branding consistency.

## 1. Authentication & Redirection
The admin login flow has been completely modernized to ensure a seamless experience.

- **Unified Session Management**: The app now listens to real-time Supabase auth state changes. No more manual refreshes are needed after logging in.
- **Integrated Layout**: The global Header and Footer are now visible on the login page, maintaining consistent branding throughout the entry process.
- **Premium Aesthetics**: The login page features a sophisticated deep-navy and gold gradient background.

## 2. Dynamic Content Management
All administrative modules are now fully integrated with **Supabase Database** and **Storage**.

### 📸 Gallery Management
- **Direct Uploads**: You can now upload images directly from your computer. No URL pasting required.
- **Categorization**: Tag photos by category (Campus, Events, etc.) for organized display.
- **Instant Preview**: See your uploaded image immediately before saving.

### 👥 Faculty Management
- **Full Profiles**: Manage names, designations, departments, qualifications, and experience.
- **Photo Uploads**: Upload profile pictures for faculty members using the dedicated storage bucket.
- **Interactive Editing**: A new modal-based interface allows for quick updates and deletions.

### 📢 Notice Board
- **Heading & Text**: Notices now support a distinct title and a detailed content body.
- **Pinned Notices**: Use the "Pin" feature to keep critical announcements at the top of the list.
- **Dynamic Date**: Automatically records the publication date for chronological sorting.

### 📰 News & Campus Buzz
- **New Module**: A dedicated section to manage college news stories.
- **Media Rich**: Supports both image uploads for the news card and **PDF uploads** for detailed reports.
- **Home Page Sync**: The home page "Campus Buzz" section now automatically pulls the latest 3 stories from the database.

## 3. Deployment Automation
To ensure every update is pushed safely and quickly, use the new deployment script.

### Using `deploy.ps1`
1. Open PowerShell in the project root.
2. Run `./deploy.ps1`.
3. The script will:
   - Check and install dependencies if missing.
   - Run a production build check to catch errors.
   - Deploy the site to Vercel production.
   - Provide the live site URL upon success.

---

> [!TIP]
> **Data Persistence**: All changes made in the Admin panels are saved directly to your Supabase instance. Ensure your Supabase Storage buckets (`images` and `documents`) are configured with public access for media to render correctly.

> [!IMPORTANT]
> **Branding Consistency**: The official nomenclature "S.K. Degree & P.G. College" is now enforced project-wide across all metadata, UI labels, and dashboard stats.
