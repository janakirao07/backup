# ClinicalML — Real Dataset Integration Walkthrough

## Summary
Transitioned the ClinicalML app from a **rule-based prototype** (hardcoded weights) to a **data-driven clinical ML system** trained on **104,909 real clinical records** across 2 public datasets. The system now runs 3 trained ML models entirely in the browser.

## What Changed

### 1. Python Training Pipeline (`training/train_models.py`)
- **Loads** diabetes (100K rows) and stroke (5.1K rows) datasets
- **Feature engineering**: harmonizes columns → 7 standardized features (age, gender, BMI, glucose, hypertension, CVD history, smoking)
- **Label assignment**: priority-based function maps clinical flags → 7 disease classes
- **Class balancing**: undersamples majority classes, oversamples minority  
- **Trains ensemble**: Random Forest (85.1%), Gradient Boosting (87.6%), MLP (83.6%)
- **Exports** 4 JSON files to `models/` (total 813 KB)

### 2. Browser Inference Engine (`js/ml-models.js`) — **NEW**
- Tree traversal for RF and GB (walks JSON-serialized decision trees)
- Matrix multiply + ReLU + softmax for MLP forward pass
- Weighted ensemble: GB(40%) + RF(35%) + DNN(25%)
- Zero external dependencies — pure JavaScript

### 3. Updated ML Engine (`js/ml-engine.js`)
- `predict()` now calls real models instead of simulated ones
- Stage 1 (classification) = real trained models
- Stage 2 (drug/diet recommendations) = unchanged rule-based engine
- Added Stroke cases to drug and diet `switch` statements

### 4. Data Updates
- `js/data.js`: Added **Stroke** as 7th disease class
- `js/data_computed.js`: Auto-generated real correlation matrix + feature importance from training data  
- `js/charts.js`: Uses computed correlation/importance when available
- `index.html`: Added Stroke sample button, new script tags, cache busters

## Test Results

| Sample Patient | Predicted Class | Confidence | Correct? |
|---|---|---|---|
| 🧠 Stroke | Stroke | 52.2% | ✅ |
| ✅ Healthy | Healthy (Control) | 93.5% | ✅ |
| 🩸 T2DM | Type 2 Diabetes | 57.8% | ✅ |
| 💓 Hypertension | (not tested) | — | — |
| 🫀 CVD | (not tested) | — | — |

## Model Performance

| Model | Accuracy | F1 Score |
|---|---|---|
| Random Forest | 85.1% | 0.832 |
| Gradient Boosting | 87.6% | 0.870 |
| MLP (DNN) | 83.6% | 0.814 |

## Architecture

```
[Kaggle Datasets] → [Python trainer] → [JSON model files]
                                            ↓
[Browser] ← [ml-models.js loads JSON] ← [models/*.json]
     ↓
[ml-engine.js] → Stage 1: Real inference (RF+GB+MLP ensemble)
     ↓
[ml-engine.js] → Stage 2: Rule-based drug/diet recommendations
     ↓
[ui.js] → Renders results, charts, EDA with real data
```
