# Migrate Job Tracker to Next.js + TypeScript + React Three Fiber

## Current State Analysis

Your project is a **production-grade** application with significant complexity:

| Component | File | Lines | Complexity |
|---|---|---|---|
| Dashboard App | `app.js` | **2,990** | Auth, CRUD, AI Blaze, Kanban, Resume, Export, Settings |
| Chrome Extension Sidebar | `content.js` | **3,121** | Job extraction (10+ job boards), sidebar UI, AI, offline queue |
| Dashboard HTML + CSS | `app.html` + `app.css` | **2,573 + 1,100** | Full design system, 10+ pages |
| Landing Page | `landing.html` | **1,374** | Hero, Bento grid, testimonials, mockups |
| Extension Popup | `popup.js` + `popup.html` | **330** | Quick-action popup |
| Background Worker | `background.js` | **180** | Message relay, proxy fetch |
| Resume Engine | `resume-engine.js` | **600** | DOCX generation |
| Libraries | `docx-bundle.js`, `xlsxbuilder.js`, `FileSaver.min.js` | **750K+** | Third-party |
| **Total** | | **~10,000+ lines of custom code** | |

### Architecture Dependencies
- **Supabase** — Auth (email/password), PostgreSQL database, RLS
- **Chrome Extension APIs** — `chrome.storage`, `chrome.runtime`, content scripts, background service worker
- **Gemini API** — Job extraction, AI Blaze chat, resume generation, ATS scoring
- **Vercel** — Static hosting (currently no build step)
- **PWA** — Service worker, manifest, offline caching

---

## User Review Required

> [!CAUTION]
> **This is a MASSIVE migration** — not an incremental upgrade. Here's the honest reality:

### Scope & Effort

| Metric | Estimate |
|---|---|
| **Total files to create** | ~80–120 new TypeScript/React files |
| **Lines of code to rewrite** | ~10,000+ (everything) |
| **Estimated dev time** | **3–6 weeks** for an experienced developer |
| **Risk level** | 🔴 **HIGH** — production app with real users |

### Critical Tradeoffs

| Concern | Impact |
|---|---|
| **Chrome Extension stays vanilla JS** | Extensions CAN'T use Next.js natively — content scripts & background workers must remain as-is (or use a separate Vite+React build) |
| **Two separate build pipelines** | Website = Next.js on Vercel, Extension = Vite/Webpack → Chrome Web Store |
| **Current deployment is zero-build** | You currently just push HTML files. Next.js requires `npm run build` |
| **Supabase auth must be fully re-integrated** | Need `@supabase/supabase-js` + `@supabase/auth-helpers-nextjs` |
| **3D is the easiest part** | React Three Fiber is a drop-in; the hard part is migrating 3,000 lines of app logic |

> [!WARNING]
> **Breaking change:** The Chrome extension currently loads `app.html` as its options page and your website serves the same file from Vercel. With Next.js, these are server-rendered React pages — the extension cannot load Next.js pages as `options_page`. You'd need to either:
> 1. Keep a separate vanilla `options.html` for the extension
> 2. Point the extension's options page to your Vercel URL
> 3. Build a separate React SPA for the extension using Vite

---

## Recommended Approach: Phased Migration

Rather than rewriting everything at once, I recommend a **3-phase approach**:

### Phase 1: Add 3D to Current Landing Page (1–2 days) ✅ LOW RISK
Enhance your existing `landing.html` / `index.html` with Three.js 3D effects **without changing the architecture**. This gives you the visual wow-factor immediately.

**What changes:**
- Add Three.js 3D hero section to the existing landing page
- Add scroll-triggered 3D animations (GSAP)
- Add particle effects, floating device mockups
- Keep everything else unchanged

**What stays the same:**
- Dashboard, extension, auth, Supabase — all untouched
- No build step changes
- No risk to production

---

### Phase 2: Migrate Website to Next.js (1–2 weeks) 🟡 MEDIUM RISK
Rebuild only the **web dashboard** (not the extension) in Next.js + TypeScript.

**New project structure:**
```
job-tracker-nextjs/          ← NEW Next.js project
├── src/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx              ← 3D Landing page
│   │   ├── dashboard/
│   │   │   ├── page.tsx          ← Dashboard home
│   │   │   ├── applications/     ← Apps list + Kanban
│   │   │   ├── ai-blaze/         ← AI Blaze chat
│   │   │   ├── jobs/             ← Job Search
│   │   │   ├── settings/         ← Settings
│   │   │   ├── export/           ← Export
│   │   │   └── layout.tsx        ← Sidebar + topbar shell
│   │   └── auth/
│   │       ├── login/page.tsx
│   │       └── signup/page.tsx
│   ├── components/
│   │   ├── 3d/                   ← React Three Fiber scenes
│   │   │   ├── HeroScene.tsx
│   │   │   ├── FloatingScreens.tsx
│   │   │   └── AuroraOrbs.tsx
│   │   ├── ui/                   ← Reusable UI components
│   │   │   ├── Button.tsx
│   │   │   ├── Modal.tsx
│   │   │   ├── StatCard.tsx
│   │   │   ├── StatusBadge.tsx
│   │   │   └── Toast.tsx
│   │   ├── dashboard/
│   │   │   ├── Sidebar.tsx
│   │   │   ├── Topbar.tsx
│   │   │   ├── AppTable.tsx
│   │   │   ├── KanbanBoard.tsx
│   │   │   └── DetailModal.tsx
│   │   └── ai-blaze/
│   │       ├── BlazeChat.tsx
│   │       ├── QuickActions.tsx
│   │       └── ResponseCard.tsx
│   ├── lib/
│   │   ├── supabase.ts           ← Supabase client
│   │   ├── auth.ts               ← Auth helpers
│   │   ├── gemini.ts             ← Gemini API wrapper
│   │   ├── resume-engine.ts      ← Resume generation
│   │   └── types.ts              ← TypeScript types
│   ├── hooks/
│   │   ├── useAuth.ts
│   │   ├── useApplications.ts
│   │   └── useTheme.ts
│   └── styles/
│       └── globals.css
├── public/
│   ├── icons/
│   └── models/                   ← 3D .glb models (if any)
├── next.config.ts
├── tailwind.config.ts
├── tsconfig.json
└── package.json
```

**Key migrations:**
1. Auth → `@supabase/auth-helpers-nextjs` with middleware
2. App state → React hooks + context (or Zustand)
3. Routing → Next.js App Router (`/dashboard`, `/dashboard/ai-blaze`, etc.)
4. CSS → Tailwind CSS + CSS Modules for complex components
5. 3D → React Three Fiber + Drei for landing page hero
6. Build → `next build` → Vercel (auto-detected)

---

### Phase 3: Modernize Chrome Extension (1–2 weeks) 🟡 MEDIUM RISK
Rebuild the extension with Vite + React + TypeScript as a **separate project**.

```
job-tracker-extension/       ← SEPARATE Vite project
├── src/
│   ├── popup/
│   │   ├── Popup.tsx
│   │   └── popup.html
│   ├── sidebar/              ← Content script UI
│   │   ├── Sidebar.tsx
│   │   └── sidebar.css
│   ├── background/
│   │   └── background.ts
│   ├── content/
│   │   ├── extractor.ts     ← Job extraction logic
│   │   └── content.ts
│   └── lib/
│       ├── supabase.ts
│       └── gemini.ts
├── manifest.json
├── vite.config.ts
└── package.json
```

---

## Open Questions

> [!IMPORTANT]
> **I need your input before proceeding:**

1. **Which phase do you want to start with?**
   - **Phase 1 only** (add 3D to current landing page — quick win, no risk)
   - **Phase 1 + 2** (3D landing + full Next.js migration)
   - **All 3 phases** (complete rewrite of everything)

2. **Separate repos or monorepo?**
   - The Next.js website and Chrome extension will need **separate build pipelines**. Should they live in the same repo (monorepo with Turborepo) or separate GitHub repos?

3. **Styling preference?**
   - **Tailwind CSS** (fast, utility-first)
   - **Keep vanilla CSS** (more control, what you have now)
   - **CSS Modules** (scoped, no conflicts)

4. **Are you comfortable with the timeline?**
   - Phase 1: 1–2 days
   - Phase 2: 1–2 weeks
   - Phase 3: 1–2 weeks
   - This assumes focused, full-time work

5. **Do you want to keep the current site running while migrating?**
   - I'd recommend keeping `job-tracker-app` live and building `job-tracker-nextjs` in a new branch or folder, then switching Vercel once ready

---

## Verification Plan

### Automated Tests
- Run `npm run build` to verify Next.js compiles
- Run `npx tsc --noEmit` for TypeScript type checking
- Test Supabase auth flow in browser
- Verify 3D scenes render with React Three Fiber

### Manual Verification
- Test all dashboard pages (Dashboard, Applications, AI Blaze, Job Search, Settings, Export, Privacy, About)
- Test light/dark theme toggle
- Test mobile responsive layout
- Test Chrome extension ↔ dashboard sync
- Verify Vercel deployment works with Next.js
