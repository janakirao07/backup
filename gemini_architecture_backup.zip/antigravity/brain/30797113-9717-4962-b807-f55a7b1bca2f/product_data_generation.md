# Implementation Plan - Bulk Product Data Generation

The goal is to provide SQL queries to reset the `products` table and populate it with 100 diverse product records for the BSR Shopping Mall.

## 1. SQL Delete Query
- Use `DELETE FROM products;` to clear existing data.

## 2. Product Data Generation Strategy
I will generate 100 products distributed across:
- **Categories**: Men (35), Women (40), Kids (25)
- **Brands**: Raymond, Peter England, Manyavar, BSR Exclusive, W, Allen Solly, Disney, Hopscotch, US Polo, Levi's, Puma, Adidas, Nike, BIBA, FabIndia, Aurelia, Louis Philippe, Van Heusen.
- **Subcategories**: 
  - Men: Formal Shirts, Casual Shirts, Chinos, Jeans, Kurtas, Blazers, Polos.
  - Women: Silk Sarees, Cotton Sarees, Anarkalis, Midi Dresses, Crop Tops, Palazzo Suits.
  - Kids: Graphic Tees, Frocks, Boys Suits, Ethnic Wear, Dungarees.

## 3. Delivery
- Provide the SQL code block directly to the user for execution in the Supabase SQL Editor.
