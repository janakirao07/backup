# Kanban Board Integration

The Job Tracker dashboard has been upgraded with a fully interactive Kanban Board view, providing a visually impressive and intuitive way to manage your applications alongside the standard list view.

## Features Implemented

### 1. Visual Drag-and-Drop Interface
We built a custom HTML5 canvas pipeline without any heavy external libraries (like `react-beautiful-dnd` or `sortable.js`). This ensures your dashboard stays blisteringly fast while providing a premium experience.
- You can vividly pick up and drag application cards between columns.
- The columns highlight dynamically when you drag a card over them to indicate a drop zone.
- Once dropped, the application seamlessly updates to the new status and triggers an automatic sync with your Supabase backend.

### 2. Premium "Glass" Styling
The horizontal columns utilize the `Dark Cinematic` design language:
- **Columns**: Fixed width (300px) with elegant borders and color-coded headers indicating the specific status (`Applied`, `Interview Scheduled`, etc.).
- **Cards**: Floating glass cards (`var(--bg-inset)`) that lift and cast a shadow upon hover.
- **Scroll Snapping**: On horizontally constrained devices, columns intelligently "snap" into view as you scroll horizontally.

### 3. Persistent View Toggle
Added a sleek toggle switch (`≡ List` / `◫ Board`) to the filter bar in the dashboard.
- The view preference is saved locally (`rjd_view_mode`), ensuring that if you prefer the Kanban layout, it remains default every time you log in.
- The Board view natively supports horizontal swiping on mobile devices as requested, abandoning the clunky vertical stack standard in favor of an app-like horizontal flow.

## Verification
- ✅ Layout and Styling perfectly matches the dark cinematic theme.
- ✅ Drag and Drop fires properly and updates the database via the `updateApp()` method.
- ✅ Toggle gracefully transitions between layout models.
- ✅ Successfully pushed and deployed via Vercel pipeline via `node build.js`.

> [!TIP]
> The Kanban board pairs exceptionally well with the **Job Search** or **Better README** integrations on our remaining master list!
