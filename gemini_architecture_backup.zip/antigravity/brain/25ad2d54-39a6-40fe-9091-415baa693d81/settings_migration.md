# Database Migration: Settings Persistence

## Objective
Enable persistence for store settings managed in the Admin Dashboard.

## SQL Migration
```sql
-- Create settings table
CREATE TABLE IF NOT EXISTS public.settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_name TEXT DEFAULT 'BSR Shopping Mall',
    store_email TEXT DEFAULT 'bsrshoppingmall@gmail.com',
    store_phone TEXT DEFAULT '+91 78293 33444',
    store_address TEXT DEFAULT 'Main Road, Sompeta, Srikakulam Dist, AP - 532284',
    whatsapp_number TEXT DEFAULT '917829333444',
    announcement_text TEXT,
    announcement_active BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Enable RLS
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;

-- Public read access
CREATE POLICY "Allow public read access" ON public.settings
    FOR SELECT USING (true);

-- Admin write access (authenticated users)
CREATE POLICY "Allow admin write access" ON public.settings
    FOR ALL USING (auth.role() = 'authenticated');

-- Insert default settings row if not exists
INSERT INTO public.settings (id)
SELECT '00000000-0000-0000-0000-000000000000'::UUID
WHERE NOT EXISTS (SELECT 1 FROM public.settings LIMIT 1);
```

## Impact Radius
- `AdminSettingsPage`: Will now fetch and save data to Supabase.
- `Footer`, `Navbar`, `WhatsAppWidget`: Can potentially fetch live settings instead of using environment variables or hardcoded fallbacks.
