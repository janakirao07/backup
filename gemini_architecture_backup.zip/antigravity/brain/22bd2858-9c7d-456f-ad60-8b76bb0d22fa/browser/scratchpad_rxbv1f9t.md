# Task: Preview Faculty Page

## Checklist
- [x] Navigate to http://localhost:3000/faculty
- [x] Wait 5 seconds for animations
- [x] Capture initial viewport/hero section (captured error overlay)
- [ ] Scroll down to faculty grid
- [ ] Capture faculty grid and sidebar
- [ ] Analyze findings (3D particles, text reveals, cards grid, sidebar)

### Findings
- Persistent runtime error in `app/layout.tsx`: `supabase.auth.onAuthStateChange is not a function`.
- This error blocks the entire application from rendering.
- Bypassing the error via reload only works temporarily before it crashes again.
- Hydration mismatches were also observed initially.
- Unable to preview the 3D particles or animated text due to the application crash.
