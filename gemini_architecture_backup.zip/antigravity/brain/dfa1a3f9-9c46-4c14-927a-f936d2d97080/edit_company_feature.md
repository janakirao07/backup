# Implementation Plan - Edit Company Name & Job Title

The user wants to be able to edit the company name in both the extension sidebar and the dashboard app. I will also add the ability to edit the job title for completeness.

## Proposed Changes

### Extension Sidebar (`src/scripts/content.js`)
- Update the HTML structure of the `rjd-detail-panel` within `renderTrackerScreen` to replace static company and title displays with input fields.
- Update `showAppDetail` to populate these input fields when an application is selected.
- Update the event listener for `rjd-save-notes-btn` (which serves as the general save button for the detail panel) to include `company` and `jobTitle` in the update.
- Rename "Save Notes" button to "Save Changes" for better clarity.

### Dashboard App (`src/scripts/app.js`)
- Update `openDetailModal` to replace the static header text (`detail-modal-title` and `detail-modal-sub`) with input fields if they exist, or just make them editable. Looking at the code, I can change them to inputs.
- Update the save button listener (`detail-modal-save`) to read values from these new input fields and include them in the `updateApp` call.

## Verification Plan

### Manual Verification
1. Open the extension sidebar.
2. Click on an existing application to open the detail panel.
3. Edit the Company name and Job Title.
4. Click "Save Changes".
5. Verify the table updates instantly.
6. Open the Dashboard app.
7. Click on an application to open the modal.
8. Edit the Company and Title.
9. Click "Save Changes".
10. Verify the dashboard table updates.
