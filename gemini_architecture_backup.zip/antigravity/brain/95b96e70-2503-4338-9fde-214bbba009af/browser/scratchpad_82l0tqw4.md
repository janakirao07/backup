# GitHub Repository Check: janakirao4701/resume_maker_word

## Status of 'resume-builder-app' folder:
- **Exists**: Yes

## List of folders/files in root directory:
1. `resume-builder-app` (Directory)
2. `resume-builder-extension` (Directory)
3. `Venkata_Vinay_Resume.docx` (File)
4. `Venkata_vinay_vamsi_yeddula_resume.pdf` (File)
5. `Vinay_Resume_Builder_OFFLINE.html` (File)
6. `profiles_schema.sql` (File)
7. `resume_maker.html` (File)
