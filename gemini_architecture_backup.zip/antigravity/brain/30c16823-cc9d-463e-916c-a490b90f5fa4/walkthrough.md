# Walkthrough — Gemini API & Icon Path Fixes

I have fixed the Gemini API "model not found" error and resolved the missing icons across the extension and dashboard.

## Changes Made

### 1. Gemini API Endpoint
Updated the extraction logic in `content.js` to use the stable `v1` endpoint. This addresses the error where `gemini-1.5-flash` was not recognized on the `v1beta` channel for some users.

#### [MODIFY] [content.js](file:///c:/Users/janak/job-tracker-app/src/scripts/content.js)
```diff
- 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' + GEMINI_KEY,
+ 'https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=' + GEMINI_KEY,
```

### 2. Dashboard Icon Paths
Corrected multiple broken image references in the authentication and logo sections of the dashboard files.

#### [MODIFY] [index.html](file:///c:/Users/janak/job-tracker-app/index.html)
Fixed root-level paths that were incorrectly using `../`.
```diff
- <img src="../icons/icon48.png" .../>
+ <img src="public/icons/icon48.png" .../>
```

#### [MODIFY] [app.html](file:///c:/Users/janak/job-tracker-app/src/pages/app.html)
Fixed nested paths to point to the correct depth in the project root.
```diff
- <img src="../icons/icon48.png" .../>
+ <img src="../../public/icons/icon48.png" .../>
```

### 3. Extension Toggle Icon
Ensured the floating toggle button in the extension uses an absolute extension path for its icon, preventing resource resolution issues in injected contexts.

#### [MODIFY] [content.js](file:///c:/Users/janak/job-tracker-app/src/scripts/content.js)
```diff
- chrome.runtime.getURL('public/icons/icon128.png')
+ chrome.runtime.getURL('/public/icons/icon128.png')
```

## Verification Results

### Gemini API
The endpoint is now using the current stable version for `gemini-1.5-flash`, which is compatible with all standard API keys and regions.

### Icon Accessibility
All icon paths have been mapped to their actual locations in `public/icons/`.
- Root pages now correctly reach `public/`.
- Nested pages (in `src/pages/`) now correctly reach `../../public/`.
- The extension toggle now uses an absolute path and is listed in `web_accessible_resources`.

> [!NOTE]
> Please refresh your browser tabs or reload the extension in `chrome://extensions` to see the changes take effect.
