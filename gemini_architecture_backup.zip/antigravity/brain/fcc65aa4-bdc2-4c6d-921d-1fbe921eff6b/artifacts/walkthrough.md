# Local-Only Interactive Deployment Walkthrough

I have replaced your basic deployment script with a more professional, local-only tool that automates your entire workflow while giving you more control.

## Changes Made

### 1. New Interactive Script
- [x] **[local-deploy.ps1](file:///c:/Users/janak/job-tracker-app/local-deploy.ps1)**: A new PowerShell script that:
    1.  **Builds & Syncs:** Updates `index.html` from `src/pages/app.html`.
    2.  **Packages:** Automatically recreates a fresh `production.zip` for the Chrome Store.
    3.  **Core Check:** Shows you exactly which files are being pushed.
    4.  **Custom Commits:** Prompts you to type a commit message for every push.

### 2. Guardrails (.gitignore)
- [x] **Exclusion:** Added `local-deploy.ps1` to `.gitignore`. This tool will live only on your machine and will not be visible on GitHub.

### 3. Cleanup
- [x] **Legacy Removal:** Deleted the old `deploy.ps1` to prevent confusion.

## How to use it:
To deploy your core changes and update your live site, simply run:
```powershell
.\local-deploy.ps1
```
The script will walk you through the process, and you can just type your commit message when prompted!

Your development environment is now fully automated and your public repository remains clean. 🚀
