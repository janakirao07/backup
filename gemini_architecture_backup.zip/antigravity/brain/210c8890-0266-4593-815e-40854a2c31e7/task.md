# Kanban View Integration

- [x] Add CSS for the Kanban Board layout and Glass cards to `src/pages/app.html`
- [x] Add `rjd_view_mode` state to `src/scripts/app.js`
- [x] Add a visual toggle switch (List | Board) to the UI in `renderApplications()`
- [x] Build the Board View rendering logic in `renderApplications()`
- [x] Implement HTML5 Drag and Drop events (`ondragstart`, `ondragover`, `ondrop`)
- [x] Connect the `ondrop` event to update the application status in Supabase and trigger a re-render
- [x] Verify functionality and test the deployment
