# Task: Debug Resume Template Preview in Dashboard

## Progress:
- [ ] Open Job Tracker Dashboard
- [ ] Navigate to Settings > Resume Profile
- [ ] Click "Preview Selected Style" button
- [ ] Observe behavior and errors
- [ ] Fix or report findings

## Notes:
- Attempted to open `file:///c:/Users/janak/job-tracker-app/index.html` but it was blocked.
- Need to find the correct URL or a way to access the local dashboard.
