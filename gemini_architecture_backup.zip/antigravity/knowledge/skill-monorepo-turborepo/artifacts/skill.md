# Turborepo

## turbo.json
```json
{
  "pipeline": {
    "build": { "dependsOn": ["^build"], "outputs": [".next/**", "dist/**"] },
    "lint": {},
    "dev": { "cache": false, "persistent": true }
  }
}
```

## Packages structure
- `apps/web` (Next.js)
- `apps/api` (Express)
- `packages/ui` (Shared React components)
- `packages/config` (Shared ESLint/TS configs)