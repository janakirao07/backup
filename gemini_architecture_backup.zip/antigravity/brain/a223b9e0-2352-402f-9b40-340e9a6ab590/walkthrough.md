# Gemini 2.5 & Ollama Integration Complete

I have successfully updated the **Job Application Tracker** with the latest Gemini 2.5 models and added full support for local **Ollama** models.

## Key Changes

### 1. Gemini 2.5 Upgrade
- The cloud extraction engine now defaults to **Gemini 2.5 Flash Lite** for faster and more efficient parsing.
- **Gemini 2.5 Flash** and **Gemini 2.5 Flash Lite** have been added to the Ai-Blaze provider list.

### 2. Local Ollama Support
- Added a new **Ollama (Local AI)** provider to Ai-Blaze.
- You can now use your local `llama3.2` model (or any other Ollama model) for:
    - Generating cover letters and answers.
    - Extracting job application details from the clipboard.
- **Privacy First**: All Ollama requests are sent to your local machine (`http://localhost:11434`), ensuring your data never leaves your computer.

### 3. Integrated Settings UI
- **Extraction Engine Toggle**: In the extension settings (sidebar), you can now toggle between **Gemini 2.5** and **Ollama Local** for your extractions.
- **Ollama Configuration**: In the main dashboard settings, you can now configure your local Ollama URL and default model name.

## How to Test

### Using Ollama
1.  Ensure Ollama is running on your computer (`ollama serve`).
2.  Open the Tracker Settings and ensure the **Ollama URL** is set to `http://localhost:11434` and the **Model Name** is `llama3.2`.
3.  In the Sidebar (Extension), go to **Settings → API Key** and select **Ollama Local** as your extraction engine.
4.  Copy a job description to your clipboard and click **Extract**.

### Using Gemini 2.5
- Simply use the extraction or Ai-Blaze as usual; it will now utilize the **Gemini 2.5** series by default for cloud requests.

## Verification Results
- [x] Verified `gemini-2.5-flash-lite` fetch URL in `content.js`.
- [x] Verified `ollama` provider logic in `app.js`.
- [x] Verified UI toggles and settings inputs correctly save to `localStorage`.

Successfully integrated Gemini 2.5 and Ollama! 🚀
