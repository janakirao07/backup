# Data Visualization

## Matplotlib (Publication Quality)
```python
import matplotlib.pyplot as plt
import numpy as np

fig, ax = plt.subplots(figsize=(10, 6))
ax.plot(x, y, color='#6366f1', linewidth=2, label='Revenue')
ax.fill_between(x, y, alpha=0.1, color='#6366f1')
ax.set_xlabel('Month', fontsize=12)
ax.set_ylabel('Revenue ($)', fontsize=12)
ax.set_title('Monthly Revenue', fontsize=16, fontweight='bold')
ax.legend(frameon=False)
ax.spines[['top', 'right']].set_visible(False)
plt.tight_layout()
plt.savefig('chart.png', dpi=300, bbox_inches='tight')
```

## Seaborn (Statistical Plots)
```python
import seaborn as sns
sns.set_theme(style="whitegrid", palette="muted")

# Distribution
fig, axes = plt.subplots(1, 3, figsize=(15, 5))
sns.histplot(df['price'], kde=True, ax=axes[0])
sns.boxplot(x='category', y='price', data=df, ax=axes[1])
sns.violinplot(x='category', y='price', data=df, ax=axes[2])

# Correlation heatmap
sns.heatmap(df.corr(), annot=True, cmap='coolwarm', center=0, fmt='.2f')

# Pairplot (scatter matrix)
sns.pairplot(df, hue='category', diag_kind='kde')

# Categorical
sns.catplot(x='day', y='total_bill', hue='sex', kind='bar', data=tips)
```

## Plotly (Interactive)
```python
import plotly.express as px
import plotly.graph_objects as go

# Quick interactive charts
fig = px.line(df, x='date', y='value', color='category', title='Trends')
fig.update_layout(template='plotly_dark', hovermode='x unified')
fig.show()

# Scatter with size and color
fig = px.scatter(df, x='gdp', y='life_exp', size='pop', color='continent',
    hover_name='country', size_max=60, template='plotly_white')

# Subplots
from plotly.subplots import make_subplots
fig = make_subplots(rows=2, cols=2, subplot_titles=['A', 'B', 'C', 'D'])
fig.add_trace(go.Bar(x=x, y=y), row=1, col=1)
fig.add_trace(go.Scatter(x=x, y=y2), row=1, col=2)
fig.update_layout(height=600, showlegend=False)
```

## Chart.js (Web)
```html
<canvas id="myChart"></canvas>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
new Chart(document.getElementById('myChart'), {
  type: 'line',
  data: {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May'],
    datasets: [{
      label: 'Applications',
      data: [12, 19, 8, 15, 22],
      borderColor: '#6366f1',
      backgroundColor: 'rgba(99, 102, 241, 0.1)',
      fill: true,
      tension: 0.4,
    }]
  },
  options: {
    responsive: true,
    plugins: { legend: { display: false } },
    scales: { y: { beginAtZero: true } }
  }
});
</script>
```

## Chart Selection Guide
| Data Type | Best Chart |
|-----------|-----------|
| Trend over time | Line chart |
| Comparison | Bar chart (vertical/horizontal) |
| Composition | Pie/Donut (≤5 categories), Stacked bar |
| Distribution | Histogram, Box plot, Violin |
| Correlation | Scatter plot, Heatmap |
| Ranking | Horizontal bar |
| Part-to-whole | Treemap, Sunburst |
| Geographic | Choropleth map |

## Color Palettes
```python
# Professional palettes
corporate = ['#6366f1', '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444']
pastel = ['#c7d2fe', '#ddd6fe', '#a5f3fc', '#a7f3d0', '#fde68a', '#fecaca']
dark_mode = ['#818cf8', '#a78bfa', '#22d3ee', '#34d399', '#fbbf24', '#f87171']
```
