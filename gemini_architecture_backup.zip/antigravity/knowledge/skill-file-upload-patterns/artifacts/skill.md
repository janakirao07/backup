# File Uploads

## Presigned URL (AWS S3)
```ts
// Server
const url = await s3Client.getSignedUrlPromise('putObject', { Bucket: 'b', Key: 'file.jpg' });

// Client
await fetch(url, { method: 'PUT', body: file, headers: { 'Content-Type': file.type } });
```