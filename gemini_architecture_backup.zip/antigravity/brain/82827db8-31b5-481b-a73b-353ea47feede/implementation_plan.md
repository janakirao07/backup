# Implementation Plan - Universal Resume Pro Cleanup & Polish

The current `pages/resume_maker.html` is corrupted with duplicate body tags and conflicting styles. I will consolidate it into a single, premium, Glassmorphism-themed tool that allows you to manage your profile and generate tailored resumes instantly.

## User Review Required

> [!IMPORTANT]
> I will be overwriting `pages/resume_maker.html` with a cleaned-up, single-file version. I will use the **Glassmorphism** aesthetic from your first attempt as it looks more premium. I will also ensure the `docx` library is properly structured so it doesn't break the HTML.

- **Sidebar Integration**: Add a "Resume Pro" link to the `index.html` sidebar for easy access.

---

## Proposed Changes

### [Resume Builder UI & Logic]

#### [MODIFY] [resume_maker.html](file:///c:/Users/janak/job-tracker-app/pages/resume_maker.html)
- **Fix Structure**: Remove duplicate `<html>`, `<head>`, and `<body>` tags.
- **Consolidate Styles**: Use the modern dark-mode Glassmorphism theme with Indigo/Violet accents.
- **Profile Management**: 
    - Full Name, Title, Email, Phone, Location, LinkedIn.
    - Multi-line fields for Education and Certifications.
    - All fields will auto-save to `localStorage`.
- **Tailored Content Engine**:
    - Paste area for Claude-generated content.
    - Real-time detection of `[SUMMARY]`, `[SKILLS]`, and `[EXPERIENCE]` sections.
- **Generation Engine**:
    - Properly embed the `docx` library.
    - Create a professional Word document template (1-2 pages) that maps your profile + tailored content.

### [Sidebar Menu]

#### [MODIFY] [index.html](file:///c:/Users/janak/job-tracker-app/index.html)
- Add a new `nav-item` for "Resume Pro" under the "Manage" section.
- Ensure it links correctly to `pages/resume_maker.html`.

---

## Verification Plan

### Automated Tests
- I will use the browser tool to:
    1. Enter profile data and refresh the page to ensure it persists.
    2. Paste dummy content with tags and verify that the "Status Chips" turn green.
    3. Click "Download" and (if possible in this environment) verify the console shows no errors during `.docx` generation.

### Manual Verification
- You will need to click the "Download" button to verify the final Word document's formatting.
