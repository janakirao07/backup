# Implementation Plan — Final Visual Polish & Cache Purge

The user's mobile app might not be "showing like this" because of aggressive browser caching or a slight discrepancy in the PWA manifest. I will implement a "Force Update" strategy and refine the visual icons.

## User Review Required

> [!IMPORTANT]
> To see the changes on your phone, you may need to **refresh the page 2-3 times** or **close and reopen the browser tab**. This is because browsers "cache" the old version to save data.

## Proposed Changes

### [Fix: Force Updates]

#### [MODIFY] [sw.js](file:///c:/Users/janak/job-tracker-app/sw.js)
- Increment `CACHE_NAME` to `job-tracker-v3`.
- Implement a more aggressive "Claim Clients" logic to ensure the new version takes over immediately.

#### [MODIFY] [app.html](file:///c:/Users/janak/job-tracker-app/pages/app.html)
- Add versioning parameters to all static assets (`?v=2`) to bypass browser cache.
- Ensure the `viewport` meta tag is perfect for mobile "standalone" mode.
- Improve the mobile drawer's "Masking" (making it look even cleaner).

#### [MODIFY] [pwa-manifest.json](file:///c:/Users/janak/job-tracker-app/pwa-manifest.json)
- Update icon purposes to `any maskable` explicitly.
- Fix any potential path issues.

## Verification Plan

### Manual Verification
- I will use the browser tool to **Clear Site Data** and re-verify the "First Load" experience, ensuring it matches the modern "Pro" look in my screenshots.
- I will verify the hamburger menu icon color and visibility carefully.
