# Real Authentication — ClinicalML

Add production-grade authentication to the ClinicalML app using **Firebase Authentication** (email/password + Google OAuth). Firebase acts as a managed backend — no server code required, works perfectly with the existing static HTML/JS setup.

---

## User Review Required

> [!IMPORTANT]
> **Firebase project setup needed from you (one-time, ~3 minutes)**
> After I build all the code, you'll need to:
> 1. Go to [Firebase Console](https://console.firebase.google.com/) → Create a project → Add a web app
> 2. Enable **Email/Password** and **Google** sign-in providers
> 3. Paste your Firebase config keys into `js/firebase-config.js`
>
> I will leave clear placeholder comments so you know exactly where to paste them.

> [!NOTE]
> All actual user credentials (passwords, tokens) are managed entirely by Google's Firebase servers. The app only stores `displayName`, `email`, and `uid` in the browser session — same as any real medical platform.

---

## Proposed Changes

### 1. Firebase Auth Module

#### [NEW] `js/firebase-config.js`
Holds your Firebase project config. You paste your keys here after creating a Firebase project.

#### [NEW] `js/auth.js`
Core auth logic:
- `signUp(email, password, name)` — register new user
- `signIn(email, password)` — login
- `signInWithGoogle()` — Google OAuth one-click login
- `signOut()` — logs out and redirects to `login.html`
- `onAuthStateChanged` observer — auto-redirects unauthenticated users

---

### 2. Login / Register Page

#### [NEW] `login.html`
A stunning, glassmorphism-styled standalone page with:
- **Login tab** — email + password fields
- **Register tab** — name + email + password + confirm password
- **"Sign in with Google"** button (one-click OAuth)
- Animated particle background (matching the main app)
- Show/hide password toggle
- Real-time error messages (wrong password, user not found, etc.)
- Auto-redirect to `index.html` if already logged in

---

### 3. Auth Guard on Main App

#### [MODIFY] `index.html`
- Add `<script src="js/firebase-config.js">` and `<script src="js/auth.js">` at top
- Auth guard: if Firebase reports no user → redirect to `login.html`
- **User info in navbar**: avatar/initial bubble + user's name + **Logout** button

#### [MODIFY] `css/styles.css`
- Add styles for login page: auth card, tabs, Google button, input states
- Add styles for navbar user chip (avatar + name + logout)

---

## Auth Flow Diagram

```
User visits index.html
       │
       ▼
Firebase onAuthStateChanged
       │
   ┌───┴───┐
Not Logged In   Logged In
       │              │
       ▼              ▼
  login.html     Show App  ←── nav shows name + logout
       │
  ┌────┴────┐
Login    Register
  │           │
  ▼           ▼
Firebase   Firebase
signIn   createUser
       │
       ▼
  index.html (protected)
```

---

## Features Summary

| Feature | Details |
|---|---|
| Email/Password Login | Real Firebase auth, tokens managed by Google |
| Google OAuth | One-click sign-in with Google account |
| Auth Guard | `index.html` redirects to `login.html` if not logged in |
| Persistent Session | Firebase persists session across browser closes |
| Navbar User Info | Shows logged-in user's name + avatar initial + logout button |
| Error Handling | Friendly messages for wrong password, email taken, etc. |
| Password Visibility Toggle | Show/hide password in both login and register |

---

## Open Questions

> [!IMPORTANT]
> **Do you want Google "Sign in with Google" OAuth button** in addition to email/password?
> I'll include it by default — let me know if you want email/password only.

> [!NOTE]
> **Role-based access (Doctor / Researcher / Admin)?**
> If not needed now, I'll skip it — roles can be added later via Firestore user documents.

---

## Verification Plan

### Code Verification
- `login.html` opens correctly in browser
- Login, Register, and Google OAuth tabs work
- Auth guard on `index.html` redirects unauthenticated users
- Logged-in user's name appears in navbar
- Logout clears session and returns to `login.html`

### Firebase Console Verification
- New users appear in Firebase Console → Authentication → Users
- Auth tokens are issued correctly
