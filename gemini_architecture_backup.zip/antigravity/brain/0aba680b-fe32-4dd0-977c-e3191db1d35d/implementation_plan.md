# Custom Extraction Restrictions

This plan outlines the changes needed to allow users to specify "Excluded Companies" and "Job Description Rules" to prevent unwanted jobs from being extracted.

## User Review Required

> [!IMPORTANT]
> The AI will be instructed to identify if a job matches your exclusion rules. If matched, the extraction will stop and notify you with a warning.

## Proposed Changes

### [Component] Chrome Extension Context (content.js)

Summary: Update the sidebar settings UI to include "Extraction Rules" and modify the AI prompt to respect these rules.

#### [MODIFY] [content.js](file:///c:/Users/janak/job-tracker-app/src/scripts/content.js)

1.  **Settings Sidebar**:
    *   Add a new navigation item `🛠️ Extraction Rules` in `renderSettingsScreen`.
    *   Add a new section `extractionrules` in `renderSection` with two textareas:
        *   `Excluded Companies` (one per line).
        *   `JD Exclusion Rules` (e.g., "Exclude roles that require Java", "Only remote").
    *   Implement Save logic to `chrome.storage.local`.

2.  **Extraction Logic**:
    *   Update `extractWithGemini` and `extractWithOllama` to load these new settings.
    *   Inject the rules into the AI prompt under a new `RESTRICTIONS` section.
    *   Update the AI's output requirements to include an `is_excluded` field:
        *   `{"company_name": "...", "job_title": "...", "is_excluded": boolean, "exclusion_reason": "..."}`
    *   Handle the `is_excluded` flag in `runExtract` to show a toast message or warning.

### [Component] Storage and Utilities

*   Add `loadExtractionRules` and `saveExtractionRules` utilities (similar to `loadGeminiKey`).

## Open Questions

*   **Rule Type**: Should JD rules be fuzzy concepts (e.g., "Not for Juniors") or strict regex/keyword matches? (I'll aim for AI-powered fuzzy matching as it's more flexible).
*   **Excluded Result**: Should extracted text still show in the form even if it's "Excluded"? (Likely better to leave it empty or clear it if it matches).

## Verification Plan

### Automated Tests
- Test extraction on a page with an "Excluded Company".
- Test extraction on a JD matching a "JD Exclusion Rule".

### Manual Verification
- Go to Settings -> Extraction Rules.
- Add "Google" to excluded companies.
- Extract from a Google-related job.
- Verify exclusion message appears.
