# Implementation Plan: Restructure job-tracker-app

Fix the messy root directory by organizing source code, assets, and documentation into standard directories (`src`, `docs`). This improves maintainability and follows modern web development standards.

## User Review Required

> [!IMPORTANT]
> **Path Changes**: Moving files into `src/` will require updating `manifest.json`, `index.html`, and all internal file references in the HTML files.
> **Skills**: I will remove the redundant `skills/` folder in the root (these are symlinks) and keep the source of truth in `.agents/skills/`.
> **Documentation**: I will consolidate model-specific markdown files (`GEMINI.md`, `CLAUDE.md`, `AGENTS.md`) into a `docs/` folder.

## Proposed Changes

### [Component] File Organization

#### [NEW] [src/](file:///c:/Users/janak/job-tracker-app/src)
Create a `src/` directory to house all source code:
- `src/pages/` (HTML files)
- `src/scripts/` (JS files)
- `src/styles/` (CSS files)
- `src/lib/` (External dependencies)

#### [NEW] [docs/](file:///c:/Users/janak/job-tracker-app/docs)
Move existing model files and future documentation here:
- `docs/GEMINI.md`
- `docs/CLAUDE.md`
- `docs/AGENTS.md`

#### [DELETE] [skills/](file:///c:/Users/janak/job-tracker-app/skills)
Remove the redundant `skills/` symlink folder from the root.

---

### [Component] Root Configuration

#### [MODIFY] [manifest.json](file:///c:/Users/janak/job-tracker-app/manifest.json)
Update all resource paths to point to their new locations in `src/`.

#### [MODIFY] [index.html](file:///c:/Users/janak/job-tracker-app/index.html)
Update script and style tags to point to `src/`.

#### [MODIFY] [deploy.ps1](file:///c:/Users/janak/job-tracker-app/deploy.ps1)
Update the deployment script to reflect the new structure (e.g., sync `src/pages/app.html` to `index.html`).

#### [NEW] [package.json](file:///c:/Users/janak/job-tracker-app/package.json)
Initialize a standard `package.json` with project metadata and scripts.

## Open Questions

- **Service Worker Location**: Currently `sw.js` is in the root. For PWA scope, it's often best to keep it in the root. Do you want it moved to `src/` or kept in the root?
- **Root Manifest**: Should `pwa-manifest.json` stay in the root or move to a `public/` directory? (I suggest keeping it root for now to avoid complex path issues with PWA installs).

## Verification Plan

### Manual Verification
- Load `index.html` in a local browser and verify all assets/scripts load without 404s.
- Inspect the Chrome extension via `chrome://extensions` to ensure the manifest is still valid.
- Run `.\deploy.ps1` and verify that `index.html` is correctly updated.
