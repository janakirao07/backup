# OpenAI SDK

## Chat Completion
```ts
import OpenAI from 'openai';
const openai = new OpenAI();
const completion = await openai.chat.completions.create({
  messages: [{ role: 'user', content: 'Say hello' }],
  model: 'gpt-4o',
});
```

## Embeddings
```ts
const embedding = await openai.embeddings.create({
  model: 'text-embedding-3-small',
  input: 'The text',
});
```