---
name: web-master-stack
description: Master reference for building world-class websites — libraries, stacks, tools, and quality rules
---

# 🌐 Web Development Master Stack Reference

> The complete toolkit for building world-class websites in 2025-26.

---

## 🏗️ Core Framework
| Library | Purpose |
|---|---|
| **Next.js 14/15** | Best full-stack React framework |
| **TypeScript** | Type safety, scalability |
| **Tailwind CSS** | Utility-first styling |

---

## ✨ Animation & Motion
| Library | Purpose | Notes |
|---|---|---|
| **GSAP** | Industry standard animation engine | Used by Apple, Google, Netflix |
| **ScrollTrigger** | GSAP plugin for scroll animations | |
| **Framer Motion** | React-specific animations | Page transitions, gestures |
| **Lenis** | Buttery smooth scrolling | |
| **Theatre.js** | Professional animation sequencer | |
| **Auto Animate** | Automatic layout animations | |
| **Motion One** | Lightweight alternative to GSAP | |

---

## 🎮 3D & WebGL
| Library | Purpose | Notes |
|---|---|---|
| **Three.js** | Core 3D engine | |
| **React Three Fiber** | Three.js for React | |
| **@react-three/drei** | Three.js helpers & abstractions | |
| **Spline** | No-code 3D design for web | |
| **Babylon.js** | Alternative to Three.js | Better for games |
| **WebGL** | Low level graphics | Via Three.js |
| **GLSL Shaders** | Custom visual effects | |

---

## 🎨 Visual Effects & Creative
| Library | Purpose |
|---|---|
| **@react-three/postprocessing** | Bloom, depth of field, chromatic aberration |
| **tsParticles** | Advanced particle systems |
| **Lottie Web** | After Effects on web |
| **SVG.js** | SVG animations |
| **Rive** | Interactive animations (next level Lottie) |
| **Curtains.js** | WebGL on HTML elements (distortion effects) |
| **Pixi.js** | 2D WebGL renderer (canvas animations) |

---

## 🖥️ UI Component Libraries
| Library | Purpose | Notes |
|---|---|---|
| **Shadcn/ui** | Clean, customizable components | |
| **Radix UI** | Headless accessible components | |
| **Aceternity UI** | Advanced animated components | Most popular right now |
| **Magic UI** | Beautiful animated components | |
| **Cult UI** | Premium components | |
| **HyperUI** | Free Tailwind components | |
| **DaisyUI** | Tailwind component library | |
| **Headless UI** | Unstyled accessible components | |

---

## 🔤 Typography & Fonts
| Library | Purpose |
|---|---|
| **Google Fonts** | Free web fonts (Playfair, Lato, etc.) |
| **Fontsource** | Self-hosted Google Fonts (better performance) |
| **Variable Fonts** | Single font file, multiple weights |
| **Capsize** | Perfect font metrics/spacing |

---

## 🖼️ Image & Media
| Library | Purpose |
|---|---|
| **Next/image** | Automatic optimization, lazy load |
| **Sharp** | Image processing |
| **Cloudinary** | Image CDN, transformations |
| **Uploadthing** | File uploads for Next.js |
| **Plaiceholder** | Blur placeholder for images |
| **React Player** | Video embeds |

---

## 🗃️ Backend & Database
| Library | Purpose |
|---|---|
| **Supabase** | Postgres DB, auth, storage, realtime |
| **Prisma** | Type-safe database ORM |
| **PlanetScale** | Serverless MySQL |
| **MongoDB + Mongoose** | NoSQL database |
| **Drizzle ORM** | Lightweight TypeScript ORM |
| **Redis (Upstash)** | Caching, rate limiting |

---

## 🔐 Authentication
| Library | Purpose |
|---|---|
| **NextAuth.js** | Auth for Next.js (Google, GitHub, email) |
| **Clerk** | Complete auth solution (easiest) |
| **Supabase Auth** | If already using Supabase |
| **Lucia Auth** | Lightweight custom auth |

---

## 📧 Email & Communication
| Library | Purpose |
|---|---|
| **Resend** | Modern email API (best for devs) |
| **Nodemailer** | Traditional email sending |
| **React Email** | Build emails like React components |
| **Twilio** | SMS notifications |

---

## 💳 Payments
| Library | Purpose |
|---|---|
| **Stripe** | Most popular payment gateway |
| **Razorpay** | Best for India 🇮🇳 (UPI, NetBanking, Cards) |
| **PayU** | Alternative India payment |
| **Lemon Squeezy** | Digital products payments |

---

## 🔍 SEO & Analytics
| Library | Purpose |
|---|---|
| **Next SEO** | Meta tags, Open Graph |
| **Schema.org** | Structured data for Google |
| **Google Analytics** | Traffic analytics |
| **Vercel Analytics** | Performance analytics |
| **Hotjar** | Heatmaps, user recordings |
| **Posthog** | Open source analytics |

---

## 🚀 Performance
| Library | Purpose |
|---|---|
| **Lighthouse** | Performance testing |
| **Web Vitals** | Core performance metrics |
| **Bundle Analyzer** | Find large packages |
| **Sharp** | Image optimization |
| **Turbopack** | Fast bundler (Next.js 14+) |
| **ISR** | Incremental Static Regeneration |
| **Edge Runtime** | Fastest API responses |

---

## 🧪 Testing
| Library | Purpose |
|---|---|
| **Playwright** | End-to-end testing |
| **Cypress** | E2E browser testing |
| **Jest** | Unit testing |
| **React Testing Library** | Component testing |
| **Storybook** | Component documentation |

---

## 📦 State Management
| Library | Purpose | Notes |
|---|---|---|
| **Zustand** | Simplest global state | Most popular right now |
| **Jotai** | Atomic state management | |
| **TanStack Query** | Server state, data fetching | |
| **Redux Toolkit** | Large scale applications | |

---

## 🌐 API & Data Fetching
| Library | Purpose |
|---|---|
| **TanStack Query** | Best data fetching library |
| **Axios** | HTTP requests |
| **SWR** | Stale while revalidate |
| **tRPC** | End-to-end type safe APIs |
| **GraphQL + Apollo** | Graph-based API |
| **Zod** | Schema validation |

---

## ☁️ Hosting & Deployment
| Platform | Notes |
|---|---|
| **Vercel** | Best for Next.js (easiest) |
| **Netlify** | Great free tier |
| **Cloudflare Pages** | Unlimited bandwidth free |
| **Railway** | Full stack hosting |
| **AWS** | Enterprise grade |
| **Docker** | Container deployment |

---

## 🔥 Recommended Stacks by Project Type

### Marketing / Business Website
```
Next.js 15 + Tailwind CSS + Framer Motion + GSAP + Lenis
+ Aceternity UI + Shadcn UI + Supabase + Resend + Vercel
```

### SaaS / Web App
```
Next.js 15 + TypeScript + Tailwind + Shadcn UI + Clerk
+ Prisma + Supabase + TanStack Query + Zustand
+ Stripe / Razorpay + Vercel
```

### Creative / Portfolio / Agency
```
Next.js 15 + Three.js + React Three Fiber + GSAP + ScrollTrigger
+ Lenis + Framer Motion + Spline + Tailwind CSS + Vercel
```

### E-Commerce
```
Next.js 15 + Tailwind + Shadcn UI + Stripe / Razorpay
+ Prisma + PostgreSQL + TanStack Query + NextAuth
+ Cloudinary + Vercel
```

---

## ⚡ 10 Quality Rules (Non-Negotiable)

1. **Performance first** → Lighthouse score 90+
2. **Mobile first** → Design for phone first
3. **Accessibility** → WCAG 2.1 standards
4. **SEO ready** → Meta, schema, sitemap
5. **Font pairing** → Max 2 fonts only
6. **Color system** → Max 3 colors + shades
7. **Animation purpose** → Animate with reason, not to show off
8. **Loading states** → Always show skeleton/spinner
9. **Error handling** → Always handle failures gracefully
10. **Image optimization** → WebP, lazy load, blur placeholder

---

## 🏆 Design Inspiration Sites

- [awwwards.com](https://awwwards.com) — World's best websites
- [cssdesignawards.com](https://cssdesignawards.com) — Creative CSS websites
- [dribbble.com](https://dribbble.com) — UI design inspiration
- [behance.net](https://behance.net) — Design portfolios
- [godly.website](https://godly.website) — Curated web design
- [land-book.com](https://land-book.com) — Landing page inspiration
