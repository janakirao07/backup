# BSR Shopping Mall — Announcement Bar Visual Audit

Before refining `OfferTicker.tsx`, we identified the following aesthetic and performance issues that weaken the premium luxury perception of the brand:

## 1. Visual Problems
*   **Aggressive Marquee Motion:** The GSAP-driven infinite ticker animation is distracting. Luxury brands prefer stillness, control, and minimal motion. A scrolling marquee is a hallmark of discount stores, news sites, or stock tickers, not high-end fashion.
*   **Informal Typography & Emojis:** The default announcements use heavy ALL CAPS text paired with literal emojis (🚚, 📞, 🕙). This creates a loud, casual visual texture. Premium fashion relies on typographic restraint (e.g., Title Case, light font weights, wide tracking) and subtle separators rather than pictograms.
*   **Visual Clutter:** Having multiple messages flying across the screen simultaneously dilutes the communication and makes the top of the viewport feel dense and noisy.

## 2. Why it Weakens Luxury Perception
Luxury ecommerce relies heavily on the concept of "white space" (even when dark) and intentionality. The user's eye should be immediately drawn to the high-quality product photography and curated collections. A moving, dense, emoji-filled bar at the very top of the hierarchy violently pulls attention away from the clothing and establishes a "bargain" psychological framing before the user even sees a product.

## 3. Mobile UX Risks
*   On mobile screens, scrolling marquees can induce motion sickness (accessibility issue) and make it difficult for users to read or tap phone numbers before they scroll out of view.
*   The tight horizontal padding combined with motion can lead to a cramped, visually overwhelming experience on a 320px screen.

## Implementation Plan
1.  **Remove Motion:** Strip out `gsap` entirely. The bar will become a static, centered element.
2.  **Typography Restraint:** Remove forced `uppercase`. Use the `Jost` sans-serif at a light weight (`font-light`), or a small size with elegant tracking.
3.  **Content Simplification:** Instead of scrolling, we will display up to three announcements evenly spaced on desktop, and perhaps only the primary one (or stacked) on mobile, separated by a minimal typographic bullet (`•`) or thin vertical line.
4.  **Emoji Removal:** Strip or ignore emojis in favor of a clean text-only presentation. 
5.  **Performance Win:** Removing the GSAP effect allows this component to be incredibly lightweight, resolving any client-side painting/layout shift issues entirely.
