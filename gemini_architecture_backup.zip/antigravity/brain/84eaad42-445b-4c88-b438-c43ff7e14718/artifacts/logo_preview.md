# Primetek Global Solutions Logo Preview

Here is the production-ready SVG logo that I injected into your `Navbar.tsx` component. It renders cleanly at any resolution.

<div style="padding: 2rem; background-color: #f8fafc; border-radius: 8px; margin-bottom: 2rem; border: 1px solid #e2e8f0; max-width: 600px;">
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 400 100" 
    style="width: 100%; height: auto;"
    fill="none"
  >
    <defs>
      <linearGradient id="globeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#1E3A8A" stop-opacity="0.8" />
        <stop offset="100%" stop-color="#0F172A" stop-opacity="0.6" />
      </linearGradient>
      <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stop-color="#D4AF37" />
        <stop offset="100%" stop-color="#FDE047" />
      </linearGradient>
      <linearGradient id="meshGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#1E3A8A" />
        <stop offset="100%" stop-color="#2563EB" />
      </linearGradient>
    </defs>

    <!-- Logo Mark (Globe + P) -->
    <g transform="translate(10, 10)">
      <!-- Globe / Orbit lines -->
      <ellipse cx="40" cy="40" rx="35" ry="35" fill="none" stroke="url(#globeGrad)" stroke-width="1.5" opacity="0.4"/>
      <ellipse cx="40" cy="40" rx="15" ry="35" fill="none" stroke="url(#globeGrad)" stroke-width="1" opacity="0.5"/>
      <ellipse cx="40" cy="40" rx="35" ry="15" fill="none" stroke="url(#globeGrad)" stroke-width="1" opacity="0.5"/>
      <path d="M 15 15 L 65 65 M 15 65 L 65 15" stroke="url(#globeGrad)" stroke-width="0.5" opacity="0.3"/>
      
      <!-- P Network Mesh -->
      <path 
        d="M 25,65 L 25,20 L 45,20 C 55,20 60,25 60,35 C 60,45 55,50 45,50 L 25,50" 
        fill="none" 
        stroke="url(#meshGrad)" 
        stroke-width="4" 
        stroke-linecap="round" 
        stroke-linejoin="round"
      />
      
      <!-- Connection Nodes -->
      <circle cx="25" cy="20" r="4.5" fill="url(#goldGrad)" />
      <circle cx="45" cy="20" r="4" fill="url(#goldGrad)" />
      <circle cx="58" cy="35" r="4.5" fill="url(#goldGrad)" />
      <circle cx="45" cy="50" r="4" fill="url(#goldGrad)" />
      <circle cx="25" cy="50" r="4.5" fill="url(#goldGrad)" />
      <circle cx="25" cy="65" r="4" fill="url(#goldGrad)" />
      
      <!-- Outer orbital node -->
      <circle cx="70" cy="20" r="2.5" fill="url(#goldGrad)" opacity="0.8" />
      <path d="M 60 25 L 70 20" stroke="url(#globeGrad)" stroke-width="1" opacity="0.5" />
    </g>

    <!-- Text Elements -->
    <g transform="translate(105, 50)">
      <text 
        x="0" 
        y="0" 
        font-family="system-ui, -apple-system, sans-serif" 
        font-weight="800" 
        font-size="38" 
        fill="#0F172A" 
        letter-spacing="1"
      >
        PRIMETEK
      </text>
      
      <!-- Gold Separator Line -->
      <path d="M 2 12 L 195 12" stroke="url(#goldGrad)" stroke-width="2" stroke-linecap="round" opacity="0.8"/>
      
      <text 
        x="0" 
        y="32" 
        font-family="system-ui, -apple-system, sans-serif" 
        font-weight="600" 
        font-size="13" 
        fill="#475569" 
        letter-spacing="4"
      >
        GLOBAL SOLUTIONS
      </text>
    </g>
  </svg>
</div>

### And here is the AI-generated concept image (PNG):

![Primetek Concept Logo](file:///C:/Users/janak/.gemini/antigravity/brain/84eaad42-445b-4c88-b438-c43ff7e14718/primetek_logo_1777330220552.png)
