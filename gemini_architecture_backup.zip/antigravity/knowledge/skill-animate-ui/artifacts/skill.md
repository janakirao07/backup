---
name: animate-ui-best-practices
description: Animate UI component library for React. Use when adding animated components like buttons, cards, text effects, backgrounds, and transitions using Shadcn CLI + Framer Motion.
---

# Animate UI Best Practices

## Installation
```bash
# Add to your project via Shadcn CLI
npx shadcn@latest init
npx shadcn@latest add "https://animate-ui.com/r/fade-in"
```

## Core Setup
Requires: React, TypeScript, Tailwind CSS, Motion (Framer Motion)

```bash
npm install motion class-variance-authority clsx tailwind-merge
```

## Usage Pattern
```tsx
// Components install into your codebase (not node_modules)
// Located at: components/animate-ui/

import { FadeIn } from '@/components/animate-ui/fade-in';
import { ScaleIn } from '@/components/animate-ui/scale-in';
import { SlideIn } from '@/components/animate-ui/slide-in';
import { TextReveal } from '@/components/animate-ui/text-reveal';

function HeroSection() {
  return (
    <div>
      <FadeIn delay={0.2}>
        <h1>Welcome</h1>
      </FadeIn>
      <SlideIn direction="up" delay={0.4}>
        <p>Subtitle text</p>
      </SlideIn>
      <ScaleIn delay={0.6}>
        <button>Get Started</button>
      </ScaleIn>
    </div>
  );
}
```

## Component Categories
| Category | Components |
|----------|-----------|
| **Transitions** | FadeIn, SlideIn, ScaleIn, BlurIn, FlipIn |
| **Text** | TextReveal, TypeWriter, LetterPullUp, WordRotate, GradientText |
| **Buttons** | ShinyButton, MagneticButton, AnimatedButton |
| **Cards** | TiltCard, FlipCard, GlowCard |
| **Backgrounds** | ParticleField, GradientMesh, AnimatedGrid, Aurora |
| **Loading** | SkeletonPulse, SpinnerDots, ProgressRing |
| **Interactions** | Magnetic, Spotlight, Marquee, InfiniteScroll |

## Best Practices
1. **Don't over-animate** — Use max 2-3 animation types per page
2. **Stagger delays** — Increment by 0.1-0.2s for sequential reveals
3. **Respect prefers-reduced-motion** — Components handle this automatically
4. **Customize after install** — Components are in YOUR code, modify freely
5. **Combine with GSAP** — Use Animate UI for component-level, GSAP for page-level
6. **Performance** — Motion uses GPU-accelerated transforms by default

## vs Other Animation Libraries
| Library | Best for | Bundled with components? |
|---------|----------|------------------------|
| **Animate UI** | Drop-in animated components | ✅ Yes |
| **Framer Motion** | Custom animations from scratch | ❌ Library only |
| **GSAP** | Complex timelines, scroll | ❌ Library only |
| **CSS animations** | Simple hover/transition effects | ❌ Manual |
