# Razorpay India Integration Guide

This guide contains the specific patterns required for a robust Razorpay implementation in Next.js App Router.

## 1. Flow Overview
1. Client requests an order creation from the server.
2. Server creates a Razorpay `order_id` and returns it to the client.
3. Client opens the Razorpay checkout script with the `order_id`.
4. Client handles success/failure callback.
5. **Critical**: Server MUST verify the payment via Webhook or direct API check before fulfilling the order. Never trust the client callback alone.

## 2. Server: Creating an Order (API Route)
```typescript
import Razorpay from 'razorpay';
import { NextResponse } from 'next/server';

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_SECRET!,
});

export async function POST(req: Request) {
  try {
    const { amount } = await req.json();
    
    const options = {
      amount: amount * 100, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
      currency: 'INR',
      receipt: `receipt_${Date.now()}`
    };

    const order = await razorpay.orders.create(options);
    return NextResponse.json({ orderId: order.id });
  } catch (err) {
    return NextResponse.json({ error: 'Order creation failed' }, { status: 500 });
  }
}
```

## 3. Server: Webhook Signature Verification
Webhooks are essential for capturing UPI intents where the user might close the browser before returning.

```typescript
import crypto from 'crypto';
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  const body = await req.text(); // Must read as text for crypto signature
  const signature = req.headers.get('x-razorpay-signature');
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET!;

  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(body)
    .digest('hex');

  if (expectedSignature === signature) {
    const event = JSON.parse(body);
    // Handle event.payment.captured
    return NextResponse.json({ status: 'ok' });
  } else {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
  }
}
```

## 4. Client: Checkout UI
Always load the Razorpay script dynamically.

```tsx
'use client';
import { useState } from 'react';

export default function Checkout() {
  const handlePayment = async () => {
    // 1. Create order on server
    const res = await fetch('/api/create-order', { method: 'POST', body: JSON.stringify({ amount: 500 }) });
    const { orderId } = await res.json();

    // 2. Load script
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => {
      const options = {
        key: process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID,
        amount: 50000,
        currency: 'INR',
        name: 'BSR Shopping Mall',
        description: 'Test Transaction',
        order_id: orderId,
        handler: function (response: any) {
          // Success callback - STILL NEEDS SERVER VERIFICATION via webhook or status check
          console.log(response.razorpay_payment_id);
        },
        prefill: {
          name: 'Janaki',
          email: 'customer@example.com',
          contact: '9999999999'
        },
        theme: {
          color: '#3399cc'
        }
      };
      
      const rzp = new (window as any).Razorpay(options);
      rzp.open();
    };
    document.body.appendChild(script);
  };

  return <button onClick={handlePayment}>Pay Now</button>;
}
```
