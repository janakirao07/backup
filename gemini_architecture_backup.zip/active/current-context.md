# Current Active Context

Current project:
- Pravallika Resume Builder

Current phase:
- Active development

Active files:
- None

Blockers:
- None

Architecture decisions:
- Frontend: HTML/JS
- Database: LocalStorage
- Backend: None
