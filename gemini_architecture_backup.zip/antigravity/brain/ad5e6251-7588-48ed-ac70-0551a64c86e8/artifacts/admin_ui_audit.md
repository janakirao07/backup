# Admin Portal UI Audit

## Audit Summary
Reviewed all admin portal pages for UI/UX consistency, mobile responsiveness, and visual polish.

| Page | Overall | Key Issues |
|------|---------|------------|
| Dashboard | ✅ Good | `inq.message` → should be `inq.requirement` (silent data mismatch) |
| Approvals | ✅ Excellent | Premium design, no issues |
| Client Profiles | ⚠️ Needs Work | Missing status colors, no empty state, inconsistent styling |
| Attendance | ✅ Good | Well-designed with filters |
| Applications | ✅ Good | Consistent with design system |
| Jobs | ✅ Good | Toggle switches, hover effects |
| Employees | ✅ Excellent | Premium modals, stats summary |
| Inquiries | ⚠️ Needs Work | **No mobile card layout** — only horizontal-scroll table |
| Settings | ✅ Excellent | Premium geofence config |
| Sidebar | ✅ Excellent | Mobile bottom nav + overflow sheet |

---

## Issues & Fixes

### A-01: Client Profiles — Incomplete Status Badge Colors
**File**: `ClientProfilesClient.tsx:221-224`  
**Severity**: Medium  
**Issue**: Status badge only handles `completed` (green) and defaults everything else to blue. Missing `assigned`, `processing`, `rejected`, `pending` states.  
**Fix**: Add a comprehensive `statusColors` map like other pages.

### A-02: Client Profiles — No Empty State
**File**: `ClientProfilesClient.tsx:191-233`  
**Severity**: Medium  
**Issue**: When no profiles exist, the grid is just empty — no illustration or message. Every other page has a proper empty state.  
**Fix**: Add empty state with icon + message.

### A-03: Client Profiles — Search Input Inconsistency
**File**: `ClientProfilesClient.tsx:180-189`  
**Severity**: Low  
**Issue**: Search input uses `border-border` and lacks `shadow-sm`, inconsistent with the `border-border/60 shadow-sm` pattern used across Attendance, Jobs, Employees pages.  
**Fix**: Align input styling.

### A-04: Client Profiles — Cards Lack Hover Effects
**File**: `ClientProfilesClient.tsx:193`  
**Severity**: Low  
**Issue**: Profile cards have no hover shadow/scale transition. Other pages (Dashboard stats, Quick Actions) have `hover:shadow-md transition-all`.  
**Fix**: Add hover transition to cards.

### A-05: Inquiries — No Mobile Card Layout
**File**: `InquiryTable.tsx:212-291`  
**Severity**: High  
**Issue**: Every other admin page has `block md:hidden` mobile cards + `hidden md:block` desktop table. InquiryTable only has a desktop table with `overflow-x-auto`. On mobile, users must horizontally scroll the table — poor UX.  
**Fix**: Add mobile card layout.

### A-06: Dashboard — Silent Data Mismatch
**File**: `dashboard/page.tsx:185`  
**Severity**: Medium  
**Issue**: Line 185 references `inq.message` but the inquiry schema field is `requirement`. This silently renders nothing for the inquiry preview text.  
**Fix**: Change `inq.message` → `inq.requirement`.
