# Task: Debugging Home Page Scroll Issues

## Checklist
- [ ] Open home page (http://localhost:3000)
- [ ] Verify if page is scrollable
- [ ] Check console logs for errors (GSAP, Lenis, Layout)
- [ ] Inspect elements for CSS issues (overflow hidden, etc.)
- [ ] Report findings

## Findings
- 
