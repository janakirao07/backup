# Phase 6: Admin Module & Cloud Integration

## Objective
Enable college administrators to manage site content (Notices, Faculty, Gallery) and view/export student inquiries via a secure dashboard.

## Tasks

### 6.1: Cloud Infrastructure
- [ ] Initialize Supabase client
- [ ] Define database schema for `notices`, `faculty`, `gallery`, and `inquiries`
- [ ] Migrate local JSON data to Supabase (one-time setup)

### 6.2: Admin Authentication
- [ ] Create `/admin` login page
- [ ] Implement middleware to protect `/admin/*` routes
- [ ] Setup Admin-only Role Level Security (RLS) in Supabase

### 6.3: Content Management (CRUD)
- [ ] **Notice Manager**: UI to add/delete announcements
- [ ] **Faculty Manager**: Form to add new professors with photo upload
- [ ] **Gallery Manager**: Image upload to Supabase Storage

### 6.4: Admissions Management
- [ ] **Inquiry Dashboard**: Table view of all submissions from `/admissions`
- [ ] **Excel Export**: Implement `xlsx` export functionality for leads
- [ ] Connect Admissions form to Supabase `inquiries` table

### 6.5: Final Polishing
- [ ] Favicon generation
- [ ] OpenGraph/Social cards
- [ ] Google Maps Embed on Contact page
- [ ] SEO Sitemap & Robots.txt
