# 🔍 Full Code Audit — Job Tracker / AI Blaze Chrome Extension

---

## ISSUE #1
**File:** `content.js`  
**Line:** 339  
**Category:** 🔴 Security Issue / Broken API Call  
**Problem:** `dbLoadApps()` fetches ALL applications from the `applications` table without filtering by `username`. The query has no `username=eq.{userId}` parameter. If Row Level Security (RLS) is misconfigured or disabled, this returns **every user's data**.  
**Broken Code:**
```js
SUPABASE_URL + `/rest/v1/applications?select=*&order=created_at.asc&limit=${PAGE_SIZE}&offset=${offset}`
```
**Fixed Code:**
```js
SUPABASE_URL + `/rest/v1/applications?username=eq.${currentUser.id}&select=*&order=created_at.asc&limit=${PAGE_SIZE}&offset=${offset}`
```
**Impact:** If Supabase RLS policies aren't correctly enforced (or are bypassed by the anon key), every user sees and edits every other user's applications. Even with RLS, including the filter is correct practice and reduces payload size.

---

## ISSUE #2
**File:** `content.js`  
**Line:** 2459  
**Category:** 🔴 Broken API Call / Missing Function  
**Problem:** `processAIShortcut()` calls `callOllama(url, model, fullPrompt)` when engine is `'ollama'`, but **no `callOllama` function exists** anywhere in `content.js`. This will throw `ReferenceError: callOllama is not defined` at runtime.  
**Broken Code:**
```js
if (engine === 'ollama') {
  const url = localStorage.getItem('rjd_ollama_url') || 'http://localhost:11434';
  const model = localStorage.getItem('rjd_ollama_model') || 'llama3.2';
  result = await callOllama(url, model, fullPrompt);
}
```
**Fixed Code:**
```js
if (engine === 'ollama') {
  // Ollama support removed — force Gemini
  throw new Error('Ollama is no longer supported. Please switch to Gemini in Settings.');
}
```
**Impact:** If a user previously set the engine to 'ollama' (via localStorage), every AI Assistant chat message crashes silently with `[AI Error: callOllama is not defined]`.

---

## ISSUE #3
**File:** `popup.js`  
**Line:** 151  
**Category:** 🔴 Missing Null Check / Crash  
**Problem:** `session` might be `null` (no user logged in), but line 151 does `session.token` without checking if `session` is `null` first. `null.token` will throw a `TypeError` and the popup will show a blank white page.  
**Broken Code:**
```js
const session = res.rjd_session || null;
const sessToken = session.token || session.access_token;
```
**Fixed Code:**
```js
const session = res.rjd_session || null;
if (!session) { renderNotLoggedIn(); return; }
const sessToken = session.token || session.access_token;
```
**Impact:** First-time users or logged-out users see a **blank popup** instead of the "Get Started" screen. This is likely a live bug.

---

## ISSUE #4
**File:** `content.js`  
**Line:** 2344–2347  
**Category:** 🟡 Duplicate Event Listener / Logic Bug  
**Problem:** `bindTrackerEvents()` attaches a second `click` listener to `rjd-resume-copy-btn`, and this duplicate uses `.textContent` instead of `.value` on the textarea, so it copies empty text or HTML-rendered text, not the actual textarea value.  
**Broken Code:**
```js
// Line 2149 (first binding — CORRECT)
document.getElementById('rjd-resume-copy-btn').addEventListener('click', () => {
  const text = document.getElementById('rjd-resume-body').value;
  navigator.clipboard.writeText(text)...
});

// Line 2344 (second binding — WRONG, uses textContent)
document.getElementById('rjd-resume-copy-btn').addEventListener('click', () => {
  navigator.clipboard.writeText(document.getElementById('rjd-resume-body').textContent);
  showToast('Resume copied');
});
```
**Fixed Code:**
Remove lines 2344–2347 entirely — the correct listener is already attached at line 2149.
**Impact:** Copy button fires twice. The second handler copies `textContent` (empty string for a `<textarea>`), so the clipboard may sometimes contain empty text.

---

## ISSUE #5
**File:** `content.js`  
**Line:** 2356  
**Category:** 🔴 Broken Path / Runtime Crash  
**Problem:** The xlsxbuilder script source path is `'lib/xlsxbuilder.js'` (missing `src/` prefix). `chrome.runtime.getURL('lib/xlsxbuilder.js')` resolves to the root, but the file is actually at `src/lib/xlsxbuilder.js`.  
**Broken Code:**
```js
s.src = chrome.runtime.getURL('lib/xlsxbuilder.js');
```
**Fixed Code:**
```js
s.src = chrome.runtime.getURL('src/lib/xlsxbuilder.js');
```
**Impact:** "Export XLSX" button always fails with `'Failed to load xlsxbuilder.js'` error. Users cannot export their applications to Excel.

---

## ISSUE #6
**File:** `content.js`  
**Line:** 1128–1131  
**Category:** 🟡 Dead Code / Logic Bug  
**Problem:** The `returnTo` parameter is checked but both branches do exactly the same thing (`renderTrackerScreen()`). The `else` branch was intended to return to the assistant or other screen but was never implemented.  
**Broken Code:**
```js
if (returnTo === 'tracker') renderTrackerScreen();
else renderTrackerScreen(); // default fallback
```
**Fixed Code:**
```js
if (returnTo === 'assistant') renderAssistantScreen();
else renderTrackerScreen();
```
**Impact:** No functional bug currently, but the Settings back button always returns to tracker even when opened from the assistant tab.

---

## ISSUE #7
**File:** `content.js`  
**Line:** 1407–1410  
**Category:** 🟡 Hardcoded Stale Info  
**Problem:** The "About" section hardcodes version as `4.2.0` and AI Model as `Gemini 3.1 Flash Lite`. Both are stale — the manifest says `5.1.0`, and the model is now dynamic and configurable.  
**Broken Code:**
```html
<span ...>4.2.0</span>
...
<span ...>Gemini 3.1 Flash Lite</span>
```
**Fixed Code:** Read from `chrome.runtime.getManifest().version` and from the stored model respectively.
**Impact:** Users see incorrect version and model information in the About screen.

---

## ISSUE #8
**File:** `background.js`  
**Line:** 47  
**Category:** 🟡 Silent Failure  
**Problem:** The `catch(e) {}` after `chrome.scripting.executeScript()` swallows all errors completely. If a command fails (e.g., on a chrome:// page), there's zero diagnostic info.  
**Broken Code:**
```js
} catch(e) {}
```
**Fixed Code:**
```js
} catch(e) {
  console.warn('[RJD] Command injection failed on tab', tab?.id, ':', e.message);
}
```
**Impact:** Keyboard shortcuts silently fail on restricted pages with no ability to diagnose.

---

## ISSUE #9
**File:** `background.js`  
**Line:** 112  
**Category:** 🟡 Silent Failure  
**Problem:** `checkInterviewsToday()` has a bare `catch(e) {}` that swallows all errors (network failures, parse errors, etc.) with zero logging.  
**Broken Code:**
```js
} catch(e) {}
```
**Fixed Code:**
```js
} catch(e) {
  console.warn('[RJD SW] Interview check failed:', e.message);
}
```
**Impact:** If interview notifications break, there's no way to know why.

---

## ISSUE #10
**File:** `background.js`  
**Line:** 91  
**Category:** 🟡 Broken API Call  
**Problem:** The interview query filters by `status=eq.Interview Scheduled` without URL-encoding the space. While Supabase may handle this, it's technically malformed and could break on some proxy servers.  
**Broken Code:**
```js
"/rest/v1/applications?status=eq.Interview Scheduled&select=..."
```
**Fixed Code:**
```js
"/rest/v1/applications?status=eq.Interview%20Scheduled&select=..."
```
**Impact:** Interview notification check could fail silently on certain environments.

---

## ISSUE #11
**File:** `content.js`  
**Line:** 240  
**Category:** 🟡 Missing Null Check  
**Problem:** In `sbFetch`, when a 401 retry happens, `opts.headers` is accessed without checking if `opts` or `opts.headers` exists. If the caller passed `opts` without `headers`, this crashes.  
**Broken Code:**
```js
if (opts.headers) opts.headers['Authorization'] = 'Bearer ' + sessionToken;
```
**Fixed Code:**
```js
if (!opts.headers) opts.headers = {};
opts.headers['Authorization'] = 'Bearer ' + sessionToken;
```
**Impact:** Rare crash during token refresh if opts was passed without explicit headers.

---

## ISSUE #12
**File:** `content.js`  
**Line:** 517  
**Category:** 🟢 XSS Risk (Low)  
**Problem:** `showLoading(msg)` inserts `msg` directly into innerHTML using template literal `${msg}`. If `msg` ever comes from user input, it could inject HTML.  
**Broken Code:**
```js
<div ...>${msg || 'Loading...'}</div>
```
**Fixed Code:**
```js
<div ...>${escHtml(msg || 'Loading...')}</div>
```
**Impact:** Currently safe (all callers pass hardcoded strings), but a latent XSS vector.

---

## ISSUE #13
**File:** `copilot.js`  
**Line:** 294  
**Category:** 🟡 XSS Vulnerability  
**Problem:** `showInlineResultModal` inserts `text` directly into innerHTML using `.replace(/\n/g, '<br>')` without escaping HTML first. The AI response `text` could contain `<script>` tags or event handlers.  
**Broken Code:**
```js
${text.replace(/\n/g, '<br>')}
```
**Fixed Code:**
```js
${text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\n/g, '<br>')}
```
**Impact:** If Gemini returns text containing HTML tags (which it can), those get executed as real HTML in the Shadow DOM modal. Potential XSS.

---

## ISSUE #14
**File:** `content.js`  
**Line:** 2202  
**Category:** 🟡 Logic Bug  
**Problem:** Quick Extract checks `GEMINI_KEY` to decide whether to call extraction. But `GEMINI_KEY` is loaded asynchronously at login time and might still be empty even when a key is saved. The manual extraction (`runExtract`) correctly loads the key on demand, but the quick path does not.  
**Broken Code:**
```js
if (GEMINI_KEY && GEMINI_KEY.trim() && clipText.trim()) {
```
**Fixed Code:**
```js
// Always try extraction — callGeminiBlaze loads the key itself via extractWithGemini
if (clipText.trim()) {
```
Or load the key first:
```js
if (!GEMINI_KEY) await new Promise(r => loadGeminiKey(k => { GEMINI_KEY = k; r(); }));
if (GEMINI_KEY && GEMINI_KEY.trim() && clipText.trim()) {
```
**Impact:** "✦ Extract & Save" button sometimes skips AI extraction and opens a blank form, even though the user has a valid API key saved.

---

## ISSUE #15
**File:** `content.js`  
**Line:** 2119  
**Category:** 🟡 Missing Context Check  
**Problem:** `setWorkingDate` calls `chrome.storage.local.set()` directly without wrapping in `chromeStore()` or checking `isContextValid()`. If the extension is reloaded, this throws an uncaught error.  
**Broken Code:**
```js
chrome.storage.local.set({ rjd_working_date: iso });
```
**Fixed Code:**
```js
const s = chromeStore();
if (s) s.set({ rjd_working_date: iso });
```
**Impact:** Setting the working date crashes if extension context is invalidated.

---

## ISSUE #16
**File:** `content.js`  
**Line:** 326–330  
**Category:** 🟡 Silent Failure / Logic Bug  
**Problem:** `sbSignOut()` does not include the session token in the Authorization header because `sbHeaders()` uses `sessionToken` which might be null at signout time. Also, this is a direct `fetch()` instead of using `sbFetch()`, so it bypasses CSP protection on strict sites.  
**Broken Code:**
```js
async function sbSignOut() {
  await fetch(SUPABASE_URL + '/auth/v1/logout', {
    method: 'POST',
    headers: sbHeaders(),
  });
}
```
**Fixed Code:**
```js
async function sbSignOut() {
  try {
    await sbFetch(SUPABASE_URL + '/auth/v1/logout', {
      method: 'POST',
      headers: sbHeaders(),
    });
  } catch(e) { /* best-effort logout */ }
}
```
**Impact:** Logout may fail silently on CSP-strict sites (LinkedIn, ChatGPT). The server session stays alive even after the user thinks they logged out.

---

## ISSUE #17
**File:** `content.js`  
**Line:** 641  
**Category:** 🟢 Silent Failure  
**Problem:** `extractFromDomain()` has a bare `catch(e) {}` that swallows all DOM scraping errors.  
**Impact:** Low — DOM scraping errors are expected, but makes debugging domain extraction impossible.

---

## ISSUE #18
**File:** `content.js`  
**Line:** 1766  
**Category:** 🟡 Missing Null Check  
**Problem:** `renderTrackerScreen()` calls `currentUser.name` without checking if `currentUser` is null. If a race condition occurs where the UI tries to render before session is loaded, this crashes.  
**Broken Code:**
```js
const initials = getInitials(currentUser.name);
```
**Fixed Code:**
```js
if (!currentUser) return;
const initials = getInitials(currentUser.name);
```
**Impact:** Occasional crash on slow connections when sidebar opens before session loads.

---

## ISSUE #19
**File:** `content.js`  
**Line:** 2308  
**Category:** 🟡 Missing Field  
**Problem:** When saving a new application from the form, `followUpDate` is not included in the app object, though it's expected by `dbSaveApp`.  
**Broken Code:**
```js
const app = {
  id: crypto.randomUUID(), company, jobTitle, url, jd, resume: '',
  status, date: today(), dateRaw: new Date().toISOString(), dateKey: todayKey(), notes: ''
};
```
**Fixed Code:**
```js
const app = {
  id: crypto.randomUUID(), company, jobTitle, url, jd, resume: '',
  status, date: today(), dateRaw: new Date().toISOString(), dateKey: todayKey(), notes: '', followUpDate: ''
};
```
**Impact:** `dbSaveApp` sends `followUpDate: undefined` to Supabase, which may cause a column type mismatch error.

---

## ISSUE #20
**File:** `background.js`  
**Line:** 3–33  
**Category:** 🟡 Logic Bug  
**Problem:** The `onMessage` listener only returns `true` (to keep the response channel open) for the `sb_proxy_fetch` action. But for `session_saved`/`session_cleared`, it implicitly returns `undefined`, which means Chrome may close the channel before the tab broadcast completes. This is benign **only** because those branches don't call `sendResponse`.  
**Impact:** No current breakage, but if `sendResponse` is ever added to the session broadcast branch, it will fail silently.

---

## ISSUE #21
**File:** `copilot.js`  
**Line:** 253–256  
**Category:** 🟡 Logic Bug  
**Problem:** `mousedown` handler checks `shadowRoot.contains(e.target)` to avoid hiding toolbar when clicking inside it. But elements inside a Shadow DOM are *not* contained by the shadow root via `contains()` — the event target is re-targeted. This means clicking toolbar buttons hides the toolbar before the click event fires.  
**Broken Code:**
```js
document.addEventListener('mousedown', (e) => {
  if (shadowRoot.contains(e.target)) return;
  hideToolbar();
});
```
**Fixed Code:**
```js
document.addEventListener('mousedown', (e) => {
  if (e.composedPath().some(el => el === floatingToolbar)) return;
  hideToolbar();
});
```
**Impact:** Copilot toolbar buttons may be unreliable — the toolbar hides on click before the button's `onclick` fires.

---

## ISSUE #22
**File:** `content.js`  
**Line:** 822  
**Category:** 🟢 Regex Bug  
**Problem:** The regex has a misplaced non-greedy quantifier `{1,40?}` inside a character class range. `?` inside `{}` is not valid regex for non-greedy — it works in JS but logs a deprecation warning. Should be `{1,40}` (greedy is fine here since `[,!.]` anchors the end).  
**Broken Code:**
```js
let m = line.match(/^(?:we are|...)\s+([A-Z][A-Za-z0-9&' ]{1,40?})[,!.]/i);
```
**Fixed Code:**
```js
let m = line.match(/^(?:we are|...)\s+([A-Z][A-Za-z0-9&' ]{1,40})[,!.]/i);
```
**Impact:** Minor — the regex works but generates console deprecation warnings in newer V8 engines.

---

## ISSUE #23
**File:** `manifest.json`  
**Line:** 66–82  
**Category:** 🟡 Performance Issue  
**Problem:** `content_scripts` injects `docx-bundle.js` (732KB) and `FileSaver.min.js` on **every single page** the user visits. These are only needed when downloading a resume.  
**Impact:** Every page load is slowed by ~750KB of unnecessary script parsing. These should be lazy-loaded (as done for `xlsxbuilder.js`).

---

## ISSUE #24
**File:** `content.js`  
**Line:** 2492  
**Category:** 🟡 Performance Issue  
**Problem:** Google Fonts CSS import (`@import url(...)`) is injected via a `<style>` element on every page load, causing an additional network request and potential FOUT on every page.  
**Impact:** Minor rendering delay and unnecessary network request on every page.

---

---

# SUMMARY TABLE

| Issue # | File | Line | Category | Severity |
|---------|------|------|----------|----------|
| **1** | content.js | 339 | Security / Broken API | **Critical** |
| **2** | content.js | 2459 | Missing Function | **Critical** |
| **3** | popup.js | 151 | Missing Null Check / Crash | **Critical** |
| **4** | content.js | 2344 | Duplicate Listener / Bug | **High** |
| **5** | content.js | 2356 | Broken Path | **High** |
| **6** | content.js | 1128 | Dead Code | Low |
| **7** | content.js | 1407 | Stale Hardcoded Info | Low |
| **8** | background.js | 47 | Silent Failure | Medium |
| **9** | background.js | 112 | Silent Failure | Medium |
| **10** | background.js | 91 | URL Encoding | Medium |
| **11** | content.js | 240 | Missing Null Check | Medium |
| **12** | content.js | 517 | XSS Risk (Latent) | Low |
| **13** | copilot.js | 294 | XSS Vulnerability | **High** |
| **14** | content.js | 2202 | Logic Bug | **High** |
| **15** | content.js | 2119 | Missing Context Check | Medium |
| **16** | content.js | 326 | Silent Failure / CSP Bug | Medium |
| **17** | content.js | 641 | Silent Failure | Low |
| **18** | content.js | 1766 | Missing Null Check | Medium |
| **19** | content.js | 2308 | Missing Field | Medium |
| **20** | background.js | 3 | Logic Bug (Benign) | Low |
| **21** | copilot.js | 253 | Shadow DOM Bug | Medium |
| **22** | content.js | 822 | Regex Deprecation | Low |
| **23** | manifest.json | 66 | Performance | Medium |
| **24** | content.js | 2492 | Performance | Low |

---

# 🚨 TOP 5 MOST CRITICAL FIXES

> [!CAUTION]
> Fix these first — they directly break user-facing functionality.

### 1. **ISSUE #1 — `dbLoadApps` has NO user filter** (content.js:339)
Every query returns ALL applications to every user. Even if RLS covers you, this is the single most dangerous bug. Fix: add `username=eq.${currentUser.id}` to the query URL.

### 2. **ISSUE #3 — popup.js crashes for logged-out users** (popup.js:151)
Accessing `session.token` when `session` is `null` crashes the entire popup. Users who haven't logged in see a blank white popup. Fix: add null check before accessing `.token`.

### 3. **ISSUE #5 — XLSX export path is wrong** (content.js:2356)
`chrome.runtime.getURL('lib/xlsxbuilder.js')` should be `'src/lib/xlsxbuilder.js'`. Export XLSX is completely broken — it will never load the script.

### 4. **ISSUE #14 — Quick Extract skips Gemini when GEMINI_KEY is empty in memory** (content.js:2202)
`GEMINI_KEY` is loaded asynchronously, so on first click after login it may still be empty even though a key is saved. The "Extract & Save" button opens a blank form instead of extracting. Fix: load the key synchronously before the check or rely on `extractWithGemini`'s internal key load.

### 5. **ISSUE #2 — `callOllama` is called but never defined** (content.js:2459)
If engine is set to 'ollama' in localStorage, every AI chat message crashes. Fix: remove the dead ollama branch or add a clear error message.
