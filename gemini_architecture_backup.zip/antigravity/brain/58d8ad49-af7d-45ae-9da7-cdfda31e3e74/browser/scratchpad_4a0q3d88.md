# Typography Verification Plan: BSR Shopping Mall

- [ ] Open http://localhost:3000
- [ ] Verify Hero Section (Cormorant Garamond + Selective Italics)
- [ ] Verify Curated Collections Section
- [ ] Verify Why BSR Section
- [ ] Verify Navbar and Footer (Jost, uppercase)
- [ ] Capture screenshots for evidence

## Findings
- Hero Headline: N/A (Runtime Error)
- Navigation: N/A (Runtime Error)
- Italic Accents: N/A (Runtime Error)
- **Issue**: The application is crashing with a Supabase configuration error: "Your project's URL and Key are required to create a Supabase client!".
