---
name: headlessui-best-practices
description: Headless UI accessible component patterns. Use when building dropdowns, modals, tabs, comboboxes, or any interactive UI components that need full accessibility.
---

# Headless UI Best Practices

## Installation
```bash
npm install @headlessui/react
```

## Core Philosophy
- **Unstyled** — You control 100% of the styling
- **Accessible** — WCAG 2.1 compliant out of the box
- **Composable** — Render any HTML element with `as` prop

## Dialog (Modal)
```tsx
import { Dialog, DialogPanel, DialogTitle, Transition, TransitionChild } from '@headlessui/react';
import { Fragment, useState } from 'react';

function Modal() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button onClick={() => setIsOpen(true)}>Open Modal</button>

      <Transition show={isOpen} as={Fragment}>
        <Dialog onClose={() => setIsOpen(false)} className="relative z-50">
          {/* Backdrop */}
          <TransitionChild
            enter="ease-out duration-300" enterFrom="opacity-0" enterTo="opacity-100"
            leave="ease-in duration-200" leaveFrom="opacity-100" leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-black/30" />
          </TransitionChild>

          {/* Panel */}
          <div className="fixed inset-0 flex items-center justify-center p-4">
            <TransitionChild
              enter="ease-out duration-300" enterFrom="opacity-0 scale-95" enterTo="opacity-100 scale-100"
              leave="ease-in duration-200" leaveFrom="opacity-100 scale-100" leaveTo="opacity-0 scale-95"
            >
              <DialogPanel className="bg-white rounded-xl p-6 shadow-xl max-w-md w-full">
                <DialogTitle className="text-lg font-semibold">Confirm Action</DialogTitle>
                <p className="mt-2 text-gray-600">Are you sure? This cannot be undone.</p>
                <div className="mt-4 flex gap-3">
                  <button onClick={() => setIsOpen(false)}>Cancel</button>
                  <button onClick={() => { /* action */ setIsOpen(false); }}>Confirm</button>
                </div>
              </DialogPanel>
            </TransitionChild>
          </div>
        </Dialog>
      </Transition>
    </>
  );
}
```

## Menu (Dropdown)
```tsx
import { Menu, MenuButton, MenuItems, MenuItem } from '@headlessui/react';

function Dropdown() {
  return (
    <Menu as="div" className="relative">
      <MenuButton className="px-4 py-2 bg-indigo-600 text-white rounded-lg">
        Options
      </MenuButton>
      <MenuItems className="absolute mt-2 w-48 bg-white rounded-lg shadow-lg border p-1">
        <MenuItem>
          {({ active }) => (
            <button className={`${active ? 'bg-indigo-50' : ''} w-full text-left px-3 py-2 rounded`}>
              Edit
            </button>
          )}
        </MenuItem>
        <MenuItem>
          {({ active }) => (
            <button className={`${active ? 'bg-red-50 text-red-600' : ''} w-full text-left px-3 py-2 rounded`}>
              Delete
            </button>
          )}
        </MenuItem>
      </MenuItems>
    </Menu>
  );
}
```

## Tab Group
```tsx
import { Tab, TabGroup, TabList, TabPanel, TabPanels } from '@headlessui/react';

function Tabs() {
  return (
    <TabGroup>
      <TabList className="flex gap-2 border-b">
        <Tab className={({ selected }) =>
          `px-4 py-2 ${selected ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-gray-500'}`
        }>Overview</Tab>
        <Tab className={({ selected }) =>
          `px-4 py-2 ${selected ? 'border-b-2 border-indigo-600 text-indigo-600' : 'text-gray-500'}`
        }>Settings</Tab>
      </TabList>
      <TabPanels className="mt-4">
        <TabPanel>Overview content here</TabPanel>
        <TabPanel>Settings content here</TabPanel>
      </TabPanels>
    </TabGroup>
  );
}
```

## Available Components
| Component | What it does |
|-----------|-------------|
| `Dialog` | Modal / alert dialog |
| `Popover` | Floating panel triggered by button |
| `Menu` | Dropdown menu |
| `Listbox` | Custom select / dropdown |
| `Combobox` | Searchable autocomplete |
| `Switch` | Toggle switch |
| `RadioGroup` | Radio button group |
| `Tab` | Tab navigation |
| `Disclosure` | Expandable accordion |
| `Transition` | Enter/leave animations |

## Rules
1. **Always use Transition** for enter/leave animations
2. **Never remove focus management** — Headless UI handles it
3. **Use `as` prop** to render as any element: `<Menu as="nav">`
4. **Render props** give you state: `active`, `selected`, `open`
5. **Style with data attributes**: `data-[active]:bg-blue-500`
