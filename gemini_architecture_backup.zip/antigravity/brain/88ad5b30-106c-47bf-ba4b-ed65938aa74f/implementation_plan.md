# Fix Gemini Model Integration Error

The goal is to resolve the `404` / `models/gemini-1.5-flash not found` error reported by the user. We will switch to the stable `v1` API endpoint and provide a model selector to allow users to choose from available free-tier models, improving reliability and fulfilling an earlier feature request.

## User Review Required

> [!IMPORTANT]
> I am switching the API version from `v1beta` to `v1` for better stability with standard models. I am also adding a model selector in the UI.

## Proposed Changes

### [Component Name] Dashboard AI Logic

#### [MODIFY] [app.js](file:///c:/Users/janak/job-tracker-app/scripts/app.js)
-   **`renderAiBlaze`**: Add a dropdown to select between `gemini-1.5-flash` and `gemini-1.5-flash-8b`.
-   **`callGeminiBlaze`**: Use the selected model and switch the base URL to `v1`.
-   **Default Model**: Default to `gemini-1.5-flash` (stable).

## Open Questions

- None.

## Verification Plan

### Automated Steps
- **Execution**: Run `.\deploy.ps1` to push the fix live.
- **Rollback**: Standard git rollback if further errors occur.

### Manual Verification
- Ask the user to test the "Blaze it!" button again with the newly selected model(s).
