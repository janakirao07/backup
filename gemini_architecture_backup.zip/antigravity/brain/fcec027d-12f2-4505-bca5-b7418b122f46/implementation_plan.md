# Default to Today's Applications in Trackbar

The goal is to update the Applications view so that by default, it only shows applications from the current work day. Users will have the option to switch to "All" applications or select a specific date.

## Proposed Changes

### [scripts/app.js](file:///c:/Users/janak/job-tracker-app/scripts/app.js)

#### [MODIFY] Initialize `filterDate` to Today
- Change `let filterDate = '';` to `let filterDate = workTodayISO();` so the initial view is filtered to today's work day.

#### [MODIFY] Update `renderApplications()`
- Add a new "Filter Bar" in the applications section (above the table or within the header).
- Add buttons for **Today**, **All**, and a more integrated **Date Picker**.
- Update the filtering logic to properly handle these states.
- Ensure the selected filter is visually highlighted.

### [index.html](file:///c:/Users/janak/job-tracker-app/index.html)
- No changes needed to `index.html` structure as most UI is injected via `app.js`. However, I might add some CSS classes if needed for the new filter bar, or just use inline styles consistent with the current implementation.

## Open Questions
- Should "Select Date" open a calendar icon/dropdown, or is the current date input (which opens the browser's date picker) sufficient?
- Should the "Today" default also apply to the Dashboard's "Recent Applications" list, or just the main "Applications" page? (The user specifically mentioned "trackbar", which usually refers to the main list in this context).

## Verification Plan

### Manual Verification
- Open the "Applications" page and verify it defaults to today's date.
- Click "All" and verify all applications are shown.
- Click "Today" and verify only today's apps are shown.
- Use the date picker to select a specific date and verify filtering works.
- Check if the UI looks premium and follows the existing design language.
