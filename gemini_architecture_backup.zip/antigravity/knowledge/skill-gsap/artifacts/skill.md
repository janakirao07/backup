---
name: gsap-best-practices
description: GSAP (GreenSock Animation Platform) best practices. Use when creating scroll animations, timelines, page transitions, SVG morphing, or any complex web animations.
---

# GSAP Best Practices

## Installation
```bash
npm install gsap
# For React:
npm install @gsap/react
```

## Core Concepts

### Basic Tween
```javascript
import gsap from 'gsap';

// To — animate TO these values
gsap.to('.box', { x: 200, duration: 1, ease: 'power2.out' });

// From — animate FROM these values
gsap.from('.box', { opacity: 0, y: 50, duration: 0.8 });

// FromTo — animate FROM → TO
gsap.fromTo('.box', { opacity: 0 }, { opacity: 1, duration: 1 });
```

### Timeline — Sequence Animations
```javascript
const tl = gsap.timeline({ defaults: { duration: 0.8, ease: 'power3.out' } });

tl.from('.hero-title', { y: 100, opacity: 0 })
  .from('.hero-subtitle', { y: 50, opacity: 0 }, '-=0.4')   // Start 0.4s before previous ends
  .from('.hero-cta', { scale: 0, opacity: 0 }, '-=0.3')
  .from('.hero-image', { x: 100, opacity: 0 }, '<');          // Start at same time as previous
```

### Position Parameters
| Syntax | Meaning |
|--------|---------|
| `'-=0.5'` | Start 0.5s before previous ends (overlap) |
| `'+=0.5'` | Start 0.5s after previous ends (gap) |
| `'<'` | Start at same time as previous |
| `'<0.2'` | Start 0.2s after previous starts |
| `2` | Start at absolute time 2s |

## ScrollTrigger
```javascript
import { ScrollTrigger } from 'gsap/ScrollTrigger';
gsap.registerPlugin(ScrollTrigger);

// Animate on scroll
gsap.from('.section', {
  scrollTrigger: {
    trigger: '.section',
    start: 'top 80%',      // When top of trigger hits 80% of viewport
    end: 'bottom 20%',
    toggleActions: 'play none none reverse', // onEnter onLeave onEnterBack onLeaveBack
    // scrub: true,         // Tie animation to scroll position
    // pin: true,           // Pin element during animation
    // markers: true,       // Debug markers (remove in production!)
  },
  y: 100,
  opacity: 0,
  duration: 1,
});

// Scrub animation (moves with scroll)
gsap.to('.parallax-bg', {
  scrollTrigger: {
    trigger: '.parallax-section',
    start: 'top bottom',
    end: 'bottom top',
    scrub: 1,                // Smooth scrubbing (1 = 1s lag)
  },
  y: -200,
});
```

## React Integration
```tsx
import { useGSAP } from '@gsap/react';
import gsap from 'gsap';
import { useRef } from 'react';

function AnimatedComponent() {
  const containerRef = useRef(null);

  useGSAP(() => {
    // All animations here are auto-cleaned up
    gsap.from('.card', {
      y: 50,
      opacity: 0,
      stagger: 0.15,
      duration: 0.8,
      ease: 'power3.out',
    });
  }, { scope: containerRef }); // Scope to container

  return (
    <div ref={containerRef}>
      <div className="card">Card 1</div>
      <div className="card">Card 2</div>
      <div className="card">Card 3</div>
    </div>
  );
}
```

## Easing Guide
| Ease | Feel | Best for |
|------|------|----------|
| `power1.out` | Gentle deceleration | Subtle UI |
| `power2.out` | Smooth deceleration | Most animations |
| `power3.out` | Punchy deceleration | Hero entrances |
| `power4.out` | Dramatic stop | Impact moments |
| `back.out(1.7)` | Overshoot bounce-back | Playful UI |
| `elastic.out(1, 0.3)` | Springy bounce | Attention grabbers |
| `bounce.out` | Ball-drop bounce | Game-like UI |
| `expo.out` | Sharp deceleration | Modern/premium |
| `none` | Linear | Loading bars |

## Stagger Animations
```javascript
// Stagger children with delay between each
gsap.from('.list-item', {
  y: 40,
  opacity: 0,
  stagger: {
    each: 0.1,           // 0.1s between each
    from: 'start',       // 'start', 'end', 'center', 'edges', 'random'
    ease: 'power2.out',
  },
  duration: 0.6,
});
```

## Performance Rules
1. **Animate transforms + opacity** — `x`, `y`, `scale`, `rotation`, `opacity` (GPU-accelerated)
2. **Avoid animating**: `width`, `height`, `margin`, `padding`, `top`, `left` (trigger layout)
3. **Use `will-change`** sparingly — GSAP handles this automatically
4. **Kill animations on unmount** — Use `useGSAP` hook or `tl.kill()`
5. **Use `gsap.set()`** for instant property changes (no animation)
6. **Batch ScrollTriggers** — `ScrollTrigger.batch()` for many elements

## Common Patterns
```javascript
// Reveal on scroll
gsap.utils.toArray('.reveal').forEach(el => {
  gsap.from(el, {
    scrollTrigger: { trigger: el, start: 'top 85%' },
    y: 60, opacity: 0, duration: 0.8,
  });
});

// Text split animation (with SplitText plugin)
// Magnetic hover effect
// Smooth page transitions
// Parallax backgrounds
// Horizontal scroll sections
```
