# Implementation Plan: Securing SK Degree College Repository

The repository currently contains sensitive files (Excel reports with student data, internal tool logs, and scratch scripts) that are being tracked by Git. This plan aims to remove these files from the Git index and ensure they are properly ignored in the future.

## 1. Untrack Sensitive Files & Directories
We need to remove these from the Git index without deleting them locally.
- `project docs/` (Contains reports and student data)
- `scratch/` (Contains temporary scripts)
- `.planning/` (Internal planning artifacts)
- `.agents/` (Agent logs)
- `.code-review-graph/` (Tool data)
- `graphify-out/` (Tool data)

## 2. Update `.gitignore`
- Add `project docs/`
- Add `scratch/`
- Ensure all other internal tool directories are correctly listed.

## 3. Implement Security Headers
- Update `next.config.ts` to include standard security headers:
  - `X-Frame-Options: DENY`
  - `X-Content-Type-Options: nosniff`
  - `Referrer-Policy: strict-origin-when-cross-origin`
  - `Permissions-Policy` (restricted)
  - `Strict-Transport-Security`

## 4. Verification
- Run `git ls-files -i --exclude-standard` to verify no ignored files are tracked.
- Run `git status` to ensure clean state.
