# Figma to Code

## Translation rules
- Auto Layout (Horizontal) -> `flex flex-row`
- Auto Layout (Vertical) -> `flex flex-col`
- Space Between -> `justify-between`
- Padding -> `p-4` or `px-4 py-2`
- Hug Contents -> `w-fit h-fit`
- Fill Container -> `flex-1` or `w-full`