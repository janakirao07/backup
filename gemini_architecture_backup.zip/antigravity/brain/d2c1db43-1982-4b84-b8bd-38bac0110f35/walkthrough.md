# Walkthrough - Fixing code-review-graph Execution Issue

I have successfully performed a clean reinstallation of `code-review-graph` and identified why it was not being found in your terminal.

## Changes Made

### 1. Clean Reinstallation
- Uninstalled the previous (potentially broken) installation of `code-review-graph`.
- Reinstalled the latest version (2.1.0) using `pip`.

### 2. Executable Verification
- Located the executable at:
  `C:\Users\janak\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\LocalCache\local-packages\Python313\Scripts\code-review-graph.exe`
- Verified that the tool runs correctly when called with its full path.

## How to Fix the PATH Permanently

To use `code-review-graph` without typing the full path, you need to add the following directory to your system's **Environment Variables**:

> [!IMPORTANT]
> **Directory to add to PATH:**
> `C:\Users\janak\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\LocalCache\local-packages\Python313\Scripts`

### Steps to add to PATH on Windows:
1. Press `Win + R`, type `sysdm.cpl`, and hit Enter.
2. Go to the **Advanced** tab and click **Environment Variables**.
3. Under **User variables**, find the **Path** variable and click **Edit**.
4. Click **New** and paste the directory path above.
5. Click **OK** on all windows.
6. **Restart your terminal or IDE** (Cursor/VS Code) for the changes to take effect.

## Verification Result
- Running the tool manually:
  ```powershell
  & "C:\Users\janak\AppData\Local\Packages\PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0\LocalCache\local-packages\Python313\Scripts\code-review-graph.exe" --version
  ```
- **Result:** `code-review-graph, version 2.1.0`
