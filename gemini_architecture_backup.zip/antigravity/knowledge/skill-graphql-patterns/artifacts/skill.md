# GraphQL Patterns

## Server Setup (Apollo)
```ts
import { ApolloServer } from '@apollo/server';
const typeDefs = `#graphql
  type Job { id: ID! title: String! }
  type Query { jobs: [Job] }
`;
const resolvers = { Query: { jobs: () => db.jobs.findMany() } };
const server = new ApolloServer({ typeDefs, resolvers });
```

## Client Setup
```tsx
import { ApolloClient, InMemoryCache, gql, useQuery } from '@apollo/client';
const client = new ApolloClient({ uri: '/graphql', cache: new InMemoryCache() });
const GET_JOBS = gql`query GetJobs { jobs { id title } }`;
function JobList() { const { data } = useQuery(GET_JOBS); return <div>{data?.jobs.map(j => j.title)}</div>; }
```