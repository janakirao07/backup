# Academics Page Preview Checklist

- [x] Navigate to http://localhost:3000/academics
- [x] Wait 5 seconds for animations
- [x] Capture hero section screenshot
- [ ] Scroll down to content
- [ ] Capture content (stats, sidebar, accordions) screenshot
- [x] Analyze visual quality and report findings

## Findings
- The academics page (and likely others) is broken due to a runtime error: `TypeError: supabase.auth.onAuthStateChange is not a function`.
- This is likely caused by missing Supabase credentials or a mismatch in the `supabase` client initialization in `lib/supabase.ts`.
- The Next.js error overlay is visible, preventing any preview of the 3D backgrounds or content.
- Need to check other pages to confirm if this is a global layout issue.
