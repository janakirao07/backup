# Phase 2: Job Board & Recruitment — PLAN

**Phase**: 2 of 3 | **Depends on**: Phase 1 ✅ | **Requirements**: WEB-04, WEB-05, ADM-04

## ✅ Success Criteria
1. Visitor can **browse and filter** job postings on the public site
2. Visitor can **upload a resume** and apply for a specific role
3. Admin can **create, edit**, and **view applications** for job postings

---

## Plan 02-01: Careers Frontend (Public)

### 02-01-A: Data Layer & API Routes
| File | Purpose |
|------|---------|
| `src/lib/validations.ts` | Add `jobSchema` + `applicationSchema` |
| `src/app/api/jobs/route.ts` | `GET` — list active jobs with filters |
| `src/app/api/jobs/[id]/route.ts` | `GET` — single job details |
| `src/app/api/applications/route.ts` | `POST` — submit application + resume |

**Job Model**: title, department, location, type, description, requirements, salary_range, is_active  
**Application Model**: job_id, name, email, phone, resume_url, cover_letter, experience_years, status

### 02-01-B: Careers Listing Page
| File | Purpose |
|------|---------|
| `src/app/(public)/careers/page.tsx` | Job listings with SEO metadata |
| `src/components/sections/JobFilters.tsx` | Search + Department + Location + Type filters |
| `src/components/sections/JobCard.tsx` | Individual job card with badge, CTA |

### 02-01-C: Job Detail & Application
| File | Purpose |
|------|---------|
| `src/app/(public)/careers/[id]/page.tsx` | Full job details + apply section |
| `src/components/sections/ApplicationForm.tsx` | Name, email, resume upload (drag-drop), cover letter |

---

## Plan 02-02: Recruitment Management (Admin)

### 02-02-A: Admin Job CRUD
| File | Purpose |
|------|---------|
| `src/app/admin/(dashboard)/jobs/page.tsx` | Job listing table with status toggle |
| `src/app/admin/(dashboard)/jobs/new/page.tsx` | Create new job form |
| `src/app/admin/(dashboard)/jobs/[id]/edit/page.tsx` | Edit existing job |
| `src/components/admin/JobForm.tsx` | Shared create/edit form component |
| `src/app/api/admin/jobs/route.ts` | `POST` create job |
| `src/app/api/admin/jobs/[id]/route.ts` | `PUT` update, `PATCH` toggle status |

### 02-02-B: Application Review
| File | Purpose |
|------|---------|
| `src/app/admin/(dashboard)/applications/page.tsx` | Application table with filters |
| `src/components/admin/ApplicationDetail.tsx` | Modal: full info, resume download, status change |
| `src/app/api/admin/applications/route.ts` | `GET` list with filters |
| `src/app/api/admin/applications/[id]/route.ts` | `PATCH` update status/notes |

---

## Impact Summary

| Category | Count |
|----------|-------|
| New files | ~18 |
| Modified files | ~5 (validations, sidebar, navbar, dashboard) |
| New API routes | 8 |
| New pages | 6 (2 public + 4 admin) |

## Technical Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Resume storage | Supabase Storage (local fallback) | Scalable, secure signed URLs |
| File types | PDF/DOCX only, 5MB max | Standard resume formats |
| Application pipeline | 4 stages: new → reviewing → shortlisted → rejected | Standard recruitment flow |
| Job data | Demo JSON initially | No DB dependency for development |

---

> [!IMPORTANT]
> **Ready to execute?** Say `yes` or `/gsd-execute-phase 2` to start building.
> Want changes? Let me know what to adjust before I start coding.
