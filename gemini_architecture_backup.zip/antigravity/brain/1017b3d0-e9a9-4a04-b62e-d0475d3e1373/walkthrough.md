# Walkthrough: Job Extraction Fix

The job extraction feature was failing to populate "Company Name" and "Job Title" because it was using an invalid Gemini model name (`gemini-2.5-flash`). I corrected this to the stable `gemini-1.5-flash` and updated the version information across the application.

## Changes Made

### AI Model Update
- Updated the API endpoint URL in `scripts/content.js` to use `gemini-1.5-flash` instead of `gemini-2.5-flash`.
- Corrected the displayed model version in the "About" section of both `scripts/content.js` and `scripts/app.js`.

### Code Reference
- **[content.js](file:///c:/Users/janak/job-tracker-app/scripts/content.js)**
    - Changed line 618: `gemini-2.5-flash` → `gemini-1.5-flash`
    - Changed line 900: `Gemini 2.5 Flash` → `Gemini 1.5 Flash`
- **[app.js](file:///c:/Users/janak/job-tracker-app/scripts/app.js)**
    - Changed line 1286: `Google Gemini 2.5 Flash` → `Google Gemini 1.5 Flash`

## Verification
- Performed a global search for the old model string to ensure no references remain.
- Verified that the `res.ok` check and JSON parsing logic are robust enough to handle the correct API response now that the model name is valid.

> [!TIP]
> Users may need to refresh the extension or the page for the changes to take effect in the browser.
