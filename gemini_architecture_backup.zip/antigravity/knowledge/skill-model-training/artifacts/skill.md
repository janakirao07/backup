# ML Model Training Best Practices

## Data Preparation
```python
from sklearn.model_selection import train_test_split

# Standard split ratios
# train: 70-80%, val: 10-15%, test: 10-15%
X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)
X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42, stratify=y_temp)

# Normalization — fit on train only, transform all
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)   # fit + transform
X_val = scaler.transform(X_val)           # transform only
X_test = scaler.transform(X_test)         # transform only
```

## Hyperparameter Tuning
```python
# Key hyperparameters to tune (priority order):
# 1. Learning rate (most impactful)
# 2. Batch size (32, 64, 128, 256)
# 3. Model capacity (layers, hidden units)
# 4. Regularization (dropout, weight decay)
# 5. Optimizer (Adam > SGD for most cases)

# Learning rate finder approach
learning_rates = [1e-5, 3e-5, 1e-4, 3e-4, 1e-3, 3e-3, 1e-2]
# Run short training (2-3 epochs) with each, pick the one with steepest loss decline
```

## Learning Rate Scheduling
```python
import torch.optim as optim

optimizer = optim.AdamW(model.parameters(), lr=1e-3, weight_decay=0.01)

# Option 1: Cosine Annealing (recommended for most cases)
scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=num_epochs)

# Option 2: ReduceLROnPlateau (adaptive — good when unsure)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=5)

# Option 3: OneCycleLR (fast convergence)
scheduler = optim.lr_scheduler.OneCycleLR(optimizer, max_lr=1e-3, steps_per_epoch=len(train_loader), epochs=num_epochs)

# Option 4: Warmup + Cosine (for transformers)
from torch.optim.lr_scheduler import LinearLR, CosineAnnealingLR, SequentialLR
warmup = LinearLR(optimizer, start_factor=0.1, total_iters=warmup_steps)
cosine = CosineAnnealingLR(optimizer, T_max=num_epochs - warmup_steps)
scheduler = SequentialLR(optimizer, [warmup, cosine], milestones=[warmup_steps])
```

## Early Stopping
```python
class EarlyStopping:
    def __init__(self, patience=10, min_delta=1e-4):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.should_stop = False

    def __call__(self, val_loss):
        if self.best_loss is None:
            self.best_loss = val_loss
        elif val_loss > self.best_loss - self.min_delta:
            self.counter += 1
            if self.counter >= self.patience:
                self.should_stop = True
        else:
            self.best_loss = val_loss
            self.counter = 0

early_stopping = EarlyStopping(patience=10)
```

## Evaluation Metrics
```python
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score
)

# Classification
print(classification_report(y_true, y_pred))
# Includes: precision, recall, f1, support per class

# For imbalanced datasets — use F1 or AUC, NOT accuracy
f1 = f1_score(y_true, y_pred, average='weighted')
auc = roc_auc_score(y_true, y_proba, multi_class='ovr')

# Regression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
rmse = mean_squared_error(y_true, y_pred, squared=False)
```

## Experiment Tracking
```python
# Minimal tracking with CSV
import csv, datetime

def log_experiment(filepath, **kwargs):
    kwargs['timestamp'] = datetime.datetime.now().isoformat()
    file_exists = os.path.exists(filepath)
    with open(filepath, 'a', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=kwargs.keys())
        if not file_exists:
            writer.writeheader()
        writer.writerow(kwargs)

log_experiment('experiments.csv', lr=1e-3, batch_size=64, epochs=50, val_acc=0.94, val_loss=0.18)
```

## Data Augmentation (Vision)
```python
from torchvision import transforms

train_transform = transforms.Compose([
    transforms.RandomResizedCrop(224),
    transforms.RandomHorizontalFlip(),
    transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
    transforms.RandomRotation(15),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

val_transform = transforms.Compose([   # NO augmentation for validation
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])
```

## Common Mistakes
- Training on test data or leaking validation data into training
- Not setting random seeds for reproducibility (`torch.manual_seed(42)`)
- Using accuracy on imbalanced datasets
- Not monitoring for overfitting (train loss ↓ but val loss ↑)
- Forgetting to unfreeze layers in transfer learning
- Not saving the best model checkpoint (only the last)
