# Professional Resume Dashboard Upgrade

This plan transforms the current single-column tool into a high-end, split-screen professional dashboard designed for high-volume, realistic job applications.

## Proposed Features

### 1. The "Live Mirror" Preview [Visual]
- **Split-Screen Layout**: Move the input fields to a collapsible sidebar on the left and show a **Live Page Preview** on the right.
- **A4 Simulation**: The preview will use the exact A4 aspect ratio, Arial-only typography, and 0.5" margins to match the final Word document perfectly.

### 2. ATS Optimizer [Intelligence]
- **Match Field**: Add a new (optional) textarea for a "Target Job Description."
- **Analysis Engine**: A script that extracts keywords from the Job Description and checks them against your Skills and Experience.
- **Visual Feedback**: Show a "Match Score" (%) and a list of "Found" vs "Missing" keywords.

### 3. Multi-Profile & Vault [Data]
- **Profile Switching**: A dropdown to select between saved profiles (e.g., "Standard", "Cloud Focused", "Management").
- **Import/Export**: Buttons to download your entire configuration as a `backup.json` and upload it back.

### 4. UI/UX Polishing
- **Glassmorphism Sidebar**: A sleek, semi-transparent navigation bar for profile fields.
- **Section Reordering**: Add "Up/Down" buttons to the sections? (Maybe in a future phase).
- **Auto-Capitalization**: Ensure section headers are consistently formatted during input.

## User Review Required

> [!IMPORTANT]
> To achieve the **Split-Screen Dashboard**, I'll need to restructure the layout significantly. This will make it look much more like a premium SaaS application (like Canva or Overleaf).
>
> **Which feature should we prioritize first?**
> 1. The **Live Preview** (Visual impact)
> 2. The **ATS Keyword Optimizer** (Functional utility)
> 3. The **Multi-Profile Vault** (Data management)

## Verification Plan
1. **Layout Integrity**: Ensure the split-screen works on both wide monitors and laptops.
2. **Preview Accuracy**: Verify that the text in the "Live Mirror" stays perfectly synced with the inputs.
3. **Keyword Logic**: Test the ATS scanner with sample Job Descriptions to ensure keywords are identified correctly.
