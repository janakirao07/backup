# Anthropic SDK

## Message Generation
```ts
import Anthropic from '@anthropic-ai/sdk';
const anthropic = new Anthropic();
const msg = await anthropic.messages.create({
  model: 'claude-3-5-sonnet-20240620',
  max_tokens: 1000,
  system: 'You are an AI assistant.',
  messages: [{ role: 'user', content: 'Hello' }],
});
```