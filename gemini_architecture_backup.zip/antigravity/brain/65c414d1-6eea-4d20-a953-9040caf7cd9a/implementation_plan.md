# Remove Sliders from Sidebar and Panels

The user wants to remove "sliders" from the app, specifically mentioning the "side". This refers to both the **toggle switches** (which use a slider-style switch) and potentially the **sidebar scrollbar**. I will replace the remaining toggle switches with button-styled toggles and hide visible scrollbars in the sidebar while maintaining scroll function.

## User Review Required

> [!IMPORTANT]
> I am hiding the scrollbars in the sidebar. You can still scroll using your mouse wheel or touch, but the visual "slider" thumb will be gone.
> 
> I am also replacing the remaining "Copilot Beta" toggle switch in the floating side panel with a clean "ON/OFF" button.

## Proposed Changes

### Floating Sidebar (AI Blaze)

#### [MODIFY] [content.js](file:///c:/Users/janak/job-tracker-app/src/scripts/content.js)
- Update `renderSettings` HTML to replace the `rjd-switch` checkbox with a styled `<button>`.
- Update the JavaScript initialization to set the button's text and background based on `rjd_v2_enabled`.
- Update the `onclick` handler to toggle the state.

#### [MODIFY] [sidebar.css](file:///c:/Users/janak/job-tracker-app/src/styles/sidebar.css)
- Add CSS to hide scrollbars globally within the `#rjd-sidebar` while keeping content scrollable.

### Dashboard Application

#### [MODIFY] [app.html](file:///c:/Users/janak/job-tracker-app/src/pages/app.html)
- Add CSS to hide the scrollbar in the `.sidebar-nav` element.

## Verification Plan

### Automated Tests
- Run `node --check` on `app.js` and `content.js` to ensure no syntax errors.

### Manual Verification
- Deploy using `./local-deploy.ps1`.
- Verify the "v2.0 Copilot Beta" toggle in the floating sidebar (on any job site) is now a button.
- Verify the main dashboard sidebar (left side) does not show a scrollbar thumb even when hovering or scrolling.
