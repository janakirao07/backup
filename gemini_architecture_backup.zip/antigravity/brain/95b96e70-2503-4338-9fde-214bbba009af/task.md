# Floating Resume Builder Extension

- [ ] Extract `docx.js` core from `Vinay_Resume_Builder_OFFLINE.html`
- [ ] Update `manifest.json` with new permissions and scripts
- [ ] Implement section detection logic in `content.js`
- [ ] Add the "Download .docx" generation function to `content.js`
- [ ] Overhaul `content.css` for the "Mini-Builder" layout
- [ ] Add the "Sync Assistant" button to `Vinay_Resume_Builder_OFFLINE.html`
- [ ] Verify offline-to-extension sync and Word generation
