# Prompt Master - Extended Tool Templates

This document contains templates and guidelines for advanced research tools, developer agents, local LLMs, and creative image/video pipelines.

---

## 1. Developer Agents & IDE tools

### Cursor / Windsurf
- File path + function name + current behavior + desired change + do-not-touch list + language and version.
- Never give a global instruction without a file anchor.
- "Done when:" is required — defines when the agent stops editing.
- For complex tasks: split into sequential prompts.

### Cline (formerly Claude Dev)
- Agentic VS Code extension — autonomously edits files, runs terminal commands, uses browser tools.
- Starting state + target state + file scope + stop conditions + approval gates.
- Add "Ask before running terminal commands" to prevent unwanted actions.

### Claude Code
- Agentic — runs tools, edits files, executes commands autonomously.
- Starting state + target state + allowed actions + forbidden actions + stop conditions + checkpoints.
- Stop conditions are MANDATORY.
- Always scope to specific files and directories.

### GitHub Copilot
- Write the exact function signature, docstring, or comment immediately before invoking.
- Describe input types, return type, edge cases, and what the function must NOT do.

---

## 2. Full-Stack Generators & Orchestrators

### Bolt / v0 / Lovable / Figma Make / Google Stitch
- Full-stack generators default to bloated boilerplate — scope it down explicitly.
- Always specify: stack, version, what NOT to scaffold, clear component boundaries.
- Add "Do not add authentication, dark mode, or features not explicitly listed".

### Devin / SWE-agent
- Fully autonomous — can browse web, run terminal, write and test code.
- Very explicit starting state + target state required.
- Scope the filesystem: "Only work within /src. Do not touch infrastructure, config, or CI files."

### Research & Orchestration (Perplexity, Manus AI)
- Perplexity search mode: specify search vs analyze vs compare. Add citation requirements.
- Manus and Perplexity Computer: describe the end deliverable. They decompose internally.

---

## 3. Creative Image, Video, & Audio Pipelines

### DALL-E 3
- Prose description works. Add "do not include text in the image unless specified."
- Describe foreground, midground, background separately.

### Stable Diffusion
- `(word:weight)` syntax. CFG 7-12. Negative prompt is MANDATORY.
- Steps 20-30 for drafts, 40-50 for finals.

### SeeDream
- Specify art style explicitly (anime, cinematic, painterly) before scene content.
- Mood and atmosphere descriptors work well.

### Reference Editing
- Detect when user wants to modify an existing image.
- Build the prompt around the delta ONLY — what changes, what stays the same.

### ComfyUI
- Output two separate blocks: Positive Prompt and Negative Prompt. Never merge them.

### Voice AI (ElevenLabs)
- Specify emotion, pacing, emphasis markers, and speech rate directly.
- Use SSML-like markers for emphasis.

### Video AI (Sora, Runway, Kling, LTX Video, Luma)
- Describe shot type and camera movement (dolly, static, crane) explicitly.
- Reference cinematic lighting setups, lens types, and color grading.

---

## 4. Other LLM Models

### Qwen 2.5 (instruct variants)
- Clear system prompt defining the role. Works well with JSON schemas.

### Qwen3 (thinking mode)
- Treat exactly like o3 — short clean instructions, no CoT, no scaffolding.

### Ollama (local model deployment)
- Ask which model is running. Shorter simpler prompts outperform complex ones.

### DeepSeek-R1
- Reasoning-native — do NOT add CoT instructions. Short clean instructions only.

### MiniMax (M2.7 / M2.5)
- OpenAI-compatible API. Temperature must be between 0 and 1.
