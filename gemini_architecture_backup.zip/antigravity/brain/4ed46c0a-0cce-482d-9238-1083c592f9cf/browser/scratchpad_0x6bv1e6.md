# Task: Review Performance Report

## Checklist
- [x] Open the performance report file: `c:\Users\janak\Downloads\_Projects\SK degree college\sk-degree-college-page.vercel.app-performance report.html`
- [x] Extract key performance metrics:
    - [x] LCP: 15.8 s
    - [x] FID/INP: TBT (Total Blocking Time) is 1,630 ms (Lighthouse proxy for FID/INP)
    - [x] CLS: 0.003
    - [x] FCP: 2.7 s
- [x] Identify top performance optimization suggestions.
- [ ] Provide a detailed breakdown of findings.

## Findings
- Metrics:
    - Performance Score: 37/100
    - FCP: 2.7 s (Needs Improvement)
    - LCP: 15.8 s (Poor)
    - TBT: 1,630 ms (Poor)
    - CLS: 0.003 (Good)
    - Speed Index: 7.5 s
- Optimization Suggestions (Top Insights):
    1. Improve image delivery (Est savings: 914 KiB)
    2. Eliminate render-blocking resources
    3. Use efficient cache lifetimes (Est savings: 643 KiB)
    4. Font display: Ensure text remains visible during webfont load (Est savings: 40 ms)
    5. Reduce legacy JavaScript (Est savings: 14 KiB)
    6. Minimize forced reflows
