# Job Tracker App Fixes Checklist

- `[x]` Create `config.js` with centralized credentials
- `[x]` Update `manifest.json` to include `config.js` and allow localhost for `externally_connectable`
- `[x]` Modify `background.js` to use config
- `[x]` Modify `app.js` to use config and parse `EXT_ID` correctly
- `[x]` Modify `content.js` to use config and fix date logic
- `[x]` Modify `popup.js` to use config
- `[x]` Inject `config.js` into HTML files (`index.html`, `app.html`, `popup.html`)
- `[x]` Run syntax checks
- `[x]` Commit changes to git
