# Implementation Plan — Mobile Usability Fixes

The current dashboard hides the sidebar on mobile devices (screens smaller than 768px), which leaves users without any way to navigate between pages (Dashboard, Settings, etc.). I will add a mobile-friendly navigation menu and ensure the tables and stats are fully responsive.

## User Review Required

> [!IMPORTANT]
> I will be adding a "Hamburger Menu" (three horizontal lines) to the top bar on mobile screens. This will allow users to open a mobile-specific navigation drawer.

## Proposed Changes

### [UI/UX]

#### [MODIFY] [app.html](file:///c:/Users/janak/job-tracker-app/pages/app.html) (and consequently index.html)
- **Navigation**: Add a hamburger menu button to the `.topbar` that only appears on mobile.
- **Mobile Drawer**: Add a hidden mobile-specific navigation menu that slides in when the hamburger icon is tapped.
- **CSS Improvements**: 
    - Adjust `.stats-grid` to stack better on very small screens.
    - Ensure tables use `overflow-x: auto` so they don't break the layout.
    - Add styles for the mobile menu drawer.

#### [MODIFY] [app.js](file:///c:/Users/janak/job-tracker-app/scripts/app.js)
- Add logic to toggle the mobile menu drawer when the hamburger icon is clicked.

## Verification Plan

### Automated Tests
- I will use the **Browser tool** to simulate different mobile device sizes (iPhone SE, Pixel 7) and verify the menu appears and functions correctly.

### Manual Verification
- Deploy to Vercel and ask you to check on your mobile device.
