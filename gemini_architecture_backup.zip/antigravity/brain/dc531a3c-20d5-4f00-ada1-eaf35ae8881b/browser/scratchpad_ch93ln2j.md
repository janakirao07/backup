# ML-Pipeline Testing Workflow

## Checklist
- [x] Navigate to http://localhost:3030
- [x] Test 1: "🧠 Stroke" Sample
    - [x] Select Sample
    - [x] Predict
    - [x] Capture Screenshot
    - [x] Record results
- [x] Test 2: "✅ Healthy Control" Sample
    - [x] Select Sample
    - [x] Predict
    - [x] Capture Screenshot
    - [x] Record results
- [x] Test 3: "🩸 T2DM Patient" Sample
    - [x] Select Sample
    - [x] Predict
    - [x] Capture Screenshot
    - [x] Record results
- [x] Verify EDA Correlation Matrix
    - [x] Switch to EDA Tab
    - [x] Wait & Screenshot
    - [x] Verify Labels
- [x] Check Console Logs

## Test Results
- Stroke: Stroke (52.2% Ensemble Confidence)
- Healthy: Healthy (Control) (93.5% Ensemble Confidence)
- T2DM: Type 2 Diabetes (57.8% Ensemble Confidence)
- EDA Labels Verified: No (Labels are still the old ones: BMI, Glucose, LDL, HDL, SBP, DBP, HR, Age)
- Console Errors: None observed.
- Feature Importance Verified: Yes (Uses new computed values: BMI, CVD History, Hypertension History, Blood Glucose, Age, Smoking, Gender)
