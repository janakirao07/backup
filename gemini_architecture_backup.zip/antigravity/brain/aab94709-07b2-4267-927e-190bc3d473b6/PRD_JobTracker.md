# Product Requirements Document (PRD)
## Job Tracker — AI-Powered Job Application Manager

---

## 1. Product Overview

**Product Name:** Job Tracker  
**Type:** Chrome Extension + Progressive Web App (PWA) Dashboard  
**Tagline:** *"Your Job Search, Supercharged."*  
**Target Audience:** Job seekers — recent graduates, career switchers, and employed professionals managing active job hunts.  
**Core Value Proposition:** Auto-capture job applications from any job board using AI, track every application in a premium dashboard, and generate tailored resumes — all in one place, for free.

---

## 2. User Personas

| Persona | Description | Pain Point |
|---|---|---|
| **Recent Graduate** | Entry-level job seeker applying to 20–50+ jobs | Loses track of where they applied |
| **Career Switcher** | Employed professional hunting quietly | Needs to manage search without disrupting current role |
| **Power Applicant** | Applying heavily across multiple platforms | Spends too much time copy-pasting job info into spreadsheets |

---

## 3. Product Architecture

The app has **two surfaces**:

### 3.1 Landing Page (`index.html`)
A marketing/conversion page for new users.

### 3.2 Web Dashboard (`dashboard.html`)
The authenticated single-page app (SPA) where users manage their job search.

---

## 4. Landing Page (`index.html`)

### 4.1 Visual Style
- **Design Theme:** Dark Cinematic Aurora
- **Background:** Deep dark (`#050510`) with animated floating aurora orbs (indigo, violet, cyan) — blurred radial gradients that drift continuously
- **Noise overlay:** Subtle fractal noise texture at 3% opacity
- **Typography:**
  - Display: `Sora` (800, 700 weight)
  - Body: `DM Sans` (300–700 weight)
  - Mono: `JetBrains Mono`
- **Accent Colors:** Indigo `#6366f1`, Violet `#8b5cf6`, Cyan `#06b6d4`, Purple `#a855f7`
- **Text:** Near-white `#f0f0ff`, secondary `#9898b8`, muted `#5a5a7a`

### 4.2 Navigation Bar
- Fixed position, full-width
- Frosted glass background (`rgba(5,5,16,0.7)` + `backdrop-filter: blur(20px)`)
- Shrinks padding on scroll (`.scrolled` state)
- **Logo:** Icon + "Job Tracker" text
- **Nav Links:** Features | How It Works | Privacy
- **CTA Button:** "Get Started →" (gradient indigo-to-violet, glowing box-shadow)

### 4.3 Hero Section
- **Full viewport height**, centered text
- **Badge:** Animated green pulsing dot + "AI-Powered Chrome Extension"
- **H1:** Giant gradient text — *"Your Job Search, Supercharged."*
  - Gradient: white → lavender → cyan → violet (left-to-right)
  - Font size: fluid, `clamp(42px, 7vw, 78px)`, letter-spacing `-2.5px`
- **Subtitle:** 16–20px, secondary color, max-width 560px
- **CTA Buttons:**
  1. Primary: "Get Started Free →" (gradient fill)
  2. Secondary: "See Features ↓" (glass border)
- **Hero Mockup:** Browser window mockup below CTAs
  - Shows a mini dashboard with: sidebar nav, 4 stat cards (Total, Applied, Interview, Offer), and a data table with 3 sample rows with status badges

### 4.4 Features Section (Bento Grid)
- Section label: uppercase monospace "WHAT YOU GET"
- H2: *"Everything You Need to Land Your Dream Job"*
- **Bento grid layout (3 columns):**

| Card | Icon | Title | Description |
|---|---|---|---|
| Featured (2-col) | 🧩 | Chrome Extension | Auto-captures from LinkedIn, Indeed, Glassdoor |
| Standard | 🔥 | AI Blaze | In-app AI assistant powered by Gemini |
| Standard | 📄 | Resume Engine | AI-tailored DOCX resume generation |
| Featured (2-col) | ✅ | ATS Eligibility Check | Pre-apply AI match score |
| Standard | 🌙 | Premium Dark Mode | Light & dark themes |

- Cards: `rgba(15,15,35,0.6)` glass background, subtle border, hover lifts + inner glow

### 4.5 How It Works (3 Steps)
- Section label + H2 + subtitle
- **3 numbered step cards** in a row with a decorative gradient line connecting them:
  1. Install the Extension
  2. Browse & Capture
  3. Track & Land
- Each step has a numbered badge (gradient square → 52px, glowing shadow), title, description

### 4.6 Extension Demo Section
- Two-column layout: Text left, visual right
- **Left:** Section label, H2, subtitle, bullet list (3 checkmarks), CTA button
- **Right:** Floating animated extension popup mockup
  - Shows extracted job: "Senior React Developer" at "Netflix", "Highly Eligible (92%)"
  - Has a "Capture Application ✨" button
  - Mockup floats up and down continuously (`float-ext` animation)
  - Violet glow orb behind it

### 4.7 Testimonials (3 Cards)
- 3-column grid
- Each card: dark glass background, 5-star rating, italic quote, avatar emoji + name + role
- Hover: lifts + accent border + deep shadow
- Sample users: Sarah K. (Recent Graduate), Mike T. (Career Switcher), Alex P. (Software Engineer)

### 4.8 Stats Section
- 4 stats in a row, large gradient numbers:
  - **∞** Jobs Trackable
  - **6+** AI Features
  - **3s** Capture Time
  - **$0** Forever Free

### 4.9 CTA Section
- Centered card with gradient border glow
- H2: *"Ready to Supercharge Your Job Search?"*
- Subtitle + large CTA button "Start Tracking Now →"

### 4.10 Footer
- Simple footer: copyright left, "Privacy Policy" + "GitHub" links right

---

## 5. Dashboard App (`dashboard.html`)

### 5.1 Visual Style & Design System
- **Theme:** "Refined Technical Luxury" — supports **Light** and **Dark** mode
- **Light Mode:** Background `#f4f4f5`, cards white, sidebar `#0c0c0f`
- **Dark Mode:** Background `#09090b`, cards `#18181b`, sidebar `#09090b`
- **Accent:** Indigo `#6366f1`, secondary accent violet `#8b5cf6`
- **Typography:** `Outfit` (display + body), `JetBrains Mono` (code/labels)
- **Border radius:** Cards 18px, modals 22px, buttons 10–12px
- **Background texture:** Dot-grid pattern (radial dots, masked ellipse) + noise overlay

#### Status Badge Colors
| Status | Background | Text Color |
|---|---|---|
| Applied | `rgba(99,102,241,0.1)` | `#6366f1` indigo |
| Interview | `rgba(16,185,129,0.1)` | `#10b981` green |
| Offer | `rgba(16,185,129,0.15)` | `#059669` dark green |
| Done | `rgba(245,158,11,0.1)` | `#f59e0b` amber |
| Rejected | `rgba(239,68,68,0.1)` | `#ef4444` red |
| Skipped | `rgba(113,113,122,0.1)` | `#71717a` gray |

### 5.2 App Layout
```
┌─────────────────────────────────────── App Shell ────────────────────────────────┐
│  ┌──────────┐  ┌──────────────────────────────────────────────────────────────┐ │
│  │          │  │                    Top Bar (sticky, frosted glass)          │ │
│  │ Sidebar  │  ├──────────────────────────────────────────────────────────────┤ │
│  │ (260px)  │  │                                                              │ │
│  │ fixed    │  │                     Main Content Area                       │ │
│  │          │  │                                                              │ │
│  └──────────┘  └──────────────────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────────────────────────────────┘
```

### 5.3 Sidebar
- **Fixed left**, dark background (`#0c0c0f`), 260px wide
- **Logo section:** icon + "Job Tracker" text (bottom border separator)
- **User section:** gradient ring avatar (initials), user name, email (truncated)
- **Navigation** — two groups:
  - **Main:** Dashboard | Applications | AI Blaze | Job Search
  - **Manage:** Settings | Export
  - **Info:** Privacy | About
- Each nav item: icon (SVG, 18px stroke) + label
- Active state: accent glow left-bar (3px), accent-tinted background, glowing SVG icon
- **Footer:** Light/Dark theme toggle button + Sign Out button

### 5.4 Top Bar
- **Sticky**, frosted glass (`backdrop-filter: blur(16px)`)
- **Left:** Page title (current section)
- **Right:** Count badge (e.g., "47 apps") + optional action buttons

### 5.5 Mobile Navigation
- Sidebar hidden on mobile
- ☰ hamburger button in top bar
- Slide-in drawer overlay (from left, 280px) with backdrop blur
- Identical nav content as sidebar

---

## 6. Dashboard Pages / Screens

### 6.1 Authentication Screens

#### Sign In / Sign Up
- Full-screen gradient background: `135deg, #4f46e5 → #7c3aed → #a855f7`
- Decorative blurred circles (top-right, bottom-left)
- **Card** (420px max-width, rounded 20px, white background):
  - **Header:** Gradient banner (indigo-to-violet) with logo + welcome text
  - **Body:**
    - Segmented tab control: "Sign In" | "Sign Up"
    - Form fields: Email, Password (with eye toggle), [Name for signup]
    - Forgot password link
    - Primary submit button (gradient)
    - Toggle text link to switch between sign in / sign up

#### Password Reset Screen
- Same card layout as auth
- Single email field + "Send reset link" button

### 6.2 Dashboard Home Page

#### Stat Cards (Bento Grid — 4 columns)
Each card shows a metric with ambient glow on hover:
| Card | Metric | Color |
|---|---|---|
| Total Applications | Number | Indigo `#6366f1` |
| Total Interviews | Number | Green `#10b981` |
| Total Done/Offer | Number | Amber `#f59e0b` |
| Response Rate | Percentage | Blue `#3b82f6` |

- Cards: white bg, 18px radius, subtle border
- On hover: lifts 4px + XL shadow + reveal ambient gradient overlay

#### Applications Table
- **Wrapped in section card** (bg-card, 18px radius, border)
- **Card header:** Title + filter controls + action buttons
  - Search input (text filter)
  - Status dropdown filter
  - "New Entry" button (accent outline)
  - "Export CSV" button (gradient fill)
- **Table columns:** Company | Job Title | Status (dropdown) | Date Applied | URL | Actions
- **Row behavior:**
  - Staggered fade-in animation on load
  - Hover: accent-light background
  - Status is an inline `<select>` with color classes
  - URL is a styled link button
  - Actions: View Details / Delete
- **Empty state:** Centered message if no apps

#### View Toggle (Table / Kanban)
A pill toggle button group: **Table View** | **Kanban View**

### 6.3 Kanban Board View
- Horizontal scroll container, snap scrolling
- **6 Kanban columns** (one per status): Applied | Interview | Done | Offer | Rejected | Skipped
- Each column: 300px wide, card background, rounded 16px
  - **Column header:** Status name + count badge
  - **Body:** Scrollable card list, dashed accent border on drag-over
- **Kanban Cards:**
  - Company name (bold, 13px)
  - Job title (12px, muted)
  - Footer: date + action icon (edit/delete)
  - Draggable (cursor: grab)
  - Hover: lifts 2px, accent border

### 6.4 Application Detail Modal
- Triggered on row click or "View" button
- Overlay: dark backdrop + `backdrop-filter: blur(8px)`
- Modal: 540px max-width, 22px radius, scrollable
- **Header:** Application title + company, close button
- **Tabs inside modal:**
  1. Details — fields for all application data (editable)
  2. Resume — AI resume generator UI
  3. Notes — free text notes area
- **Footer:** Cancel + Save buttons

### 6.5 New Application Modal
- Same modal template as Detail
- Fields: Company Name, Job Title, Location, Status, Date Applied, Job URL, Notes
- AI auto-fill option

### 6.6 AI Blaze Page
- **Full-page mode** (no topbar on desktop)
- Dark themed: `#09090b` background
- **Pulsing orbs**: 3 blurred gradient orbs in the background (violet, indigo, pink) that pulse in size/opacity
- **Center column** (max 680px):
  - Gradient heading: *"AI Blaze"*
  - Decorative horizontal gradient rule
  - Subtitle with current usage info
  - **Application selector**: compact select dropdown (dark glass style, min-width 260px) — lets user select a saved job to use as context
  - **Quick action pills** (horizontal flex-wrap):
    - 📝 Write Cover Letter
    - 📊 ATS Check
    - 🎯 Interview Prep
    - ✏️ Improve Resume
    - 💡 Salary Insights
    - (and more)
  - **Glass card input area**:
    - `textarea` (transparent bg, min-height 64px, auto-expand)
    - **Toolbar row** (below textarea):
      - Left: Status pill (green "READY" dot or amber pulsing "WORKING")
      - Right: Clear button + Send button (white fill when active, gradient when blazing)
  - **Response card** (rendered below input):
    - Header: orange "AI" tag + copy button
    - Body: formatted AI response text (pre-wrap)
  - **Thinking indicator** (fixed at bottom): pill with avatar + 3 bouncing dots + "Thinking..." label

### 6.7 Job Search Page
- **Search header card** (white card, 20px radius):
  - Grid input row (3 columns + button):
    1. Job title / keyword input
    2. Location input
    3. Search button (gradient, "Search Jobs")
- **Results grid** (responsive auto-fill, min 300px per card):
  - **Job cards:**
    - Company logo placeholder (initials in accent color, 44px square, 10px radius)
    - Job title (bold, 2-line clamp)
    - Company name (muted)
    - Meta badges: Location | Employment Type | Salary range (monospace font)
    - **Actions row** (border-top separator):
      - "View & Apply" button (link out)
      - "Add to Tracker" button
      - AI Match score pill (if analyzed)
  - **Skeleton loading** state: shimmer rectangles
- **AI Match feature** per card:
  - "✨ AI Match" button triggers Gemini analysis
  - Shows score pill: `"87% Match"` with indigo background

### 6.8 Settings Page
- **Two-column layout**: settings nav (220px) | content panel
- **Settings Nav** (left): vertical list of setting categories
  - Active state: accent-left bar + tinted background
  - Categories: Profile | API Keys | Preferences | Security | Keyboard Shortcuts | Privacy | Data

#### Settings Sections:

**Profile:**
- Name input, email display
- Save button

**API Keys:**
- Gemini API Key input (full-width)
- JSearch API Key input
- Info box (blue tint): describes what each key is for
- Save keys button
- Link to get API keys

**Preferences:**
- Default status on capture dropdown
- Theme preference (Light/Dark toggle)

**Keyboard Shortcuts:**
- Display-only table of shortcuts
- Uses `<kbd>` styled tag

**Security:**
- Change password flow
- Danger zone: "Delete All Data" button (red outline → fills red on hover)

**Privacy:**
- Privacy information blocks (inset card style)

### 6.9 Export Page
- Export date range selector (chip buttons: 7 Days | 30 Days | 90 Days | All Time)
- Export to CSV button
- Export summary info

### 6.10 Privacy Page
- Premium-styled content page (centered, max 900px)
- Large centered icon + title + subtitle
- 3-column card grid (glass effect) — each card describes a privacy aspect
- Bullet list section with privacy details

### 6.11 About Page
- Centered hero block:
  - Large emoji logo
  - Version badge (monospace, uppercase, accent background)
  - App name + tagline
- Feature grid cards (same 3-col glass card style)
- Tech stack list
- Links: GitHub | Privacy Policy

---

## 7. Modals & Overlays

### Generic Modal Template
- **Overlay:** `rgba(0,0,0,0.6)` + `backdrop-filter: blur(8px)`
- **Modal card:** white bg, 22px radius, max 540px, scroll-safe
- Structure: `modal-header` (title + close X) | `modal-body` | `modal-footer` (Cancel + Save)
- Entry animation: `fadeInUp 0.3s cubic-bezier`

### Toast Notifications
- Fixed: bottom-right, 24px from edges
- Default: gradient indigo-violet background
- Error: solid red background
- Animation: slides up and fades in, auto-dismisses

---

## 8. Design System Reference

### 8.1 Colors

#### Dashboard Light Mode
| Token | Value |
|---|---|
| `--bg` | `#f4f4f5` |
| `--bg-card` | `#ffffff` |
| `--bg-sidebar` | `#0c0c0f` |
| `--border` | `#e4e4e7` |
| `--text` | `#18181b` |
| `--text2` | `#3f3f46` |
| `--text-muted` | `#a1a1aa` |
| `--accent` | `#6366f1` |
| `--accent2` | `#8b5cf6` |
| `--success` | `#10b981` |
| `--warning` | `#f59e0b` |
| `--danger` | `#ef4444` |

#### Dashboard Dark Mode
| Token | Value |
|---|---|
| `--bg` | `#09090b` |
| `--bg-card` | `#18181b` |
| `--border` | `#27272a` |
| `--text` | `#fafafa` |
| `--text2` | `#a1a1aa` |

### 8.2 Typography

| Level | Font | Size | Weight | Notes |
|---|---|---|---|---|
| Display headings | Outfit | 20–40px | 600–700 | `-0.5px` letter-spacing |
| Stat values | Outfit | 36px | 700 | `-1.5px` letter-spacing |
| Body text | Outfit | 13–14px | 400–500 | |
| Labels / Caps | Outfit | 10–11px | 700 | uppercase, `+1px` letter-spacing |
| Monospace (API keys, badges) | JetBrains Mono | 10–13px | 400–600 | |

### 8.3 Spacing & Geometry
- Content padding: `28px 32px` (desktop), `16px` (mobile)
- Card border-radius: `18px` (standard), `22px` (modals)
- Sidebar width: `260px` fixed
- Topbar height: `66px` (desktop), `56px` (mobile)
- Stats grid gap: `16px`
- Section card gap: `28px`

### 8.4 Shadows
| Level | Value |
|---|---|
| `--shadow` | `0 1px 2px rgba(0,0,0,0.04), 0 1px 3px rgba(0,0,0,0.06)` |
| `--shadow-md` | `0 4px 6px -1px rgba(0,0,0,0.05)` |
| `--shadow-lg` | `0 10px 15px -3px rgba(0,0,0,0.08)` |
| `--shadow-xl` | `0 20px 25px -5px rgba(0,0,0,0.1)` |

### 8.5 Key Animations
| Name | Effect | Usage |
|---|---|---|
| `fadeInUp` | opacity 0→1 + translateY(18px→0) | Page entry, modals |
| `shimmer` | background-position left→right | Skeleton loaders, AI button |
| `pulse-glow` | box-shadow pulsing | Active states |
| `spin` | 360° rotation | Loading spinners |
| `drift-1/2/3` | Translate + scale cycle | Aurora orbs |
| `blaze-orb-pulse` | Opacity + scale | AI Blaze orbs |
| `float-ext` | TranslateY 0 → -15px → 0 | Extension mockup float |
| `blaze-dot-bounce` | Scale + opacity | Thinking dots |

---

## 9. User Flows

### 9.1 New User Flow
1. Lands on `index.html`
2. Clicks "Get Started Free →"
3. Redirected to `dashboard.html` → shows Auth screen
4. Signs up with email/password
5. Lands on Dashboard Home (empty state)

### 9.2 Capture Job from Extension
1. User browses a job board (LinkedIn, Indeed, etc.)
2. Clicks the Chrome extension icon
3. Extension popup shows: extracted Job Title, Company, Match Score
4. User clicks "Capture Application ✨"
5. Job appears at top of Applications list in dashboard

### 9.3 Application Lifecycle
1. Job saved with status = **Applied**
2. User updates to **Interview** (inline dropdown or drag-and-drop in Kanban)
3. Opens detail modal → uses AI Blaze tab for interview prep
4. Updates to **Offer** or **Rejected**

### 9.4 AI Resume Generation
1. User opens Application detail → "Resume" tab
2. Selects base resume or uploads
3. Clicks "Generate Tailored Resume"
4. AI generates DOCX-ready resume
5. Download button appears

### 9.5 AI Blaze Chat
1. User navigates to "AI Blaze" page
2. Selects application context from dropdown (optional)
3. Clicks a quick action pill (e.g., "Write Cover Letter")
4. Prompt pre-fills in textarea
5. User edits and sends
6. AI responds in glass response card
7. User copies or continues

---

## 10. Data Model (Stored per User)

### Applications Table
| Field | Type | Notes |
|---|---|---|
| `id` | UUID | Primary key |
| `user_id` | UUID | Foreign key (auth) |
| `company` | text | Company name |
| `job_title` | text | Position title |
| `status` | enum | applied, interview, done, offer, rejected, skipped |
| `date_applied` | date | |
| `job_url` | text | Original job posting URL |
| `job_description` | text | Full JD text (for AI) |
| `location` | text | |
| `notes` | text | User notes |
| `created_at` | timestamp | |

### User Settings
| Field | Notes |
|---|---|
| `gemini_api_key` | Stored securely, used for AI features |
| `jsearch_api_key` | Used for Job Search page |
| `theme` | light / dark |
| `default_status` | Status applied on new capture |

---

## 11. Non-Functional Requirements

| Requirement | Detail |
|---|---|
| **PWA** | Service worker (`sw.js`), `pwa-manifest.json`, installable |
| **Responsive** | Sidebar hidden on `<768px`, mobile drawer navigation |
| **Performance** | Staggered row animations, skeleton loaders, lazy rendering |
| **Auth** | Supabase email/password authentication, session persistence |
| **Security** | RLS on all Supabase tables, no API key exposure in frontend |
| **Offline** | Service worker caches static assets |
| **Dark Mode** | `data-theme="dark"` attribute on `<html>`, CSS variable swap |
| **Accessibility** | Semantic HTML, `aria` labels, keyboard navigable |

---

## 12. Pages / Route Summary

| Screen | File/Route | Auth Required |
|---|---|---|
| Landing Page | `index.html` | No |
| Privacy Page | `privacy.html` | No |
| Dashboard (all tabs) | `dashboard.html` | Yes |
| Auth (sign in/up) | Inside `dashboard.html` | No |
| Dashboard Home | `#dashboard` | Yes |
| Applications List | `#applications` | Yes |
| AI Blaze Chat | `#aiblaze` | Yes |
| Job Search | `#jobs` | Yes |
| Settings | `#settings` | Yes |
| Export | `#export` | Yes |
| Privacy Info | `#privacy` | Yes |
| About | `#about` | Yes |

---

*Generated from source: `index.html` (landing page) + `dashboard.html` (web app) — Job Tracker v2026*
