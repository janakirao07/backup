# Reinstall and Configure code-review-graph

The user is experiencing an error where `code-review-graph` is not found in the system PATH. This plan aims to perform a clean reinstallation and ensure the tool is accessible.

## Proposed Changes

### Environment Configuration

#### [CLEANUP] Remove old installation
- [x] Uninstall `code-review-graph` via pip (already completed).

#### [INSTALL] Reinstall code-review-graph
- Install `code-review-graph` using `pip install code-review-graph`.
- Verify the location of the installed executable.

#### [PATH] Update Session Path (Workaround)
- Since I cannot permanently change the system PATH, I will provide the user with the exact path they need to add to their environment variables.
- I will also attempt to run the tool by its full path or via `python -m code_review_graph` if supported.

## Verification Plan

### Automated Tests
- Run `code-review-graph --version` to verify accessibility.
- Run `code-review-graph build` to ensure it can still access the project.

### Manual Verification
- Confirm with the user if they can now run the command in their terminal.
