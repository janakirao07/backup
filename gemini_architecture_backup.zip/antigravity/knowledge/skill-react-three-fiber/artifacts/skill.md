---
name: react-three-fiber
description: React Three Fiber (R3F) — React renderer for Three.js. Use when building 3D scenes, models, animations, or interactive WebGL/WebGPU content in React/Next.js applications.
---

# React Three Fiber (R3F) Best Practices

## Installation
```bash
npm install three @react-three/fiber @react-three/drei @react-three/postprocessing
npm install -D @types/three
```

## Why R3F over raw Three.js
- **Declarative** — JSX instead of imperative Three.js code
- **React ecosystem** — hooks, state, context, suspense all work
- **Auto cleanup** — components auto-dispose on unmount
- **Performance** — re-renders only what changes (React reconciler)
- **pmndrs ecosystem** — Drei, Postprocessing, Rapier, Spring, XR

## Basic Scene
```tsx
import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';

export default function Scene() {
  return (
    <Canvas
      camera={{ position: [0, 2, 5], fov: 50 }}
      gl={{ antialias: true, alpha: true }}
      dpr={[1, 2]}  // Responsive pixel ratio
    >
      <color attach="background" args={['#0a0a0a']} />
      <ambientLight intensity={0.4} />
      <directionalLight position={[5, 5, 5]} intensity={1} castShadow />

      <mesh castShadow receiveShadow>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color="#6366f1" metalness={0.5} roughness={0.2} />
      </mesh>

      <OrbitControls enableDamping dampingFactor={0.05} />
    </Canvas>
  );
}
```

## Hooks (Core API)

### useFrame — Animation Loop
```tsx
import { useFrame } from '@react-three/fiber';
import { useRef } from 'react';

function SpinningBox() {
  const meshRef = useRef<THREE.Mesh>(null!);

  useFrame((state, delta) => {
    meshRef.current.rotation.y += delta * 0.5;
    // state.clock — elapsed time
    // state.camera — active camera
    // state.mouse — normalized mouse position
  });

  return (
    <mesh ref={meshRef}>
      <boxGeometry />
      <meshStandardMaterial color="hotpink" />
    </mesh>
  );
}
```

### useThree — Access Three.js Internals
```tsx
import { useThree } from '@react-three/fiber';

function CameraLogger() {
  const { camera, gl, scene, size, viewport } = useThree();
  // camera — active camera
  // gl — WebGL renderer
  // scene — root scene
  // size — canvas size in pixels
  // viewport — size in Three.js units
  return null;
}
```

### useLoader — Load Assets
```tsx
import { useLoader } from '@react-three/fiber';
import { TextureLoader } from 'three';

function TexturedBox() {
  const texture = useLoader(TextureLoader, '/texture.jpg');
  return (
    <mesh>
      <boxGeometry />
      <meshStandardMaterial map={texture} />
    </mesh>
  );
}
```

## Drei — Essential Helpers (100+ components)
```bash
npm install @react-three/drei
```

```tsx
import {
  OrbitControls,     // Camera controls
  Environment,       // HDR environment maps
  Float,             // Floating animation
  Text3D,            // 3D text
  Html,              // HTML overlay in 3D
  useGLTF,           // Load .glb/.gltf models
  useTexture,        // Load textures
  MeshDistortMaterial, // Distortion shader
  MeshWobbleMaterial,  // Wobble shader
  Stars,             // Starfield background
  Sparkles,          // Particle sparkles
  ContactShadows,    // Ground shadows
  PresentationControls, // Drag-to-rotate
  Center,            // Auto-center content
  useScroll,         // Scroll-linked animation
  ScrollControls,    // Scroll wrapper
} from '@react-three/drei';
```

### Load 3D Models
```tsx
import { useGLTF } from '@react-three/drei';

function Model({ url }: { url: string }) {
  const { scene } = useGLTF(url);
  return <primitive object={scene} scale={0.5} position={[0, -1, 0]} />;
}

// Preload for instant display
useGLTF.preload('/model.glb');
```

### Environment Lighting
```tsx
// Preset environments
<Environment preset="studio" />
<Environment preset="sunset" />
<Environment preset="city" />
<Environment preset="forest" />

// Custom HDR
<Environment files="/hdri/studio.hdr" />
```

### Scroll Animations
```tsx
import { ScrollControls, useScroll } from '@react-three/drei';
import { useFrame } from '@react-three/fiber';

function ScrollScene() {
  return (
    <Canvas>
      <ScrollControls pages={3} damping={0.25}>
        <AnimatedContent />
      </ScrollControls>
    </Canvas>
  );
}

function AnimatedContent() {
  const scroll = useScroll();
  const meshRef = useRef<THREE.Mesh>(null!);

  useFrame(() => {
    const offset = scroll.offset; // 0 to 1
    meshRef.current.rotation.y = offset * Math.PI * 2;
    meshRef.current.position.y = offset * -5;
  });

  return <mesh ref={meshRef}>...</mesh>;
}
```

## Post-Processing Effects
```bash
npm install @react-three/postprocessing
```

```tsx
import { EffectComposer, Bloom, ChromaticAberration, Vignette } from '@react-three/postprocessing';

<Canvas>
  <Scene />
  <EffectComposer>
    <Bloom luminanceThreshold={0.5} intensity={1.5} />
    <ChromaticAberration offset={[0.002, 0.002]} />
    <Vignette darkness={0.5} />
  </EffectComposer>
</Canvas>
```

## Physics (Rapier)
```bash
npm install @react-three/rapier
```

```tsx
import { Physics, RigidBody } from '@react-three/rapier';

<Canvas>
  <Physics gravity={[0, -9.81, 0]}>
    <RigidBody type="dynamic">
      <mesh><sphereGeometry /><meshStandardMaterial /></mesh>
    </RigidBody>
    <RigidBody type="fixed">
      <mesh><boxGeometry args={[10, 0.5, 10]} /><meshStandardMaterial /></mesh>
    </RigidBody>
  </Physics>
</Canvas>
```

## Next.js Integration
```tsx
// Must use dynamic import with ssr: false
import dynamic from 'next/dynamic';

const Scene = dynamic(() => import('@/components/Scene'), { ssr: false });

export default function Page() {
  return (
    <div style={{ width: '100vw', height: '100vh' }}>
      <Scene />
    </div>
  );
}
```

## Performance Rules
1. **Use `useFrame`** for animations (not `useEffect` + `requestAnimationFrame`)
2. **Instanced meshes** — `<instancedMesh>` for 100+ identical objects
3. **Memoize** — `useMemo` for geometries/materials created in components
4. **Don't re-render Canvas** — Keep Canvas parent state minimal
5. **Use `<Suspense>`** for async loading (models, textures)
6. **Dispose** — R3F auto-disposes, but manual `dispose()` for custom resources
7. **dpr={[1, 2]}** — Cap pixel ratio for mobile performance
8. **frameloop="demand"** — Only render when needed (static scenes)

```tsx
// Conditional rendering for performance
<Canvas frameloop="demand">  {/* Only re-render when state changes */}
<Canvas frameloop="always">  {/* Default: render every frame */}
```

## pmndrs Ecosystem
| Package | Purpose |
|---------|---------|
| `@react-three/fiber` | Core React renderer for Three.js |
| `@react-three/drei` | 100+ helper components |
| `@react-three/postprocessing` | Visual effects (bloom, DOF, etc.) |
| `@react-three/rapier` | Physics engine |
| `@react-spring/three` | Spring animations |
| `@react-three/xr` | VR/AR support |
| `@react-three/a11y` | Accessibility for 3D |
| `leva` | Debug GUI controls |
| `zustand` | State management (same team) |
