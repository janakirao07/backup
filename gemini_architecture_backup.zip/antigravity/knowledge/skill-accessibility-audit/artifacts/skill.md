---
name: accessibility-audit
description: WCAG 2.2 accessibility audit and compliance. Use when reviewing UI for accessibility, checking color contrast, keyboard navigation, screen readers, ARIA labels, or inclusive design.
---

# Accessibility Audit (WCAG 2.2)

## The 4 Principles (POUR)
| Principle | What it means |
|-----------|---------------|
| **Perceivable** | Users can perceive content (see, hear, feel) |
| **Operable** | Users can navigate and interact |
| **Understandable** | Users can understand content and UI |
| **Robust** | Works with assistive technologies |

## Critical Checks (Level A — Must Fix)

### 1. Images
```html
<!-- ✅ Every image needs alt text -->
<img src="logo.png" alt="Company logo" />

<!-- ✅ Decorative images: empty alt -->
<img src="divider.png" alt="" role="presentation" />

<!-- ❌ Never skip alt -->
<img src="chart.png" />
```

### 2. Keyboard Navigation
- **Tab** — Move between interactive elements
- **Enter/Space** — Activate buttons and links
- **Escape** — Close modals/popups
- **Arrow keys** — Navigate within components (menus, tabs)

```html
<!-- ✅ All interactive elements must be keyboard accessible -->
<button onclick="submit()">Submit</button>

<!-- ❌ Div with click handler — NOT keyboard accessible -->
<div onclick="submit()">Submit</div>

<!-- ✅ If you must use div, add these: -->
<div role="button" tabindex="0" onkeydown="handleKey(event)" onclick="submit()">Submit</div>
```

### 3. Color Contrast
| Text size | Minimum ratio (AA) | Enhanced ratio (AAA) |
|-----------|--------------------|--------------------|
| Normal text (<18px) | 4.5:1 | 7:1 |
| Large text (≥18px bold, ≥24px) | 3:1 | 4.5:1 |
| UI components | 3:1 | — |

```css
/* ✅ Good contrast */
color: #1a1a1a;          /* Dark text */
background: #ffffff;      /* White background */
/* Ratio: 16.75:1 ✓ */

/* ❌ Bad contrast */
color: #999999;           /* Gray text */
background: #ffffff;      /* White background */
/* Ratio: 2.85:1 ✗ */
```

### 4. Form Labels
```html
<!-- ✅ Every input needs a label -->
<label for="email">Email address</label>
<input type="email" id="email" name="email" required aria-describedby="email-help" />
<span id="email-help">We'll never share your email.</span>

<!-- ❌ Placeholder is NOT a label -->
<input type="email" placeholder="Email" />
```

### 5. Focus Indicators
```css
/* ✅ Never remove focus outlines without replacement */
:focus-visible {
  outline: 2px solid #4A90D9;
  outline-offset: 2px;
}

/* ❌ NEVER do this */
*:focus { outline: none; }
```

## ARIA Essentials
```html
<!-- Landmarks -->
<header role="banner">...</header>
<nav role="navigation" aria-label="Main">...</nav>
<main role="main">...</main>
<footer role="contentinfo">...</footer>

<!-- Live regions (screen reader announcements) -->
<div aria-live="polite" aria-atomic="true">
  Form submitted successfully!
</div>

<!-- Modal dialog -->
<div role="dialog" aria-modal="true" aria-labelledby="dialog-title">
  <h2 id="dialog-title">Confirm Delete</h2>
  ...
</div>

<!-- Loading state -->
<div aria-busy="true" aria-live="polite">Loading...</div>
```

## Heading Hierarchy
```html
<!-- ✅ Correct: sequential, one h1 per page -->
<h1>Page Title</h1>
  <h2>Section</h2>
    <h3>Subsection</h3>
  <h2>Another Section</h2>

<!-- ❌ Wrong: skipped levels -->
<h1>Title</h1>
  <h4>Jumped to h4</h4>
```

## Testing Tools
| Tool | What it catches |
|------|-----------------|
| **axe DevTools** (browser extension) | Automated WCAG violations |
| **Lighthouse** (Chrome DevTools) | Accessibility score + issues |
| **WAVE** (web tool) | Visual error indicators |
| **Tab key** | Keyboard navigation manually |
| **NVDA / VoiceOver** | Screen reader testing |
| **Color contrast checker** | Ratio calculations |

## Audit Checklist
- [ ] All images have meaningful alt text
- [ ] Color contrast meets 4.5:1 (text) and 3:1 (UI)
- [ ] All functionality works via keyboard only
- [ ] Focus order is logical (follows visual order)
- [ ] Focus indicators are visible
- [ ] Forms have associated labels
- [ ] Error messages are descriptive and linked to fields
- [ ] Page has one h1 and proper heading hierarchy
- [ ] ARIA landmarks define page regions
- [ ] Modals trap focus and return focus on close
- [ ] Dynamic content uses aria-live regions
- [ ] Page language is set: `<html lang="en">`
- [ ] No auto-playing media without controls
- [ ] Touch targets are at least 44x44px
