# CSS Grid & Flexbox Patterns

## Flexbox — When to Use
Use for **1-dimensional** layouts (row OR column).

### Common Patterns
```css
/* Center anything */
.center {
  display: flex;
  align-items: center;
  justify-content: center;
}

/* Space between items */
.navbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
}

/* Stack with gap */
.stack {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

/* Wrap items */
.tag-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

/* Sidebar layout */
.layout {
  display: flex;
  min-height: 100vh;
}
.sidebar { width: 260px; flex-shrink: 0; }
.main { flex: 1; min-width: 0; } /* min-width:0 prevents overflow */

/* Push item to end */
.card-footer {
  display: flex;
  align-items: center;
  gap: 8px;
}
.card-footer .spacer { margin-left: auto; }
```

## CSS Grid — When to Use
Use for **2-dimensional** layouts (rows AND columns).

### Common Patterns
```css
/* Responsive card grid (auto-fit) */
.card-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
  gap: 24px;
}

/* Fixed column grid */
.dashboard {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

/* Holy grail layout */
.page {
  display: grid;
  grid-template-columns: 260px 1fr 200px;
  grid-template-rows: auto 1fr auto;
  grid-template-areas:
    "header header header"
    "sidebar main aside"
    "footer footer footer";
  min-height: 100vh;
}
.header { grid-area: header; }
.sidebar { grid-area: sidebar; }
.main { grid-area: main; }
.aside { grid-area: aside; }
.footer { grid-area: footer; }

/* Span columns */
.featured { grid-column: span 2; }
.full-width { grid-column: 1 / -1; }

/* Auto-fill vs auto-fit */
/* auto-fill: creates empty tracks if space available */
/* auto-fit: collapses empty tracks (items stretch) */
grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));  /* preferred */
```

## Responsive Patterns
```css
/* Mobile-first responsive grid */
.grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 16px;
}

@media (min-width: 640px) {
  .grid { grid-template-columns: repeat(2, 1fr); }
}

@media (min-width: 1024px) {
  .grid { grid-template-columns: repeat(3, 1fr); }
}

/* Container queries (modern CSS) */
.card-container {
  container-type: inline-size;
}

@container (min-width: 400px) {
  .card { flex-direction: row; }
}
```

## Decision Guide
| Layout Need | Use |
|-------------|-----|
| Navbar items in a row | Flexbox |
| Center a single element | Flexbox |
| Card grid (responsive) | Grid (auto-fit) |
| Dashboard with areas | Grid (template-areas) |
| Sidebar + content | Flexbox OR Grid |
| Equal-height columns | Grid |
| Inline tags/badges | Flexbox (wrap) |
| Complex 2D layout | Grid |
| Vertically stacked items | Flexbox (column) |

## Modern CSS Tips
- Use `gap` (works in both Grid and Flexbox)
- Use `min-width: 0` on flex children to prevent overflow
- Use `place-items: center` as shorthand for Grid centering
- Use `aspect-ratio: 16/9` instead of padding hacks
- Use `clamp(1rem, 2.5vw, 2rem)` for fluid typography
- Use `dvh` (dynamic viewport height) instead of `vh` on mobile
