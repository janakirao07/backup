# Task: Preview Hero Banner Design

## Checklist
- [x] Navigate to https://brsshoppingmall.vercel.app/
- [x] Capture desktop screenshot (1440x900)
- [x] Capture mobile screenshot (375x812)
- [x] Verify "Split Layout" design (text not overlapping faces)

## Findings
- **Desktop:** The split layout works perfectly. Text is on the left with a solid gradient background, and the image is on the right. No overlap with model faces.
- **Mobile:** The stacking layout works as intended. Image is on top, followed by a gradient fade into a solid background block for the text and CTA. Faces are fully visible and clear.
- **Overall:** The "Nike-style" split layout provides a premium look and ensures content readability regardless of image composition.
