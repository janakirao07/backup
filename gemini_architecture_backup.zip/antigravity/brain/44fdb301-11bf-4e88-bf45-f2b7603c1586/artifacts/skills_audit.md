# Skills Installation Audit

**Source:** `skills installation.bat` • **Date:** 2026-05-05

---

## 1. Agent Skills (via `npx skills add`)

| # | Skill | Source | Status |
|---|-------|--------|--------|
| 1 | `frontend-design` | anthropics/skills | ✅ Installed |
| 2 | `vercel-react-best-practices` | vercel-labs/agent-skills | ✅ Installed |
| 3 | `web-design-guidelines` | vercel-labs/next-skills | ✅ Installed |
| 4 | `ui-ux-pro-max` | nextlevelbuilder | ✅ Installed |
| 5 | `shadcn` | shadcn/ui | ✅ Installed |
| 6 | `supabase-postgres-best-practices` | supabase/agent-skills | ✅ Installed |
| 7 | `remotion-best-practices` | remotion-dev/skills | ✅ Installed |
| 8 | `find-skills` | vercel-labs/skills | ✅ Installed |
| 9 | `microsoft-foundry` | microsoft/azure-skills | ✅ Installed |

### 3D & Animation Skills

| # | Skill | Source | Status |
|---|-------|--------|--------|
| 10 | GSAP skills (8 sub-skills) | greensock/gsap-skills | ✅ Installed |
| 11 | R3F skills (11 sub-skills) | EnzeD/r3f-skills | ✅ Installed |
| 12 | `three-js` | mindrally/skills | ✅ Installed |
| 13 | `anime-js` | mindrally/skills | ✅ Installed |

### Antigravity Mega Collection (sickn33)

| # | Skill | Status |
|---|-------|--------|
| 14 | `ui-ux-pro-max` | ✅ Installed |
| 15 | `tailwind-design-system` | ✅ Installed |
| 16 | `threejs-skills` | ✅ Installed |
| 17 | `shadcn-ui` | ❌ **NOT FOUND** — skill name doesn't exist in the 1417-skill repo |
| 18 | `react-three-fiber` | ❌ **NOT FOUND** — skill name doesn't exist in the repo |
| 19 | `threejs-webgl` | ❌ **NOT FOUND** — skill name doesn't exist in the repo |
| 20 | `orchestrating-gsap-lenis` | ❌ **NOT FOUND** — skill name doesn't exist in the repo |

> [!WARNING]
> Skills 17–20 **do not exist** in the `sickn33/antigravity-awesome-skills` repository. The batch file references skill names that aren't in the collection. These are **phantom entries** — they cannot be installed because the repo doesn't contain them.

### Plugin Marketplace Commands (Lines 34–41)

| # | Command | Status |
|---|---------|--------|
| 21 | `/plugin marketplace add freshtechbro/claudedesignskills` | ⚠️ **Not applicable** — `/plugin` is a Claude Code native command, not Antigravity |
| 22 | `/plugin install threejs-webgl` | ⚠️ Not applicable |
| 23 | `/plugin install gsap-scrolltrigger` | ⚠️ Not applicable |
| 24 | `/plugin install react-three-fiber` | ⚠️ Not applicable |
| 25 | `/plugin install barba-js` | ⚠️ Not applicable |
| 26 | `/plugin install core-3d-animation` | ⚠️ Not applicable |
| 27 | `/plugin install extended-3d-scroll` | ⚠️ Not applicable |
| 28 | `/plugin install animation-components` | ⚠️ Not applicable |

> [!NOTE]
> The `/plugin` commands are for **Claude Code CLI only**. They don't apply to Antigravity. You already have equivalent coverage from the GSAP, R3F, and Three.js skills installed above.

### UI Pro CLI

| Tool | Status |
|------|--------|
| `uipro-cli` (global npm) | ❌ **NOT installed** |

---

## 2. NPM Libraries (project dependencies)

| # | Package | Status |
|---|---------|--------|
| 1 | `three` | ❌ **Missing** |
| 2 | `@react-three/fiber` | ❌ **Missing** |
| 3 | `@react-three/drei` | ❌ **Missing** |
| 4 | `@react-three/postprocessing` | ❌ **Missing** |
| 5 | `gsap` | ❌ **Missing** |
| 6 | `lenis` | ❌ **Missing** |
| 7 | `animejs` | ❌ **Missing** |
| 8 | `@barba/core` | ❌ **Missing** |
| 9 | `tailwindcss` | ✅ Installed |
| 10 | `shadcn` (init) | ✅ Initialized |
| 11 | `razorpay` | ✅ Installed |
| 12 | `@supabase/supabase-js` | ✅ Installed |

---

## 3. Summary

| Category | Total | ✅ Installed | ❌ Missing | ⚠️ N/A |
|----------|-------|-------------|-----------|--------|
| Agent Skills | 20 | 16 | 4 (phantom names) | — |
| Plugin Commands | 8 | — | — | 8 (Claude Code only) |
| NPM Libraries | 12 | 4 | **8** | — |
| CLI Tools | 1 | 0 | **1** | — |

---

## 4. Recommended Actions

### ✅ Install Missing NPM Libraries (Required for 3D/animation features)

```bash
npm install three @react-three/fiber @react-three/drei @react-three/postprocessing gsap lenis animejs @barba/core
```

### ⚠️ Fix Phantom Skill Names in Batch File

The following 4 skills should be **removed or replaced** in the batch file — they don't exist in the `sickn33` repo:

| Phantom Name | Closest Real Match |
|---|---|
| `shadcn-ui` | Already have `shadcn` from `shadcn/ui` ✅ |
| `react-three-fiber` | Already have 11 `r3f-*` skills from `EnzeD/r3f-skills` ✅ |
| `threejs-webgl` | Already have `threejs-skills` + `three-js` ✅ |
| `orchestrating-gsap-lenis` | Already have 8 `gsap-*` skills from `greensock/gsap-skills` ✅ |

> [!TIP]
> **Good news** — you already have equivalent or better coverage from other installed sources. No actual capability gap exists. Only the NPM libraries need to be installed.

### 🟡 Optional: Install uipro-cli

```bash
npm install -g uipro-cli
```
This is optional — you already have `ui-ux-pro-max` skill installed which covers the same design system rules.
