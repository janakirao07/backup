# Firebase

## Firestore
```ts
import { doc, setDoc, getDoc } from 'firebase/firestore';
await setDoc(doc(db, 'users', 'userId'), { name: 'Alice' });
const snap = await getDoc(doc(db, 'users', 'userId'));
```

## Security Rules
```javascript
match /users/{userId} {
  allow read, write: if request.auth != null && request.auth.uid == userId;
}
```