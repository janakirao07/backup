# 🎯 BSR Banner Design — Problem & Solution Plan

## The Problem

Your banner images have **people/models as the main subject**, but the text overlay sits right on top of their faces. This happens because:

1. The text is **centered on mobile** — directly over the model's face
2. The dark overlay is too transparent in the middle — text loses contrast over skin tones
3. There's **no designated "safe zone"** — text just floats wherever

---

## How Top Brands Solve This

### 🏆 Pattern 1: Nike — "Split Layout" (RECOMMENDED)
> Image on one side, text on the other. They NEVER put text on faces.

- **Desktop**: Image fills right 60%, text block on left 40% with solid/gradient background
- **Mobile**: Image on top (60% height), text below in a clean colored block
- **Why it works**: Text and image never compete. Clean, bold, readable.

### 🏆 Pattern 2: Zara — "Bottom Bar" 
> Full-bleed image, tiny text pinned to the very bottom edge

- Ultra-minimal text (just brand name + "SHOP NOW")
- Text lives in the bottom 10% only, with a heavy bottom gradient
- **Why it works**: Image gets 90% of the space. No face overlap.

### 🏆 Pattern 3: H&M — "Text Card Overlay"
> Text sits inside a frosted glass card positioned in a safe corner

- Semi-transparent card (glassmorphism) placed bottom-left
- Image is fully visible behind it
- **Why it works**: Card creates its own readable background

### 🏆 Pattern 4: Myntra/Ajio — "Baked-in Text"
> Text is part of the image itself (designed in Canva/Photoshop)

- Designer places text in the image file, avoiding the model
- No CSS text overlay at all
- **Why it works**: Perfect control. Zero overlap. Most Indian e-commerce uses this.

---

## 🎯 Recommended Solution for BSR

### **Option A: Split Layout (Nike-style)** ⭐ BEST FIT

```
┌─────────────────────────────────────────┐
│  DESKTOP                                │
│  ┌──────────────┬──────────────────────┐ │
│  │  SUMMER      │                      │ │
│  │  COLLECTION  │   [MODEL IMAGE]      │ │
│  │  2026        │   Full height,       │ │
│  │              │   no text overlay    │ │
│  │  Up to 50%   │                      │ │
│  │  [SHOP NOW]  │                      │ │
│  └──────────────┴──────────────────────┘ │
│                                          │
│  MOBILE                                  │
│  ┌──────────────────────┐                │
│  │                      │                │
│  │   [MODEL IMAGE]      │ ← 55% height  │
│  │   Clean, no text     │                │
│  │                      │                │
│  ├──────────────────────┤                │
│  │  SUMMER COLLECTION   │                │
│  │  Up to 50% Off       │ ← 45% height  │
│  │  [SHOP NOW]          │   Solid bg     │
│  └──────────────────────┘                │
└─────────────────────────────────────────┘
```

**Pros**: Clean separation. Works with ANY image. No face overlap ever.
**Cons**: Needs gradient background colors per slide (already have these).

### **Option B: Bottom-Pinned Card (H&M-style)**

```
┌──────────────────────────┐
│                          │
│    [FULL IMAGE]          │
│    Model visible         │
│                          │
│  ┌────────────────────┐  │
│  │ ░░ GLASSMORPHISM ░░│  │
│  │ Summer Collection  │  │
│  │ Up to 50% Off      │  │
│  │ [SHOP NOW]         │  │
│  └────────────────────┘  │
└──────────────────────────┘
```

**Pros**: Full image visibility. Modern glass effect.
**Cons**: Still slightly obscures bottom of image.

### **Option C: Baked-In Banners (Myntra-style)**

Upload pre-designed banner images (from Canva) where text is already part of the image. Remove all CSS text overlays.

**Pros**: Perfect control. Designer places text exactly where it fits.
**Cons**: Harder to update. Need design skills. Two images per banner.

---

## 💡 My Recommendation

**Go with Option A (Split Layout)** because:

1. ✅ Works with ANY image — no matter where the model stands
2. ✅ You already have gradient colors per slide
3. ✅ Text is always 100% readable (solid background)
4. ✅ Looks premium and modern (Nike, Apple, Uniqlo all use this)
5. ✅ Mobile-friendly — stacked layout with image on top
6. ✅ No need to redesign images or use Canva

### What Changes in the Code

| Aspect | Current | New (Split Layout) |
|---|---|---|
| **Desktop** | Text floats over image with dark overlay | Text on left 40% with gradient bg, image on right 60% |
| **Mobile** | Text centered over image | Image top 55%, text block bottom 45% with gradient bg |
| **Overlay** | Heavy black gradient over entire image | No overlay on image side, clean gradient on text side |
| **Readability** | Poor over light images/faces | Perfect — text has solid colored background |
| **Image** | Partially hidden by text | Fully visible, clean, no obstruction |

---

## Next Step

Say **"do it"** and I'll implement Option A (Split Layout) right now.

Or pick **B** (glass card) or **C** (baked-in) if you prefer a different approach.
