# Walkthrough: Cloud-Synced Profile & Custom Sections

Your personal resume details are now permanently stored in the cloud! This ensures your profile is always available, whether you are using the web dashboard or the Chrome extension.

## What's New

### 1. Cloud-Synced Personal Profile
- **Supabase Integration**: Your name, email, phone, and other details are now saved to your database instead of just your local browser.
- **Cross-Device Access**: Save your profile on your laptop and see it instantly on your desktop or in the sidebar.
- **Improved Reliability**: Even if you clear your browser history, your resume profile remains safe in the cloud.

### 2. Dynamic Custom Sections
- **"Add Section" Button**: You can now add an unlimited number of extra sections to your profile (e.g., **Projects**, **Awards**, **Languages**, or **Volunteering**).
- **Flexible Content**: Each custom section supports plain text and bullet points (start lines with `-`, `•`, or `*`).
- **Professional Rendering**: These sections are automatically added to your generated DOCX resumes with matching professional formatting.

## How to Use

1.  **Open Settings**: Go to the **Resume Profile** tab in either the Dashboard or the Extension sidebar.
2.  **Add Sections**: Scroll down and click **"+ Add Custom Section"**.
3.  **Fill Details**: Give your section a title (e.g., "Projects") and add your content.
4.  **Save**: Click **"Save Personal Profile"**.
5.  **Generate**: Download your resume! All your new sections will be included at the end of the document.

> [!NOTE]
> When you first open the settings, I've added a loading spinner to fetch your latest details from the database.

---

### [task.md](file:///C:/Users/janak/.gemini/antigravity/brain/9c9899a0-87e5-47a2-a615-aa004eecf5d6/task.md) Update
- [x] Implement DB sync functions in `app.js`
- [x] Update Profile Settings UI in `app.js` (Add/Remove Custom Sections)
- [x] Update Profile Settings UI in `content.js` (Sync with DB + Custom Sections)
- [x] Update `resume-engine.js` to render custom sections in the DOCX
- [x] Verify migration and syncing between Dashboard and Extension
