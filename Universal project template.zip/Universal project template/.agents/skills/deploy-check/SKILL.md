---
name: deploy-check
description: Pre-deployment validation — build check, env vars, security scan, and Vercel readiness
---

<objective>
Run a comprehensive pre-deployment checklist before pushing to production.
Catches build errors, missing env vars, security issues, and performance
problems BEFORE they hit production.
</objective>

<process>
## Pre-Deployment Validation Workflow

### Step 1: Build Check
1. Run `npm run build` (or `next build`) and capture output
2. Report any TypeScript errors, warnings, or build failures
3. Check for any `console.log` statements left in production code

### Step 2: Environment Variables
1. Compare `.env.local` / `.env` keys against what the code actually uses
2. Flag any missing env vars that would cause runtime errors
3. Verify no secrets are hardcoded in source files
4. Check `.gitignore` includes `.env*` files

### Step 3: Security Quick Scan
1. Search for hardcoded API keys, passwords, or tokens in source
2. Verify Supabase RLS policies are enabled on all tables
3. Check for exposed service role keys in client-side code
4. Verify CORS and auth middleware on API routes

### Step 4: Performance Check
1. Check for missing `next/image` usage (raw `<img>` tags)
2. Verify lazy loading on heavy components
3. Check bundle size for unusually large imports
4. Verify metadata/SEO tags on all pages

### Step 5: Report
Generate a deployment readiness report:
- ✅ PASS / ❌ FAIL for each category
- List of blocking issues (must fix)
- List of warnings (should fix)
- Final GO / NO-GO recommendation
</process>
