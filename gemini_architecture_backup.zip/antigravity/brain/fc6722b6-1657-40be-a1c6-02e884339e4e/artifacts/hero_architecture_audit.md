# BSR Shopping Mall — Responsive Hero Architecture Audit

## 1. Current Hero Architecture Problems
*   **Arbitrary Sizing:** The current container sizing `h-[85vh] md:h-[600px] lg:h-[700px]` is inverted. Mobile screens (which are narrow and tall) are being forced to 85% of viewport height, aggressively cropping landscape desktop images. Meanwhile, wide desktop screens are artificially capped at 600px-700px, which breaks the immersive full-bleed luxury feel.
*   **Image Forcing & Cropping:** When a specific `mobile_image_url` isn't provided by the CMS, the desktop landscape image is forced into an extreme portrait crop. Because `object-position: center` is hardcoded, models are often cropped in half or have their heads cut off on mobile devices.
*   **Responsive Breakdowns:** The current CSS merely relies on `object-cover` without considering focal points.

## 2. Rendering, Layout, and CLS Risks
*   **Hydration Mismatch / CLS:** While `Next/Image` provides `fill`, the wrapper height relies on viewport units `vh`. On mobile Safari, the address bar expanding/collapsing causes `vh` to jump, causing layout shifts (CLS) and image resizing during scrolling.
*   **Text Crowding:** The absolute positioned text overlay forces `pb-20` on mobile. On smaller screens like the iPhone SE (320px wide), the massive `text-3xl sm:text-4xl` titles collide with the bottom edge or overlap faces.

## 3. Why the Implementation Breaks on Mobile
Mobile is a portrait medium. A cinematic desktop shot (16:9 ratio) placed in a 9:16 mobile container needs a different focal point strategy. The current implementation treats mobile as a shrunk-down desktop, leading to broken UX.

## 4. Remediation Plan
1.  **Architecture:** Adopt a dual-image strategy using responsive breakpoints. We will use `dvh` (dynamic viewport height) and explicit `vh` defaults to solve Safari's address bar CLS.
2.  **Sizing Rules:**
    *   Desktop: `md:h-[85vh]` up to `md:min-h-[700px]` (Cinematic).
    *   Mobile: `h-[65svh]` (Portrait optimized, doesn't jump).
3.  **Focal Point Protection:** If `mobile_image_url` is missing, the fallback desktop image on mobile will use `object-[center_top]` to guarantee the model's head/torso remains visible instead of cropping to the dead center of their chest.
4.  **Typography Responsiveness:** Shrink the mobile font size slightly and adjust the text container to ensure it stays in the bottom third of the screen without covering the subject.
