# PWA Patterns

## Manifest
```json
{ "name": "App", "short_name": "App", "start_url": "/", "display": "standalone", "icons": [{ "src": "/icon.png", "sizes": "512x512", "type": "image/png" }] }
```

## Service Worker
```js
self.addEventListener('fetch', (event) => {
  event.respondWith(caches.match(event.request).then(r => r || fetch(event.request)));
});
```