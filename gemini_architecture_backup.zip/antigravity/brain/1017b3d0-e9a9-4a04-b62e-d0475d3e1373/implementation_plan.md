# Fix Job Extraction Logic

The user reported that the job extraction feature is only filling the page URL and JD (Job Description), while the Company Name and Job Title remain blank. This indicates that the AI extraction via Gemini is failing to return the expected data.

## User Review Required

> [!IMPORTANT]
> The primary cause appears to be an invalid Gemini model name (`gemini-2.5-flash`) used in the code. I will update this to `gemini-1.5-flash`, which is stable and widely available.

## Proposed Changes

### Content Script Logic

#### [MODIFY] [content.js](file:///c:/Users/janak/job-tracker-app/scripts/content.js)
- Update the Gemini model name from `gemini-2.5-flash` to `gemini-1.5-flash` in the API endpoint URL.
- Update the version info in the "About" section to reflect the correct model.
- (Optional) Improve the prompt to be more explicit about returning the JSON structure even if information is missing.

### Dashboard / App Logic

#### [MODIFY] [app.js](file:///c:/Users/janak/job-tracker-app/scripts/app.js)
- Update the version info in the "About" section to reflect the correct model (`Gemini 1.5 Flash`).

## Open Questions

- None at the moment.

## Verification Plan

### Manual Verification
- Test the "Extract & Save" feature on a job posting page (e.g., LinkedIn or a local test file).
- Verify that "Company Name" and "Job Title" are now correctly populated alongside the URL and JD.
- Check the "Settings > About" section to ensure the model name is correctly displayed.
