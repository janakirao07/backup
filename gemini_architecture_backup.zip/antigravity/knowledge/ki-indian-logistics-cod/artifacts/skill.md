# Indian Logistics & COD Handling

Best practices for Shiprocket/Delhivery integration, COD fraud prevention, and return management.

## 🚚 Shiprocket Integration Patterns

### Auth & Token Caching
```javascript
class ShiprocketClient {
  constructor() { this.token = null; this.tokenExpiry = null; }

  async getToken() {
    if (this.token && Date.now() < this.tokenExpiry) return this.token;

    const res = await fetch('https://apiv2.shiprocket.in/v1/external/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: process.env.SHIPROCKET_EMAIL,
        password: process.env.SHIPROCKET_PASSWORD
      })
    });
    const data = await res.json();
    this.token = data.token;
    this.tokenExpiry = Date.now() + 23 * 60 * 60 * 1000; // 23hr buffer
    return this.token;
  }
}
```

### Order Creation
- Always pickup from a consistent location (e.g., `BSR-Warehouse-Primary`).
- Map items with **HSN codes** (mandatory for GST).
- Use `Prepaid` or `COD` as the payment method.

## 📦 Delhivery Direct Integration

- Use direct integration for volumes > 500 shipments/month.
- **Waybill creation**: Leave waybill blank in the API call; Delhivery assigns it automatically.
- **Serviceability**: Check `/courier/serviceability` before finalizing courier selection.

## 🛡️ COD Fraud Patterns & Prevention

COD RTO (Return to Origin) rates can be 30–40%. Fighting it is mandatory:

### Risk Scoring Engine
```javascript
function computeCODRiskScore(order) {
  let score = 0;
  if (order.paymentMethod === 'COD') score += 10;
  if (order.isFirstOrder) score += 15;
  if (order.total > 3000) score += 10;
  if (order.address.includes('near') || order.address.length < 25) score += 20;
  if (!order.customer.emailVerified) score += 10;
  if (order.sessionDuration < 30) score += 15;

  if (order.customer.previousOrders > 2) score -= 20;
  return score;
}
```
- **Block COD** if score >= 50.
- **OTP Verification**: Mandatory for COD above ₹1,500.

## 🔄 Returns Management

- **Window**: 7 days for garments.
- **QC Pass**: Refund triggered ONLY after warehouse QC pass.
- **COD Refunds**: Collect bank account details (IFSC, Account #) at return-request time.
- **WhatsApp**: Use for 70% of communication (pickup scheduled, item received, refund initiated).
