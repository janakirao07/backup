# ActionSense — Phase 0 + Phase 1 Foundation Implementation Plan

## Overview

This plan bootstraps the **ActionSense** human action recognition platform from zero. Given the PRD's scope (10+ months, multi-team), this plan focuses on delivering a **working, demo-able Phase 0 + Phase 1 skeleton** — the core project structure, data pipeline, model training loop, evaluation dashboard, and REST API — in a single sprint.

> [!IMPORTANT]
> This plan delivers the **foundational architecture and working MVP**. Advanced features (monitoring dashboard, alert system, multi-camera, edge deployment) are deferred to later phases per the PRD.

---

## Environment Summary

| Tool | Version | Status |
|------|---------|--------|
| Python | 3.13 | ✅ Installed |
| PyTorch | 2.11 | ✅ Installed |
| FastAPI | 0.124 | ✅ Installed |
| Node.js | 22.18 | ✅ Installed |
| npm | 10.9 | ✅ Installed |
| OpenCV | — | 🔧 To install |
| MediaPipe | — | 🔧 To install |
| MLflow | — | 🔧 To install |

---

## User Review Required

> [!WARNING]
> **Project Location**: The project will be created at `C:\Users\janak\.gemini\antigravity\scratch\actionsense\`. This keeps it in your workspace. Do you prefer a different location?

> [!IMPORTANT]
> **Dataset Strategy**: For Phase 1, we'll use **UCF-101** (smallest benchmark, 13K clips, ~6.5GB). Do you want me to include automated download scripts, or will you provide the data manually?

> [!IMPORTANT]
> **GPU Availability**: The PRD targets NVIDIA T4/A100. Do you have a CUDA-capable GPU on this machine, or should we design for CPU-first development with GPU deployment later?

---

## Proposed Architecture

```
actionsense/
├── README.md
├── pyproject.toml                    # Python project config (PEP 621)
├── requirements.txt                  # Pinned dependencies
├── .env.example                      # Environment variable template
├── docker-compose.yml                # Local dev orchestration
├── Dockerfile                        # API server container
│
├── config/
│   ├── __init__.py
│   ├── settings.py                   # Pydantic Settings (env-based config)
│   └── constants.py                  # Action classes, model configs
│
├── actionsense/                      # Core Python package
│   ├── __init__.py
│   │
│   ├── data/                         # F-01, F-02: Data Ingestion & Preprocessing
│   │   ├── __init__.py
│   │   ├── ingestion.py              # Video upload, RTSP stream, batch import
│   │   ├── preprocessing.py          # Frame extraction, resize, normalize, augment
│   │   ├── dataset.py                # PyTorch Dataset classes (UCF-101, HMDB-51)
│   │   ├── transforms.py            # Video-specific augmentation transforms
│   │   └── download.py              # Benchmark dataset download scripts
│   │
│   ├── features/                     # F-03: Feature Extraction
│   │   ├── __init__.py
│   │   ├── optical_flow.py           # Farnebäck / RAFT optical flow
│   │   ├── pose_estimation.py        # MediaPipe pose keypoints
│   │   └── descriptors.py           # Spatial-temporal descriptors
│   │
│   ├── models/                       # F-04, F-05: Model Training & Transfer Learning
│   │   ├── __init__.py
│   │   ├── cnn_lstm.py               # CNN + LSTM architecture
│   │   ├── resnet3d.py               # 3D-CNN (R3D / SlowFast)
│   │   ├── transformer.py           # Video Transformer (TimeSformer/ViViT)
│   │   ├── backbones.py             # Pre-trained backbone loader
│   │   └── registry.py              # Model factory pattern
│   │
│   ├── training/                     # Training orchestration
│   │   ├── __init__.py
│   │   ├── trainer.py                # Main training loop (PyTorch)
│   │   ├── evaluator.py             # Metrics computation
│   │   ├── callbacks.py             # Checkpointing, early stopping
│   │   └── optimizer.py             # LR schedulers, optimizer configs
│   │
│   ├── inference/                    # F-08: Real-Time Inference Engine
│   │   ├── __init__.py
│   │   ├── engine.py                 # Inference pipeline (load → preprocess → predict)
│   │   ├── batch.py                  # Batch inference handler
│   │   └── stream.py                # RTSP stream inference handler
│   │
│   ├── api/                          # F-09: RESTful API
│   │   ├── __init__.py
│   │   ├── main.py                   # FastAPI app entry point
│   │   ├── routes/
│   │   │   ├── __init__.py
│   │   │   ├── predict.py            # POST /api/v1/predict
│   │   │   ├── stream.py            # POST /api/v1/stream/start, DELETE /stream/{id}
│   │   │   ├── models.py            # GET /api/v1/models, POST /train
│   │   │   ├── datasets.py          # POST /api/v1/datasets/upload
│   │   │   └── health.py            # GET /api/v1/health
│   │   ├── schemas.py               # Pydantic request/response models
│   │   ├── auth.py                   # JWT authentication middleware
│   │   └── middleware.py            # CORS, rate limiting, error handling
│   │
│   └── utils/                        # Shared utilities
│       ├── __init__.py
│       ├── video.py                  # Video I/O helpers (OpenCV/FFmpeg)
│       ├── logging.py               # Structured logging config
│       ├── metrics.py               # Accuracy, F1, confusion matrix
│       └── device.py                # GPU/CPU device management
│
├── dashboard/                        # F-06: Model Evaluation Dashboard (Web)
│   ├── index.html                    # Single-page dashboard
│   ├── css/
│   │   └── dashboard.css            # Premium dark-mode UI
│   └── js/
│       ├── app.js                    # Main dashboard logic
│       ├── charts.js                # Chart.js visualizations
│       └── api.js                   # API client
│
├── scripts/                          # CLI utilities
│   ├── train.py                      # python scripts/train.py --config ...
│   ├── evaluate.py                   # python scripts/evaluate.py --model ...
│   ├── infer.py                      # python scripts/infer.py --video ...
│   └── download_datasets.py         # python scripts/download_datasets.py --dataset ucf101
│
├── tests/                            # Test suite
│   ├── __init__.py
│   ├── conftest.py                   # Shared fixtures
│   ├── test_data/
│   │   ├── test_preprocessing.py
│   │   └── test_dataset.py
│   ├── test_models/
│   │   ├── test_cnn_lstm.py
│   │   └── test_registry.py
│   ├── test_api/
│   │   ├── test_predict.py
│   │   └── test_health.py
│   └── test_training/
│       └── test_trainer.py
│
└── docs/                             # Documentation
    ├── api.md                        # API reference
    ├── architecture.md              # Architecture overview
    └── getting_started.md           # Quickstart guide
```

---

## Proposed Changes

### Component 1: Project Foundation

#### [NEW] `pyproject.toml`
- PEP 621 project metadata, dependencies, tool configs (pytest, ruff, mypy)
- Defines `actionsense` as installable package

#### [NEW] `requirements.txt`
- Pinned versions: `torch`, `torchvision`, `opencv-python`, `fastapi`, `uvicorn`, `pydantic`, `python-jose[cryptography]`, `mediapipe`, `mlflow`, `optuna`, `pillow`, `scikit-learn`, `matplotlib`, `tqdm`

#### [NEW] `config/settings.py`
- Pydantic Settings class loading from `.env`
- Configs for: model paths, dataset paths, API port, JWT secret, device selection, training hyperparams

#### [NEW] `.env.example`
- Template with all required environment variables

---

### Component 2: Data Pipeline (F-01, F-02)

#### [NEW] `actionsense/data/dataset.py`
- `UCF101Dataset(torch.utils.data.Dataset)` — loads video clips, applies transforms, returns tensor batches
- `HMDB51Dataset` — similar loader for HMDB-51
- Configurable frame sampling: uniform, random, center-crop

#### [NEW] `actionsense/data/preprocessing.py`
- Frame extraction from video files (OpenCV)
- Resize, center crop, normalize (ImageNet stats)
- Temporal sampling strategies (uniform, stride, random)

#### [NEW] `actionsense/data/transforms.py`
- `RandomCrop`, `RandomHorizontalFlip`, `ColorJitter`, `TemporalJitter`
- Compose pipeline compatible with video tensor format `(T, C, H, W)`

#### [NEW] `actionsense/data/ingestion.py`
- `ingest_video(path)` — validate format, extract metadata (fps, duration, resolution)
- `ingest_rtsp(url)` — connect to RTSP stream, yield frames
- `ingest_batch(directory)` — batch import with metadata JSON

#### [NEW] `actionsense/data/download.py`
- `download_ucf101()` — automated download + extraction
- `download_hmdb51()` — automated download + extraction
- Integrity verification (MD5 checksums)

---

### Component 3: Feature Extraction (F-03)

#### [NEW] `actionsense/features/optical_flow.py`
- Farnebäck dense optical flow (OpenCV fallback)
- Flow visualization utilities

#### [NEW] `actionsense/features/pose_estimation.py`
- MediaPipe Pose wrapper for human keypoint extraction
- Returns normalized keypoint coordinates per frame

#### [NEW] `actionsense/features/descriptors.py`
- Spatial-temporal descriptor computation
- Histogram of Oriented Gradients (HOG) on flow fields

---

### Component 4: Model Architectures (F-04, F-05)

#### [NEW] `actionsense/models/cnn_lstm.py`
- `CNNLSTMModel(nn.Module)`:
  - CNN backbone (ResNet-18/34/50 from torchvision, pretrained)
  - Feature pooling → LSTM sequence model
  - Classification head with dropout
  - Configurable: backbone, hidden_size, num_layers, num_classes, dropout

#### [NEW] `actionsense/models/resnet3d.py`
- `ResNet3D(nn.Module)`:
  - 3D convolutional ResNet (R3D-18 from torchvision)
  - Pretrained on Kinetics-400
  - Fine-tuning support (freeze backbone layers)

#### [NEW] `actionsense/models/transformer.py`
- `VideoTransformer(nn.Module)`:
  - Patch embedding for video frames
  - Temporal attention + spatial attention
  - Classification token + MLP head
  - Based on TimeSformer architecture

#### [NEW] `actionsense/models/backbones.py`
- Load pretrained backbones: ResNet, EfficientNet, ViT
- Freeze/unfreeze helpers for transfer learning

#### [NEW] `actionsense/models/registry.py`
- Factory pattern: `get_model(name, config) → nn.Module`
- Registry of all available architectures

---

### Component 5: Training Pipeline

#### [NEW] `actionsense/training/trainer.py`
- `ActionTrainer` class:
  - Train/val loop with mixed precision (AMP)
  - Checkpoint save/resume
  - MLflow experiment logging
  - Progress bars (tqdm)
  - Early stopping support

#### [NEW] `actionsense/training/evaluator.py`
- `evaluate_model()`:
  - Top-1 / Top-5 accuracy
  - Per-class precision, recall, F1
  - Confusion matrix generation
  - ROC curves for key classes

#### [NEW] `actionsense/training/callbacks.py`
- `ModelCheckpoint` — save best/last weights
- `EarlyStopping` — patience-based
- `LRSchedulerCallback` — step/cosine/plateau

#### [NEW] `actionsense/training/optimizer.py`
- Optimizer factory: SGD, Adam, AdamW, LARS
- LR scheduler factory: StepLR, CosineAnnealing, OneCycleLR

---

### Component 6: Inference Engine (F-08)

#### [NEW] `actionsense/inference/engine.py`
- `InferenceEngine`:
  - Load model from checkpoint or ONNX
  - Preprocess video/frames → tensor
  - Predict with confidence scores
  - Support batch and single-clip modes
  - Device-aware (auto GPU/CPU)

#### [NEW] `actionsense/inference/stream.py`
- `StreamInference`:
  - RTSP stream connection
  - Sliding window clip extraction
  - Real-time action labeling loop
  - Thread-safe result queue

---

### Component 7: REST API (F-09)

#### [NEW] `actionsense/api/main.py`
- FastAPI app with versioned routing (`/api/v1/`)
- CORS, exception handlers, startup/shutdown events
- OpenAPI docs with custom branding

#### [NEW] `actionsense/api/routes/predict.py`
- `POST /api/v1/predict` — accept video URL or base64 frames
- Returns: `{ action, confidence, top_k, processing_time_ms }`

#### [NEW] `actionsense/api/routes/stream.py`
- `POST /api/v1/stream/start` — start RTSP inference session
- `DELETE /api/v1/stream/{id}` — stop session

#### [NEW] `actionsense/api/routes/models.py`
- `GET /api/v1/models` — list trained models
- `POST /api/v1/models/train` — trigger training job (async)
- `GET /api/v1/models/{id}/metrics` — retrieve metrics

#### [NEW] `actionsense/api/routes/health.py`
- `GET /api/v1/health` — system health with GPU/memory info

#### [NEW] `actionsense/api/schemas.py`
- All Pydantic models for request/response validation

#### [NEW] `actionsense/api/auth.py`
- JWT Bearer token authentication
- Token generation and validation
- RBAC: admin, operator, viewer

---

### Component 8: Evaluation Dashboard (F-06)

#### [NEW] `dashboard/index.html`
- Premium dark-mode single-page dashboard
- Sections: Model Performance, Per-Class Analysis, Training History, Live Inference Demo

#### [NEW] `dashboard/css/dashboard.css`
- Glassmorphism + dark-mode design system
- Responsive grid layout
- Micro-animations on cards and charts
- Custom scrollbars, premium typography (Inter font)

#### [NEW] `dashboard/js/app.js`
- Dashboard initialization, tab navigation
- Model selector, metric display logic
- Real-time inference demo (webcam or video upload)

#### [NEW] `dashboard/js/charts.js`
- Chart.js integration:
  - Confusion matrix heatmap
  - Per-class accuracy bar chart
  - Training loss/accuracy curves
  - ROC curve visualization
  - Confidence distribution histogram

#### [NEW] `dashboard/js/api.js`
- API client with JWT auth
- Endpoints for model metrics, predictions, health

---

### Component 9: CLI Scripts

#### [NEW] `scripts/train.py`
- CLI entry point: `python scripts/train.py --model cnn_lstm --dataset ucf101 --epochs 50`
- Argparse configuration for all training parameters
- MLflow run logging

#### [NEW] `scripts/evaluate.py`
- CLI: `python scripts/evaluate.py --checkpoint best_model.pth --dataset ucf101`
- Exports metrics JSON + confusion matrix image

#### [NEW] `scripts/infer.py`
- CLI: `python scripts/infer.py --video sample.mp4 --model best_model.pth`
- Outputs per-frame action predictions

---

### Component 10: Docker & DevOps

#### [NEW] `Dockerfile`
- Multi-stage build: deps → app
- CUDA base image for GPU support
- Exposes FastAPI on port 8000

#### [NEW] `docker-compose.yml`
- Services: `api`, `redis`, `postgres`, `mlflow`
- Volume mounts for models, data, logs

---

## Delivery Phases (This Sprint)

| Step | Work | Files |
|------|------|-------|
| 1 | Project scaffold + config | `pyproject.toml`, `requirements.txt`, `config/`, `.env.example` |
| 2 | Data pipeline | `actionsense/data/*`, `actionsense/utils/*` |
| 3 | Feature extraction | `actionsense/features/*` |
| 4 | Model architectures | `actionsense/models/*` |
| 5 | Training pipeline | `actionsense/training/*` |
| 6 | Inference engine | `actionsense/inference/*` |
| 7 | REST API | `actionsense/api/*` |
| 8 | Evaluation Dashboard | `dashboard/*` |
| 9 | CLI scripts | `scripts/*` |
| 10 | Docker + docs | `Dockerfile`, `docker-compose.yml`, `docs/*` |
| 11 | Unit tests | `tests/*` |

---

## Open Questions

> [!IMPORTANT]
> 1. **Project location** — `C:\Users\janak\.gemini\antigravity\scratch\actionsense\` or somewhere else?
> 2. **GPU availability** — Do you have a CUDA GPU on this machine? This affects model default configs.
> 3. **Dataset auto-download** — Should I include scripts to auto-download UCF-101 (~6.5GB) or assume manual provision?
> 4. **Dashboard standalone** — The PRD asks "standalone React SPA or embedded?" — I'm proposing a **vanilla HTML/CSS/JS SPA** (no React) for simplicity and instant startup. OK?
> 5. **Skeleton-based recognition** — Should ST-GCN be included now (Phase 1) or deferred?

---

## Verification Plan

### Automated Tests
- Unit tests for data transforms, model forward passes, API endpoints
- `pytest tests/ -v --cov=actionsense --cov-report=term-missing`
- FastAPI test client for API endpoint validation

### Manual Verification
- Start API server: `uvicorn actionsense.api.main:app --reload`
- Open dashboard at `http://localhost:8000/dashboard`
- POST a sample video to `/api/v1/predict` and verify response format
- Run training script with dummy data to verify end-to-end pipeline
