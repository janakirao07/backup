# UX, Performance, and Accessibility Audit Report

This report outlines critical and medium-level issues identified across the Primetek Global Solutions web portal concerning mobile responsiveness, web performance, and accessibility. 

---

## 1. Mobile Responsiveness

### Issue 1.1: Inadequate Touch Target Sizes on Interactive Elements
**Severity: Medium**

Mobile interfaces require a minimum touch target size of 44x44px to prevent accidental taps. Several components, including the primary `<Button />` (in its `sm` variant) and the mobile navigation toggle, do not meet this threshold, resulting in heights of around ~36px to 40px.

**Broken Code (`src/components/ui/Button.tsx`):**
```tsx
// Small size lacks min-height
{
  'px-4 py-2 text-sm': size === 'sm',
}
```

**Fixed Code:**
```tsx
// Introduce a minimum height to satisfy WCAG 2.5.5 Target Size
{
  'px-4 py-2.5 text-sm min-h-[44px]': size === 'sm',
}
```

**Broken Code (`src/components/layout/Navbar.tsx`):**
```tsx
<button
  onClick={() => setIsOpen(!isOpen)}
  className={cn(
    'md:hidden p-2 rounded-lg transition-colors', // Yields a 40x40 square
    isScrolled ? 'text-navy-900 hover:bg-gray-100' : 'text-white hover:bg-white/10'
  )}
  aria-label="Toggle navigation menu"
>
```

**Fixed Code:**
```tsx
<button
  onClick={() => setIsOpen(!isOpen)}
  className={cn(
    'md:hidden p-2.5 min-w-[44px] min-h-[44px] flex items-center justify-center rounded-lg transition-colors',
    isScrolled ? 'text-navy-900 hover:bg-gray-100' : 'text-white hover:bg-white/10'
  )}
  aria-label="Toggle navigation menu"
>
```

### Issue 1.2: Horizontal Overflow Risks on Small Screens
**Severity: Medium**

While the container utilities generally constrain width, standard mobile best practices dictate explicitly hiding the X-axis overflow at the root level to prevent "wobbly" scrolling if a child element accidentally breaks out of the grid.

**Broken Code (`src/app/layout.tsx`):**
```tsx
<html lang="en" className="h-full antialiased">
  <body className="min-h-full flex flex-col">{children}</body>
</html>
```

**Fixed Code:**
```tsx
<html lang="en" className="h-full antialiased overflow-x-hidden">
  <body className="min-h-full flex flex-col overflow-x-hidden w-full">{children}</body>
</html>
```

---

## 2. Performance

### Issue 2.1: Render-Blocking Google Fonts Strategy
**Severity: Critical**

The global layout utilizes standard `<link>` tags pointing to Google Fonts. This blocks page rendering, leading to noticeable Layout Shifts (CLS) and worsening the Largest Contentful Paint (LCP) score. Next.js explicitly discourages this in favor of `next/font/google`.

**Broken Code (`src/app/layout.tsx`):**
```tsx
<head>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
  <link
    href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700&display=swap"
    rel="stylesheet"
  />
</head>
```

**Fixed Code:**
```tsx
import { Inter, Playfair_Display } from 'next/font/google';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' });
const playfair = Playfair_Display({ subsets: ['latin'], variable: '--font-playfair', display: 'swap' });

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`h-full antialiased overflow-x-hidden ${inter.variable} ${playfair.variable}`}>
      <body className="min-h-full flex flex-col overflow-x-hidden w-full">{children}</body>
    </html>
  );
}
```

### Issue 2.2: Unoptimized Standard `<img />` Elements
**Severity: High**

Several client components (e.g., `ProfileClient.tsx`, `EmployeesClient.tsx`) use standard HTML `<img>` elements for profile avatars. These bypass Next.js image optimization features (WebP conversion, lazy loading, blur placeholders), unnecessarily consuming bandwidth.

**Broken Code (`src/app/employee/(portal)/profile/ProfileClient.tsx`):**
```tsx
<img src={currentAvatarUrl} alt="Avatar" className="w-full h-full object-cover" />
```

**Fixed Code:**
```tsx
import Image from 'next/image';

<div className="relative w-full h-full">
  <Image 
    src={currentAvatarUrl} 
    alt="Employee Avatar" 
    fill 
    sizes="(max-width: 768px) 100vw, 33vw"
    className="object-cover" 
  />
</div>
```

---

## 3. Accessibility Basics

### Issue 3.1: Non-Descriptive `alt` Tags on User Profile Images
**Severity: Low**

Images uploaded to the platform lack adequate semantic descriptions. Using `alt="Avatar"` is redundant for screen readers.

**Broken Code (`src/app/employee/(portal)/profile/ProfileClient.tsx`):**
```tsx
<img src={currentAvatarUrl} alt="Avatar" className="w-full h-full object-cover" />
```

**Fixed Code:**
```tsx
<Image 
  src={currentAvatarUrl} 
  alt={`${profile.name}'s profile avatar`} 
  fill 
  className="object-cover" 
/>
```

### Issue 3.2: Missing Aria Controls / Expanded States on Mobile Menu
**Severity: Medium**

The `Navbar` mobile toggle uses an `aria-label` but fails to alert screen readers about the *state* of the navigation menu (whether it is currently open or collapsed).

**Broken Code (`src/components/layout/Navbar.tsx`):**
```tsx
<button
  onClick={() => setIsOpen(!isOpen)}
  className="..."
  aria-label="Toggle navigation menu"
>
```

**Fixed Code:**
```tsx
<button
  onClick={() => setIsOpen(!isOpen)}
  className="..."
  aria-expanded={isOpen}
  aria-controls="mobile-navigation"
  aria-label={isOpen ? "Close navigation menu" : "Open navigation menu"}
>
```
