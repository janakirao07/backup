# 🚀 Antigravity Global Skills Installation — Complete Walkthrough

> **Date**: April 17, 2026  
> **System**: Windows 11  
> **Location**: `C:\Users\janak\.gemini\antigravity\knowledge\`  
> **Total Skills Installed**: 42 Knowledge Items + GSD (73 skills + 31 agents)

---

## Table of Contents
- [Overview](#overview)
- [Phase 1: Original Job Tracker Skills (10 KIs)](#phase-1-original-job-tracker-skills)
- [Phase 2: Prompt Master (1 KI)](#phase-2-prompt-master)
- [Phase 3: Awesome Claude Skills (3 KIs)](#phase-3-awesome-claude-skills)
- [Phase 4: Antigravity Awesome Skills (14 KIs from repo + 6 custom)](#phase-4-antigravity-awesome-skills)
- [Phase 5: Library Best Practices (8 custom KIs)](#phase-5-library-best-practices)
- [GSD System Installation](#gsd-system-installation)
- [Complete Skill Inventory (42 KIs)](#complete-skill-inventory)
- [Directory Structure](#directory-structure)
- [How Skills Were Installed](#how-skills-were-installed)

---

## Overview

This session transformed the Antigravity environment from zero global skills into a **42-skill powerhouse** covering every aspect of modern full-stack development. Skills were sourced from 4 GitHub repos, 1 local project, and 6 were custom-built.

### Sources Used

| Source | GitHub Link | Skills Added |
|--------|-------------|-------------|
| Job Tracker Project | Local: `C:\Users\janak\job-tracker-app\.claude\skills\` | 10 |
| Prompt Master | [nidhinjs/prompt-master](https://github.com/nidhinjs/prompt-master) | 1 |
| Awesome Claude Skills | [ComposioHQ/awesome-claude-skills](https://github.com/ComposioHQ/awesome-claude-skills) | 3 |
| Antigravity Awesome Skills | [sickn33/antigravity-awesome-skills](https://github.com/sickn33/antigravity-awesome-skills) | 14 |
| Custom-Built (missing from repos) | N/A — written by AI | 6 |
| Library Best Practices | Multiple GitHub repos (see Phase 5) | 8 |
| **GSD System** | [gsd-build/get-shit-done](https://github.com/gsd-build/get-shit-done) | **73 skills + 31 agents** |

---

## Phase 1: Original Job Tracker Skills

**Source**: `C:\Users\janak\job-tracker-app\.claude\skills\`  
**Method**: Read each `.md` skill file → Created KI directory → Copied as `artifacts/skill.md` → Created `metadata.json`

| # | Skill Name | KI Directory | Description |
|---|-----------|-------------|-------------|
| 1 | Debug Issue | `skill-debug-issue` | Graph-powered debugging — semantic search, call chain tracing, flow analysis |
| 2 | Explore Codebase | `skill-explore-codebase` | Navigate codebase structure using knowledge graph |
| 3 | Refactor Safely | `skill-refactor-safely` | Safe refactoring with dependency analysis and impact checks |
| 4 | Review Changes | `skill-review-changes` | Risk-aware code reviews with change detection and test coverage |
| 5 | Frontend Design | `skill-frontend-design` | Production-grade frontend with bold typography, animations, themes |
| 6 | UI/UX Pro Max | `skill-ui-ux-pro-max` | Comprehensive UI/UX rules for iOS/Android/React Native/Web |
| 7 | Web Design Guidelines | `skill-web-design-guidelines` | Vercel web interface guidelines compliance auditing |
| 8 | Vercel React Best Practices | `skill-vercel-react-best-practices` | 69 rules across 8 categories for React/Next.js optimization |
| 9 | Remotion Best Practices | `skill-remotion-best-practices` | Video creation in React — captions, FFmpeg, animations, fonts |
| 10 | Find Skills | `skill-find-skills` | Discover and install agent skills from skills.sh ecosystem |

---

## Phase 2: Prompt Master

**Source**: [github.com/nidhinjs/prompt-master](https://github.com/nidhinjs/prompt-master)  
**Method**: Fetched `README.md` via URL → Extracted skill content → Created KI with references and templates

| # | Skill Name | KI Directory | Description |
|---|-----------|-------------|-------------|
| 11 | Prompt Master | `skill-prompt-master` | Generates optimized prompts for 30+ AI tools. 9-dimension intent extraction, 12 templates, safe techniques |

**Artifacts**: `skill.md`, `references/patterns.md`, `references/templates.md`

---

## Phase 3: Awesome Claude Skills

**Source**: [github.com/ComposioHQ/awesome-claude-skills](https://github.com/ComposioHQ/awesome-claude-skills) (⭐ 54.3k)  
**Method**: Fetched each `SKILL.md` from raw GitHub → Copied to KI artifacts → Created metadata

| # | Skill Name | KI Directory | Description |
|---|-----------|-------------|-------------|
| 12 | Webapp Testing | `skill-webapp-testing` | Playwright browser testing for frontend verification and screenshots |
| 13 | Canvas Design | `skill-canvas-design` | Create visual art, posters, infographics in PNG/PDF |
| 14 | Tailored Resume Generator | `skill-resume-generator` | Analyze job descriptions and generate tailored resumes |

> **Note**: Software Architecture skill was unavailable (repo was private/404).

---

## Phase 4: Antigravity Awesome Skills

**Source**: [github.com/sickn33/antigravity-awesome-skills](https://github.com/sickn33/antigravity-awesome-skills) (⭐ 33k, 1,412+ skills)  
**Method**: Cherry-picked 20 most relevant skills from the 1,412+ catalog. 14 fetched from repo, 6 custom-written to fill gaps.

### 4A. Fetched from Repo (14 skills)

| # | Skill Name | KI Directory | Repo Path |
|---|-----------|-------------|-----------|
| 15 | Brainstorming | `skill-brainstorming` | `skills/brainstorming/SKILL.md` |
| 16 | Test-Driven Development | `skill-tdd` | `skills/test-driven-development/SKILL.md` |
| 17 | Debugging Strategies | `skill-debugging-strategies` | `skills/debugging-strategies/SKILL.md` |
| 18 | API Design Principles | `skill-api-design` | `skills/api-design-principles/SKILL.md` |
| 19 | Create PR | `skill-create-pr` | `skills/create-pr/SKILL.md` |
| 20 | Security Auditor | `skill-security-auditor` | `skills/security-auditor/SKILL.md` |
| 21 | Lint & Validate | `skill-lint-validate` | `skills/lint-and-validate/SKILL.md` |
| 22 | Next.js Best Practices | `skill-nextjs-best-practices` | `skills/nextjs-best-practices/SKILL.md` |
| 23 | Database Design | `skill-database-design` | `skills/database-design/SKILL.md` |
| 24 | Postgres Best Practices | `skill-postgres-best-practices` | `skills/postgres-best-practices/SKILL.md` |
| 25 | Performance Profiling | `skill-performance-profiling` | `skills/performance-profiling/SKILL.md` |
| 26 | SEO Fundamentals | `skill-seo-fundamentals` | `skills/seo-fundamentals/SKILL.md` |
| 27 | Error Handling Patterns | `skill-error-handling` | `skills/error-handling-patterns/SKILL.md` |
| 28 | Documentation Writer | `skill-documentation` | `skills/documentation/SKILL.md` |

### 4B. Custom-Built (6 skills — not available in any repo)

These 6 skills were written from scratch with production-quality best practices tailored to the user's tech stack (React, Next.js, Supabase, Chrome Extensions).

| # | Skill Name | KI Directory | What it covers |
|---|-----------|-------------|---------------|
| 29 | Git Workflow | `skill-git-workflow` | Conventional Commits, branching strategy, merge patterns, .gitignore, dangerous commands |
| 30 | TypeScript Patterns | `skill-typescript-patterns` | Generics, discriminated unions, Zod validation, utility types, narrowing, anti-patterns |
| 31 | Chrome Extension Dev | `skill-chrome-extension-dev` | Manifest V3, service workers, content scripts, message passing, storage, rate limiting |
| 32 | Authentication Patterns | `skill-authentication-patterns` | JWT, OAuth, Supabase Auth, RLS policies, RBAC, session management |
| 33 | Accessibility Audit | `skill-accessibility-audit` | WCAG 2.2, color contrast, keyboard navigation, ARIA, heading hierarchy, focus management |
| 34 | Deployment Strategies | `skill-deployment-strategies` | Vercel deployment, GitHub Actions CI/CD, env variables, rollback, monitoring |

---

## Phase 5: Library Best Practices

**Source**: 8 GitHub library repos — converted from "npm libraries" into "best practice Knowledge Items"  
**Method**: Reviewed each repo → Wrote comprehensive best-practice guide → Created KI

| # | Skill Name | KI Directory | GitHub Source | ⭐ Stars |
|---|-----------|-------------|-------------|---------|
| 35 | Three.js Best Practices | `skill-threejs` | [mrdoob/three.js](https://github.com/mrdoob/three.js) | 103k |
| 36 | GSAP Animation | `skill-gsap` | [greensock/GSAP](https://github.com/greensock/GSAP) | 20.7k |
| 37 | Headless UI Patterns | `skill-headlessui` | [tailwindlabs/headlessui](https://github.com/tailwindlabs/headlessui) | 26.7k |
| 38 | Flowbite UI Components | `skill-flowbite` | [themesberg/flowbite](https://github.com/themesberg/flowbite) | 8.6k |
| 39 | Animate UI Components | `skill-animate-ui` | [imskyleen/animate-ui](https://github.com/imskyleen/animate-ui) | 4.1k |
| 40 | Goey Toast Notifications | `skill-goey-toast` | [anl331/goey-toast](https://github.com/anl331/goey-toast) | 400+ |
| 41 | Babylon.js Engine | `skill-babylonjs` | [BabylonJS/Babylon.js](https://github.com/BabylonJS/Babylon.js) | 23.8k |
| 42 | WebGL Fundamentals | `skill-webgl-fundamentals` | [gfxfundamentals/webgl-fundamentals](https://github.com/gfxfundamentals/webgl-fundamentals) | 4.9k |

---

## GSD System Installation

**Source**: [github.com/gsd-build/get-shit-done](https://github.com/gsd-build/get-shit-done)  
**Version**: v1.36.0  
**Location**: `C:\Users\janak\.gemini\antigravity\get-shit-done\`

### What was installed:
- **73 specialized command skills** (`/gsd-*`) — project planning, execution, verification
- **31 specialized sub-agents** — planners, researchers, verifiers, reviewers
- **9 security/workflow hooks** — prompt injection protection, read-before-edit enforcement

### Key GSD Commands:
| Command | Purpose |
|---------|---------|
| `/gsd-new-project` | Initialize new project with deep context gathering |
| `/gsd-map-codebase` | Analyze existing codebase with parallel mapper agents |
| `/gsd-discuss-phase` | Gather phase context through adaptive questioning |
| `/gsd-plan-phase` | Create detailed phase plans with verification |
| `/gsd-execute-phase` | Execute plans with wave-based parallelization |
| `/gsd-verify-work` | Validate features through conversational UAT |
| `/gsd-autonomous` | Run all remaining phases autonomously |
| `/gsd-quick` | Execute small tasks with GSD guarantees |
| `/gsd-next` | Auto-advance to next logical workflow step |
| `/gsd-code-review` | Review source files for bugs, security, quality |

---

## Complete Skill Inventory (42 KIs)

### By Category

#### 🧠 Planning & Ideation (2)
| # | Skill | Trigger |
|---|-------|---------|
| 1 | Brainstorming | Starting any new feature or project |
| 2 | Prompt Master | Writing/optimizing prompts for any AI tool |

#### 🎨 Design & UI (5)
| # | Skill | Trigger |
|---|-------|---------|
| 3 | Frontend Design | Building web UI/components |
| 4 | UI/UX Pro Max | Creating/reviewing any UI |
| 5 | Web Design Guidelines | Auditing design/accessibility compliance |
| 6 | Canvas Design | Creating posters, visual art, infographics |
| 7 | Accessibility Audit | WCAG compliance, keyboard nav, screen readers |

#### 🧩 UI Component Libraries (4)
| # | Skill | Trigger |
|---|-------|---------|
| 8 | Headless UI | Building accessible custom components |
| 9 | Flowbite | Rapid UI with pre-built Tailwind components |
| 10 | Animate UI | Adding animated React components |
| 11 | Goey Toast | Toast notifications with gooey animations |

#### ⚛️ Frameworks (3)
| # | Skill | Trigger |
|---|-------|---------|
| 12 | Vercel React Best Practices | Writing React/Next.js code |
| 13 | Next.js Best Practices | App Router, Server Components, caching |
| 14 | Remotion Best Practices | Video creation in React |

#### 📝 Languages (1)
| # | Skill | Trigger |
|---|-------|---------|
| 15 | TypeScript Patterns | Generics, types, Zod, discriminated unions |

#### 🎬 Animation (1)
| # | Skill | Trigger |
|---|-------|---------|
| 16 | GSAP | Scroll animations, timelines, page transitions |

#### 🎲 3D Graphics (3)
| # | Skill | Trigger |
|---|-------|---------|
| 17 | Three.js | 3D scenes, React Three Fiber, models, shaders |
| 18 | Babylon.js | 3D games, VR/AR, physics, simulations |
| 19 | WebGL Fundamentals | Custom shaders, GPU rendering concepts |

#### 🔧 Code Quality (5)
| # | Skill | Trigger |
|---|-------|---------|
| 20 | Test-Driven Development | Writing tests before code |
| 21 | Lint & Validate | Pre-commit quality checks |
| 22 | Error Handling | Try/catch, error boundaries, retry strategies |
| 23 | Create PR | Packaging work into clean PRs |
| 24 | Git Workflow | Branching, commits, merging |

#### 🔍 Code Intelligence (5)
| # | Skill | Trigger |
|---|-------|---------|
| 25 | Debug Issue | Graph-powered debugging |
| 26 | Debugging Strategies | Systematic troubleshooting |
| 27 | Explore Codebase | Understanding code structure |
| 28 | Refactor Safely | Safe refactoring with impact analysis |
| 29 | Review Changes | Risk-aware code reviews |

#### 🔒 Security & Auth (2)
| # | Skill | Trigger |
|---|-------|---------|
| 30 | Security Auditor | API/code security review, OWASP Top 10 |
| 31 | Authentication Patterns | JWT, OAuth, Supabase Auth, RBAC |

#### 🗄️ Database (2)
| # | Skill | Trigger |
|---|-------|---------|
| 32 | Database Design | Schema design, normalization, indexing |
| 33 | Postgres Best Practices | Supabase/PostgreSQL optimization, RLS |

#### ⚡ Performance & SEO (2)
| # | Skill | Trigger |
|---|-------|---------|
| 34 | Performance Profiling | Bundle analysis, Core Web Vitals, caching |
| 35 | SEO Fundamentals | Meta tags, structured data, crawlability |

#### 🌐 Platform (2)
| # | Skill | Trigger |
|---|-------|---------|
| 36 | Chrome Extension Dev | Manifest V3, service workers, content scripts |
| 37 | Deployment Strategies | Vercel, GitHub Actions, CI/CD, rollback |

#### 📄 Productivity (5)
| # | Skill | Trigger |
|---|-------|---------|
| 38 | Documentation Writer | READMEs, API docs, project docs |
| 39 | API Design Principles | REST conventions, naming, versioning |
| 40 | Tailored Resume Generator | Job-specific resume creation |
| 41 | Webapp Testing | Playwright browser testing |
| 42 | Find Skills | Discovering new skills from skills.sh |

#### 🏗️ Meta-System
| System | Details |
|--------|---------|
| **GSD** | 73 command skills + 31 sub-agents + 9 security hooks |

---

## Directory Structure

```
C:\Users\janak\.gemini\antigravity\
├── knowledge\                          # 42 Knowledge Items
│   ├── skill-accessibility-audit\
│   │   ├── metadata.json
│   │   └── artifacts\
│   │       └── skill.md
│   ├── skill-animate-ui\
│   ├── skill-api-design\
│   ├── skill-authentication-patterns\
│   ├── skill-babylonjs\
│   ├── skill-brainstorming\
│   ├── skill-canvas-design\
│   ├── skill-chrome-extension-dev\
│   ├── skill-create-pr\
│   ├── skill-database-design\
│   ├── skill-debugging-strategies\
│   ├── skill-debug-issue\
│   ├── skill-deployment-strategies\
│   ├── skill-documentation\
│   ├── skill-error-handling\
│   ├── skill-explore-codebase\
│   ├── skill-find-skills\
│   ├── skill-flowbite\
│   ├── skill-frontend-design\
│   ├── skill-git-workflow\
│   ├── skill-goey-toast\
│   ├── skill-gsap\
│   ├── skill-headlessui\
│   ├── skill-lint-validate\
│   ├── skill-nextjs-best-practices\
│   ├── skill-performance-profiling\
│   ├── skill-postgres-best-practices\
│   ├── skill-prompt-master\
│   ├── skill-refactor-safely\
│   ├── skill-remotion-best-practices\
│   ├── skill-resume-generator\
│   ├── skill-review-changes\
│   ├── skill-security-auditor\
│   ├── skill-seo-fundamentals\
│   ├── skill-tdd\
│   ├── skill-threejs\
│   ├── skill-typescript-patterns\
│   ├── skill-ui-ux-pro-max\
│   ├── skill-vercel-react-best-practices\
│   ├── skill-webapp-testing\
│   ├── skill-web-design-guidelines\
│   └── skill-webgl-fundamentals\
├── skills\                             # GSD System (73 skills)
│   └── get-shit-done\
├── mcp_config.json                     # MCP servers (code-review-graph)
└── scratch\                            # Working directory
```

---

## How Skills Were Installed

### Method: Knowledge Item (KI) Pattern

Every skill follows the same structure:

```
skill-<name>/
├── metadata.json       # Title, summary, timestamps, references, artifact list
└── artifacts/
    └── skill.md        # The actual skill content (YAML frontmatter + markdown)
```

### Step-by-step process for each skill:

1. **Create directory**: `New-Item -ItemType Directory -Path "knowledge\skill-<name>\artifacts"`
2. **Fetch/write skill content**: Either fetched from GitHub raw URL or custom-written
3. **Save as artifact**: `artifacts/skill.md`
4. **Create metadata**: `metadata.json` with title, summary, references, timestamps

### metadata.json format:
```json
{
  "title": "Skill: <Name>",
  "summary": "<When and how to use this skill>",
  "created": "2026-04-17T05:00:00Z",
  "updated": "2026-04-17T05:00:00Z",
  "references": ["https://github.com/..."],
  "artifacts": ["artifacts/skill.md"]
}
```

### skill.md format:
```markdown
---
name: skill-name
description: When to trigger this skill
---

# Skill Title

## Section 1
...content...

## Section 2
...content...
```

---

## How to Use in Future Projects

1. **Open any project folder** in Antigravity
2. All 42 KIs are **automatically available** globally
3. They trigger based on context — e.g., writing React code activates `vercel-react-best-practices`
4. For GSD workflow:
   - Run `/gsd-map-codebase` to analyze existing code
   - Run `/gsd-new-project` to define milestones
   - Run `/gsd-next` to auto-advance workflow

---

> **Session Status**: Complete. 42 Knowledge Items + GSD system globally configured and ready for autonomous, project-aware development across all workspaces.
