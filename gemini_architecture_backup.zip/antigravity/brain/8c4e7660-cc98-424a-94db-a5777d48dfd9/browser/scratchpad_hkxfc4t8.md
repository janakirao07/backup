# Task: Identify fonts on skdegreecollege.com

## Plan
- [x] Open https://skdegreecollege.com
- [x] Identify heading font family
- [x] Identify body font family
- [x] Report findings

## Findings
- Heading Font: Playfair Display
- Body Font: Lato
