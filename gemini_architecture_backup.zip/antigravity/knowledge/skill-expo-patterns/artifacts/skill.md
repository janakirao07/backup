# Expo Patterns

## Expo Router (Navigation)
```tsx
// app/_layout.tsx
import { Stack } from 'expo-router';
export default function Layout() {
  return <Stack screenOptions={{ headerShown: false }} />;
}

// app/index.tsx
import { Link } from 'expo-router';
export default function Home() {
  return <Link href="/profile/123">Go to Profile</Link>;
}
```

## EAS Build (Cloud Building)
```bash
eas build:configure
eas build --platform ios
eas build --platform android --profile production
```

## EAS Update (OTA Updates)
Deploy fixes directly to users' phones without app store review.
```bash
eas update --branch production --message "Fix login bug"
```

## Config Plugins (app.json)
Modify native iOS/Android code without ejecting.
```json
{
  "expo": {
    "plugins": [
      [
        "expo-camera",
        { "cameraPermission": "Allow App to access your camera" }
      ]
    ]
  }
}
```
