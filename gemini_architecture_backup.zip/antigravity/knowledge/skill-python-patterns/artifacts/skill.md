# Python Patterns

## Dataclasses
```python
from dataclasses import dataclass
@dataclass
class User:
    id: int
    name: str
    active: bool = True
```

## Typing
```python
from typing import List, Dict, Optional
def process(data: List[int]) -> Optional[Dict[str, int]]:
    if not data: return None
    return {'sum': sum(data)}
```