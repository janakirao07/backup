# Primetek Attendance Sheet Migration Checklist

- [ ] Navigate to Google Sheet URL (Done, but sign-in required)
- [ ] Check accessibility and login status (Sign-in required)
- [ ] Open File -> Import
- [ ] Upload local file: `c:\Users\janak\Downloads\_Projects\New folder\Primetek_Attendance_2026_Master.xlsx`
- [ ] Select 'Replace spreadsheet' or 'Insert new sheets'
- [ ] Confirm import
- [ ] Verify monthly tabs (Jan - Dec)

## Findings
- Navigation to the Google Sheet URL redirected to the Google Sign-in page.
- Current state: Not signed in.
- Action needed: User needs to sign in or provide a link with public edit access.
