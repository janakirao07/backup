# E-commerce Patterns

## Cart State (Zustand)
```ts
const useCart = create((set) => ({
  items: [],
  addItem: (product) => set((state) => ({ items: [...state.items, product] })),
  total: () => get().items.reduce((sum, item) => sum + item.price, 0),
}));
```
## Idempotency
- Always use idempotency keys for payment processing to avoid double charges.