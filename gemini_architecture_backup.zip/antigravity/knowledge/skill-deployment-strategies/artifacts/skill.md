---
name: deployment-strategies
description: CI/CD, deployment, and release best practices. Use when setting up deployments, configuring CI/CD pipelines, managing environments, or shipping to production.
---

# Deployment Strategies

## Environment Setup
| Environment | Purpose | Data | Access |
|-------------|---------|------|--------|
| **local** | Development | Fake/seed data | Developer only |
| **staging** | Pre-production testing | Production-like | Team |
| **production** | Live users | Real data | Public |

## Environment Variables
```bash
# .env.local (git-ignored, local dev)
DATABASE_URL=postgresql://localhost:5432/myapp_dev
NEXT_PUBLIC_API_URL=http://localhost:3000/api
SUPABASE_URL=http://localhost:54321
SUPABASE_ANON_KEY=eyJ...local

# .env.production (or set in hosting platform)
DATABASE_URL=postgresql://prod-host:5432/myapp
NEXT_PUBLIC_API_URL=https://myapp.com/api
SUPABASE_URL=https://xyz.supabase.co
SUPABASE_ANON_KEY=eyJ...prod
```

### Rules
- NEVER commit `.env` files with real secrets
- Use `.env.example` with placeholder values in git
- Set production secrets in hosting platform's dashboard
- Prefix client-side vars with `NEXT_PUBLIC_` (Next.js) or `VITE_` (Vite)

## Vercel Deployment (Next.js)
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy to preview
vercel

# Deploy to production
vercel --prod

# Set environment variables
vercel env add SUPABASE_URL production
```

### vercel.json
```json
{
  "buildCommand": "npm run build",
  "outputDirectory": ".next",
  "framework": "nextjs",
  "headers": [
    {
      "source": "/api/(.*)",
      "headers": [
        { "key": "Cache-Control", "value": "no-store" }
      ]
    }
  ]
}
```

## GitHub Actions CI/CD
```yaml
# .github/workflows/ci.yml
name: CI/CD
on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'
      - run: npm ci
      - run: npm run lint
      - run: npm run type-check
      - run: npm test

  deploy:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: amondnet/vercel-action@v25
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
          vercel-args: '--prod'
```

## Deployment Strategies
| Strategy | How it works | Risk | Rollback |
|----------|-------------|------|----------|
| **Rolling** | Gradually replace old with new | Low | Moderate |
| **Blue-Green** | Run old + new, switch traffic | Very low | Instant |
| **Canary** | Route 5-10% traffic to new first | Very low | Instant |
| **Recreate** | Stop old, start new | High (downtime) | Slow |

## Pre-Deploy Checklist
- [ ] All tests pass (unit, integration, e2e)
- [ ] Linting passes with zero errors
- [ ] TypeScript compiles with no errors
- [ ] Build completes successfully
- [ ] Environment variables set in target platform
- [ ] Database migrations applied
- [ ] No console.log / debug code in production
- [ ] Error monitoring configured (Sentry, etc.)
- [ ] Performance budget met (bundle size, LCP)
- [ ] Security headers configured
- [ ] CORS configured correctly
- [ ] SSL/HTTPS enforced

## Post-Deploy Verification
- [ ] Smoke test critical user flows
- [ ] Check error monitoring for new errors
- [ ] Verify API responses are correct
- [ ] Check performance metrics (Core Web Vitals)
- [ ] Confirm environment variables loaded correctly
- [ ] Test auth flows (login, signup, logout)
- [ ] Verify database connections are healthy

## Rollback Plan
```bash
# Vercel — instant rollback to previous deployment
vercel rollback

# Git — revert the deployment commit
git revert HEAD
git push origin main

# Database — keep migration rollback scripts ready
npx prisma migrate down  # or custom rollback SQL
```

## Monitoring After Deploy
- **Error tracking**: Sentry, LogRocket
- **Performance**: Vercel Analytics, Lighthouse CI
- **Uptime**: UptimeRobot, Pingdom
- **Logs**: Vercel logs, Supabase logs
