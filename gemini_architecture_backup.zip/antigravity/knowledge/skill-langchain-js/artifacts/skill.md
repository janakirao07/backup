# LangChain.js

## Chain
```ts
import { ChatOpenAI } from '@langchain/openai';
import { PromptTemplate } from '@langchain/core/prompts';
const model = new ChatOpenAI({ model: 'gpt-4o' });
const prompt = PromptTemplate.fromTemplate('Tell me a joke about {topic}');
const chain = prompt.pipe(model);
const res = await chain.invoke({ topic: 'bears' });
```