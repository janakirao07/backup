# Technical Guide: Overcoming Fake Logins & Attendance Fraud

To systematically eliminate fake attendance logins, geofencing bypasses, and proxy clock-ins ("buddy punching"), we must transition from a **client-reported** trust model to a **cryptographically and network-verified** server model.

Here is the exact step-by-step roadmap to harden the Primetek Global Solution system, including ready-to-use production-grade code patterns.

---

## 1. Quick Win: Server-Side IP & Network Whitelisting

**Objective**: Block any clock-in attempt that does not originate from the official office Internet connection (Wi-Fi/Ethernet). This eliminates remote spoofing (VPNs, DevTools, fake GPS) instantly.

### Implementation Blueprint
Create or modify a Next.js server route or middleware that validates the client's public IP address before saving the clock-in event:

```typescript
// File: src/app/api/attendance/check-in/route.ts
import { NextResponse } from 'next/server';
import { headers } from 'next/headers';

// Whitelisted Office Public IP addresses (configured in env)
const OFFICE_IPS = process.env.OFFICE_PUBLIC_IPS?.split(',') || ['203.0.113.50', '198.51.100.12'];

export async function POST(req: Request) {
  const headersList = await headers();
  
  // Extract client IP address behind Vercel / Cloudflare proxy
  const clientIp = 
    headersList.get('x-forwarded-for')?.split(',')[0].trim() || 
    headersList.get('x-real-ip') || 
    '127.0.0.1';

  // Under WFH/Remote exceptions, we might allow manual manager flags.
  // Otherwise, strict office-only enforcement is verified here:
  const isOfficeNetwork = OFFICE_IPS.includes(clientIp);

  if (!isOfficeNetwork) {
    return NextResponse.json(
      { 
        success: false, 
        error: 'Forbidden: Attendance logins are only permitted from the official office Wi-Fi network.',
        detectedIp: clientIp
      },
      { status: 403 }
    );
  }

  // Proceed with standard Supabase DB write...
  return NextResponse.json({ success: true, message: 'Clock-in approved.' });
}
```

- **Pros**: 100% immune to GPS spoofing and mobile mock location apps. Trivial to implement.
- **Cons**: Requires employees to be connected to the corporate Wi-Fi.

---

## 2. Advanced: Cryptographic Device Fingerprinting & Binding

**Objective**: Ensure that an employee can **only** clock in from their registered personal phone or designated work computer. If they try to log into another employee's account to clock them in, the system detects the foreign hardware signature and blocks it.

### Step A: Database Schema Upgrade
Create a `user_devices` table to bind a unique fingerprint hash to each account:

```sql
CREATE TABLE user_devices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  device_fingerprint TEXT UNIQUE NOT NULL,
  device_name TEXT,
  registered_at TIMESTAMPTZ DEFAULT now()
);

-- Index for instant lookups during logins
CREATE INDEX idx_user_devices_fingerprint ON user_devices(device_fingerprint);
```

### Step B: Generate & Bind Fingerprint (Client)
Use high-entropy canvas and browser indicators to generate a persistent hardware fingerprint:

```typescript
// File: src/utils/fingerprint.ts
export async function getDeviceFingerprint(): Promise<string> {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) return 'unknown_fallback';

  // Draw complex webgl/canvas elements to trigger hardware-specific rendering noise
  ctx.textBaseline = 'top';
  ctx.font = "14px 'Arial'";
  ctx.textBaseline = "alphabetic";
  ctx.fillStyle = "#f60";
  ctx.fillRect(125,1,62,20);
  ctx.fillStyle = "#069";
  ctx.fillText("PrimetekSecTrust1.0", 2, 15);
  ctx.fillStyle = "rgba(102, 204, 0, 0.7)";
  ctx.fillText("PrimetekSecTrust1.0", 4, 17);
  
  const rawData = canvas.toDataURL();
  
  // Create a SHA-256 hash of the render outputs and device specifications
  const hashBuffer = await crypto.subtle.digest(
    'SHA-256', 
    new TextEncoder().encode(rawData + navigator.userAgent + screen.width)
  );
  
  return Array.from(new Uint8Array(hashBuffer))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('');
}
```

### Step C: Server Validation
```typescript
// On Clock-in post request:
const fingerprint = req.body.deviceFingerprint;
const userId = req.user.id;

// Check if device matches user's registered device
const { data: device } = await supabase
  .from('user_devices')
  .select('*')
  .eq('user_id', userId)
  .eq('device_fingerprint', fingerprint)
  .single();

if (!device) {
  // If user has no device registered yet, register this as their primary device
  const { data: hasAnyDevice } = await supabase
    .from('user_devices')
    .select('id')
    .eq('user_id', userId);

  if (hasAnyDevice && hasAnyDevice.length > 0) {
    return NextResponse.json({ 
      success: false, 
      error: 'Security Alert: You are attempting to clock in from an unregistered device. Please use your primary registered smartphone.'
    }, { status: 403 });
  } else {
    // Bind first device
    await supabase.from('user_devices').insert({ user_id: userId, device_fingerprint: fingerprint });
  }
}
```

- **Pros**: Stops "buddy punching" completely. One device = one active employee check-in.
- **Cons**: If an employee buys a new phone, an admin must reset their registered device signature.

---

## 3. Gold Standard: Passwordless WebAuthn / Passkeys

**Objective**: Eliminate standard passwords and MFA SMS codes entirely. The employee logs in by verifying FaceID/TouchID or their lock screen passcode directly on their device.

### How it works
1. When clocking in, the browser requests a cryptographic signature from the device's hardware enclave (using the secure hardware key).
2. The user holds their thumb or looks at their camera.
3. The hardware returns an assertion signature that *cannot* be copied, shared over SMS, or screenshotted.
4. The server validates the signature. It is cryptographically mathematically impossible for Employee A to sign in from Employee B's phone, even if they share their PIN.

```mermaid
sequenceDiagram
    participant E as Employee Phone
    participant S as Next.js Server
    participant DB as Supabase DB
    
    E->>S: Request Login Challenge
    S-->>E: Return Cryptographic Challenge
    E->>E: User Biometric Verification (FaceID)
    E->>S: Submit Signed Challenge
    S->>S: Verify Public Key Mathematical Signature
    S-->>E: Login & Clock-In Successful
```

---

## Strategic Recommendation Summary

| Mitigation Level | Solution | Attack Vectors Blocked | Friction Level | Setup Speed |
| :--- | :--- | :--- | :--- | :--- |
| **Tier 1 (Immediate)** | **IP Whitelisting** | GPS spoofing, DevTools overrides, Home logins | **Very Low** (Requires Wi-Fi) | 30 Minutes |
| **Tier 2 (Highly Recommended)** | **Device Binding** | Multi-account sharing, emulators, proxy clock-ins | **Low** (Transparent) | 2 Hours |
| **Tier 3 (Enterprise)** | **Biometric Selfie + Liveness** | Buddy punching, credentials sharing, mock setups | **Medium** (Takes a photo) | 1 Day |
| **Tier 4 (Absolute Security)** | **WebAuthn Passkeys** | All credential sharing, stolen tokens, session replays | **Zero** (Instant FaceID) | 2 Days |
