# Job Tracker App Security & Bug Fixes

This plan outlines the steps to resolve the identified security risk of duplicated hardcoded Supabase keys, fix URL parameter handling, correct datetime parsing issues, and improve local developer experience.

## Proposed Changes

### Configuration Management

We will centralize the hardcoded API keys into a single `config.js` to ensure they are easily manageable and only loaded once, instead of scattered throughout multiple `.js` files. 

#### [NEW] [config.js](file:///c:/Users/janak/Drug_project/job-tracker-app/config.js)
- Will contain `window.CONFIG = { SUPABASE_URL: "...", SUPABASE_KEY: "..." }`.

#### [MODIFY] [manifest.json](file:///c:/Users/janak/Drug_project/job-tracker-app/manifest.json)
- Add `"config.js"` to `content_scripts` to load before `content.js`.
- Add `"http://localhost:*/*"` to `externally_connectable` matches to support local debugging. 

#### [MODIFY] [background.js](file:///c:/Users/janak/Drug_project/job-tracker-app/background.js)
- Import `config.js` via `importScripts('config.js')` since it runs as a service worker.
- Replace internal keys with `CONFIG.SUPABASE_URL` and `CONFIG.SUPABASE_KEY`.

#### [MODIFY] [app.js](file:///c:/Users/janak/Drug_project/job-tracker-app/app.js)
- Replace internal keys with `CONFIG.SUPABASE_URL` and `CONFIG.SUPABASE_KEY`.
- Update `EXT_ID` placeholder logic to properly extract the parameter from the URL using `URLSearchParams(window.location.search).get('ext_id')`.

#### [MODIFY] [content.js](file:///c:/Users/janak/Drug_project/job-tracker-app/content.js)
- Replace internal keys with `CONFIG.SUPABASE_URL` and `CONFIG.SUPABASE_KEY`.
- Fix the date logic for standard tracking avoiding timezone discrepancy by using the precise `dateKey` property.

#### [MODIFY] [popup.js](file:///c:/Users/janak/Drug_project/job-tracker-app/popup.js)
- Replace internal keys with `CONFIG.SUPABASE_URL` and `CONFIG.SUPABASE_KEY`.

#### [MODIFY] HTML files
We will inject `<script src="config.js"></script>` into the following files before the main script tag:
- [index.html](file:///c:/Users/janak/Drug_project/job-tracker-app/index.html)
- [app.html](file:///c:/Users/janak/Drug_project/job-tracker-app/app.html)
- [popup.html](file:///c:/Users/janak/Drug_project/job-tracker-app/popup.html)

## Verification Plan

### Automated Tests
- Run `node -c` on all target javascript files after modification to check for syntax validity.
- Finally stage the changes and create a Git commit fixing the features successfully.

## User Review Required

Does this structure make sense to you? Adding one central `config.js` script allows you to decouple environments (e.g., prod vs staging) quickly in the future without hunting through 5 script files. Let me know if you would like me to proceed!
