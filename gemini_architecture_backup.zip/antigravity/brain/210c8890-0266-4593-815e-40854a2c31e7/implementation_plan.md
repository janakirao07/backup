# Kanban Board View Implementation Plan

## Goal
Implement a drag-and-drop Kanban Board view for the Job Tracker dashboard. This will provide a visually impressive and highly functional alternative to the existing table list view, similar to the sambai-dev project, but fully integrated into your own lightweight Vanilla JS architecture.

## Proposed Changes

### [MODIFY] `src/scripts/app.js`
- **State Management**:
  - Introduce a new state variable: `let currentView = localStorage.getItem('rjd_view_mode') || 'list';`
  - Ensure the view preference is saved locally across sessions.
- **Render Logic Updates**:
  - Update `renderApplications()` to handle two distinct UI layouts:
    - **List View**: The existing table rendering.
    - **Board View**: A new Kanban-style rendering.
  - Add a View Toggle (List vs Board) in the `section-card-header` near the filters.
- **Kanban Board Rendering**:
  - Define columns for `STATUSES` (`Applied`, `Interview Scheduled`, `Interview Done`, `Offer`, `Rejected`, `Skipped`).
  - Render a responsive horizontal-scrolling flex container for the board.
  - Map `filtered` apps into their respective status columns as styled glassmorphism cards.
- **Drag and Drop Engine (Vanilla JS HTML5 API)**:
  - Add `draggable="true"` to each Kanban card.
  - Implement `ondragstart` to pass the application ID (`e.dataTransfer.setData('app_id', id)`).
  - Add `ondragover` to columns to allow dropping (`e.preventDefault()`).
  - Implement `ondrop` logic on columns:
    1. Extract `app_id`.
    2. Determine the new status from the column.
    3. Update the app state.
    4. Call `await updateApp(app)` to commit to Supabase.
    5. Trigger `renderApplications()` and `showToast()` to update the UI.
    6. Update stats/badges.

### [MODIFY] `src/pages/app.html`
- **CSS Additions**: Add styles for the Kanban board and cards in the `<style>` block.
  - `.kanban-container`: Horizontal scrolling, snap padding.
  - `.kanban-column`: Fixed width (e.g. 300px), distinct background, rounded corners.
  - `.kanban-col-header`: Colored top border/badge based on status.
  - `.kanban-card`: Draggable, glassmorphism UI, hover lift effect, and cursor styling.
  - `.kanban-card-title`, `.kanban-card-company`, `.kanban-card-date`.

## Verification Plan

### Automated
- No automated tests required for this pure-UI/client logic addition within the existing file structure.

### Manual Verification
- **Toggle View**: Open the dashboard, click the "Board" toggle, verify the layout switches from table to columns.
- **Data Distribution**: Verify that jobs properly fall into their respective status columns.
- **Drag and Drop**: Drag a job from "Applied" to "Interview Scheduled". Verify that:
  - The card moves.
  - A toast confirmation appears.
  - Upon refreshing the page, the job remains in the new status (verifying Supabase update).
- **Responsive Review**: View on mobile screen to ensure columns stack or scroll nicely horizontally.
- **State Persistence**: Reload the page, ensure the view defaults back to "Board View" if left on it.

## Open Questions

> [!IMPORTANT]
> 1. For mobile view, Kanban boards can sometimes be clunky. I propose that on mobile screens (`< 768px`), we either hide the Board View toggle and force List View, OR we let the user swipe horizontally through the columns. Which do you prefer? Horizontal swiping is generally accepted.
