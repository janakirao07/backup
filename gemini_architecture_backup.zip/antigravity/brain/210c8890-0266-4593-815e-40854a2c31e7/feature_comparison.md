# Feature Comparison: Your App vs sambai-dev/job-tracker-app

## What They Have That You Don't (Ideas to Adopt)

### 🔥 High Impact — Can Add to Your Current Stack

| Feature | What It Does | Effort to Add |
|---------|-------------|---------------|
| **Kanban Board View** | Drag-and-drop cards between columns (Applied → Interview → Offer) | Medium — Add a new page with CSS grid columns + drag events |
| **Priority Tagging** | Mark jobs as High / Medium / Low priority with color-coded badges | Easy — Add a `priority` field to your Supabase table + badge CSS |
| **Command Palette** | `Ctrl+K` to search jobs, navigate, and take actions instantly | Medium — Build a modal overlay with fuzzy search on your app data |
| **Keyboard Shortcuts** | `/` to search, `C` to create, `Shift+T` to toggle theme | Easy — Add `keydown` listeners in app.js |
| **Interview Calendar** | Monthly calendar view showing scheduled interviews | Medium — Render a CSS grid calendar from your `follow_up_date` data |
| **Job URL Parsing** | Paste a job URL → auto-extract company, title, description | Medium — Use your existing Gemini AI to parse pasted URLs |
| **Dark/Light on Login** | Their auth page respects the system theme preference | Easy — Your login already has dark mode; just read `prefers-color-scheme` |

---

### ⭐ Medium Impact — Nice Polish Features

| Feature | What It Does | Effort to Add |
|---------|-------------|---------------|
| **Search/Filter Bar Focus** | Press `/` to instantly focus the search input | Trivial — 5 lines of JS |
| **Optimistic Updates** | UI updates instantly before server confirms | Medium — Update local array first, then sync |
| **Seniority Classification** | Auto-tag jobs as Junior/Mid/Senior based on JD keywords | Easy — Run regex patterns on your saved job descriptions |
| **Role Type Detection** | Auto-detect Frontend/Backend/Fullstack from JD | Easy — Score keywords against known tech stacks |
| **Confidence Badges** | Show ✓ High / ~ Medium / ? Low confidence on auto-detected fields | Easy — CSS badges based on keyword match scores |
| **Interview Conflict Detection** | Warn when two interviews are on the same day | Easy — Query your `follow_up_date` for duplicates |

---

### 🧊 Low Priority — Requires Architecture Change

| Feature | What It Does | Why It's Hard |
|---------|-------------|---------------|
| **Google Calendar Sync** | Two-way sync with Google Calendar | Requires OAuth + Google API integration |
| **Email Reminders** | Auto-send 24hr interview reminders | Needs a backend email service (Resend) + cron jobs |
| **Multiple Boards** | Separate boards per job search campaign | Requires schema changes in Supabase |
| **Fractional Ordering** | O(1) drag-and-drop reordering algorithm | Your current approach works fine for your scale |

---

## What You Have That They Don't ✅

| Your Feature | Advantage |
|-------------|-----------|
| **Chrome Extension** | Auto-capture jobs from any website — they can't do this |
| **AI Blaze Chat** | In-app AI assistant for resume/cover letter generation |
| **Resume Engine** | Built-in resume tailoring + DOCX export |
| **ATS Eligibility Check** | AI checks if you're eligible before applying |
| **Extension Sidebar** | View/edit job data without leaving the job posting page |
| **PWA Support** | Installable as a mobile app |
| **No Backend Server** | Direct Supabase = zero server costs, instant deployment |

---

## Recommended Next Features (Priority Order)

> [!TIP]
> These 5 features would give the biggest user experience upgrade with the least effort:

1. **Priority Tags** — Add a `priority` column to Supabase (`high`/`medium`/`low`), render colored badges in the table
2. **Keyboard Shortcuts** — `/` to search, `C` to create, `Esc` to close modals
3. **Kanban View** — A new page alongside your table view, with drag-and-drop columns
4. **Auto Job Classification** — Parse saved JDs to auto-tag seniority + role type
5. **Command Palette** — `Ctrl+K` overlay for power users

> [!NOTE]
> Your Chrome Extension + AI Blaze combo is a **major differentiator** that sambai-dev doesn't have. Focus on polishing those unique features while cherry-picking the UX improvements above.
