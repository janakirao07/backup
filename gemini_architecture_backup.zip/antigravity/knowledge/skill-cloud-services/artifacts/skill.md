# Cloud Services — AWS, GCP, Azure

## Service Comparison
| Purpose | AWS | GCP | Azure |
|---------|-----|-----|-------|
| Compute (VMs) | EC2 | Compute Engine | Virtual Machines |
| Serverless | Lambda | Cloud Functions | Azure Functions |
| Containers | ECS/EKS | Cloud Run/GKE | AKS |
| Object Storage | S3 | Cloud Storage | Blob Storage |
| Database (SQL) | RDS | Cloud SQL | Azure SQL |
| Database (NoSQL) | DynamoDB | Firestore | Cosmos DB |
| CDN | CloudFront | Cloud CDN | Azure CDN |
| DNS | Route 53 | Cloud DNS | Azure DNS |
| Auth | Cognito | Firebase Auth | Azure AD B2C |
| AI/ML | SageMaker | Vertex AI | Azure ML |
| Messaging | SQS/SNS | Pub/Sub | Service Bus |

## AWS S3 (Object Storage)
```bash
# CLI
aws s3 cp file.zip s3://my-bucket/
aws s3 sync ./build s3://my-bucket/ --delete
aws s3 ls s3://my-bucket/

# Static website hosting
aws s3 website s3://my-bucket/ --index-document index.html --error-document error.html
```

```python
# Python (boto3)
import boto3
s3 = boto3.client('s3')
s3.upload_file('local_file.txt', 'my-bucket', 'remote/path/file.txt')
s3.download_file('my-bucket', 'remote/path/file.txt', 'local_file.txt')

# Generate presigned URL (temporary access)
url = s3.generate_presigned_url('get_object',
    Params={'Bucket': 'my-bucket', 'Key': 'file.txt'}, ExpiresIn=3600)
```

## AWS Lambda (Serverless)
```python
# handler.py
import json

def lambda_handler(event, context):
    body = json.loads(event.get('body', '{}'))
    return {
        'statusCode': 200,
        'headers': {'Content-Type': 'application/json'},
        'body': json.dumps({'message': 'Success', 'data': body})
    }
```

## GCP Cloud Functions
```python
# main.py
import functions_framework

@functions_framework.http
def hello(request):
    data = request.get_json(silent=True) or {}
    return {'message': 'Hello', 'input': data}, 200
```

```bash
gcloud functions deploy hello --runtime python311 --trigger-http --allow-unauthenticated
```

## GCP Cloud Run (Containers)
```bash
# Deploy a container image
gcloud run deploy myapp \
  --image gcr.io/project-id/myapp:latest \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --memory 512Mi \
  --cpu 1 \
  --min-instances 0 \
  --max-instances 10
```

## IAM Best Practices
- **Least privilege**: Grant minimum permissions needed
- **Use roles, not users**: Assign permissions to roles, attach roles
- **No root/admin for apps**: Create service accounts with scoped permissions
- **Rotate keys regularly**: Automate key rotation
- **MFA everywhere**: Enforce multi-factor authentication

## Cost Optimization
- Use spot/preemptible instances for non-critical workloads (60-90% cheaper)
- Right-size instances — monitor and downgrade over-provisioned resources
- Use auto-scaling to scale to zero when idle
- Set billing alerts at 50%, 80%, 100% thresholds
- Use reserved instances for predictable workloads (30-60% savings)
- Delete unused resources: unattached volumes, old snapshots, idle load balancers
- Use serverless (Lambda/Cloud Functions) for sporadic workloads

## Free Tiers (Good for Side Projects)
| Service | AWS Free | GCP Free | Azure Free |
|---------|----------|----------|------------|
| Compute | 750hrs EC2 t2.micro/yr | 1 e2-micro forever | 750hrs B1s/yr |
| Storage | 5GB S3/yr | 5GB GCS forever | 5GB Blob/yr |
| Serverless | 1M Lambda/mo | 2M Cloud Functions/mo | 1M Functions/mo |
| Database | 750hrs RDS/yr | 1GB Firestore forever | 250GB SQL/yr |
