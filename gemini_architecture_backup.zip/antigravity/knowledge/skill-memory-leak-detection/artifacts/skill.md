# Memory Leaks

## Common Causes
1. **Event Listeners**: `window.addEventListener` without `removeEventListener`.
2. **Timers**: `setInterval` not cleared.
3. **Closures**: Keeping large objects referenced inside closures.

## Prevention (React)
```tsx
useEffect(() => {
  const handler = () => {};
  window.addEventListener('resize', handler);
  return () => window.removeEventListener('resize', handler); // Cleanup!
}, []);
```