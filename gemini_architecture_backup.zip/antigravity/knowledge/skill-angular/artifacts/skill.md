# Angular Essentials

## Component (Standalone — Angular 17+)
```typescript
import { Component, signal, computed } from '@angular/core';

@Component({
  selector: 'app-counter',
  standalone: true,
  template: `
    <button (click)="increment()">Count: {{ count() }} ({{ doubled() }})</button>
  `,
  styles: [`button { padding: 8px 16px; background: #6366f1; color: white; border-radius: 8px; }`]
})
export class CounterComponent {
  count = signal(0);
  doubled = computed(() => this.count() * 2);

  increment() { this.count.update(v => v + 1); }
}
```

## Service & Dependency Injection
```typescript
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class UserService {
  private http = inject(HttpClient);
  private apiUrl = '/api/users';

  getUsers() { return this.http.get<User[]>(this.apiUrl); }
  getUser(id: string) { return this.http.get<User>(`${this.apiUrl}/${id}`); }
  createUser(user: User) { return this.http.post<User>(this.apiUrl, user); }
}
```

## Routing
```typescript
import { Routes } from '@angular/router';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'dashboard', loadComponent: () => import('./dashboard/dashboard.component').then(m => m.DashboardComponent) },
  { path: 'user/:id', loadComponent: () => import('./user/user.component').then(m => m.UserComponent) },
  { path: '**', redirectTo: '' },
];
```

## Reactive Forms
```typescript
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';

@Component({
  imports: [ReactiveFormsModule],
  template: `
    <form [formGroup]="form" (ngSubmit)="onSubmit()">
      <input formControlName="email" placeholder="Email" />
      <input formControlName="password" type="password" placeholder="Password" />
      <button type="submit" [disabled]="form.invalid">Login</button>
    </form>
  `
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  form = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(8)]],
  });

  onSubmit() {
    if (this.form.valid) console.log(this.form.value);
  }
}
```

## Key Patterns
- Use **standalone components** (no NgModules needed in Angular 17+)
- Use **signals** for state (`signal()`, `computed()`, `effect()`)
- Use `inject()` function instead of constructor injection
- Use **lazy loading** with `loadComponent` for route-level code splitting
- Use **OnPush** change detection for performance
- Use `async` pipe in templates for observables
- Structure: `features/`, `shared/`, `core/` folders
