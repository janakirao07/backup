# React DevTools

## Profiler
- Record interaction, view flamegraph.
- "Why did this render?" will show which props/state changed.
## Settings
- Turn on "Highlight updates when components render" to visually see excessive renders in UI.