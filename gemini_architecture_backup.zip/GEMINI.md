# Gemini Bootloader (Antigravity Architecture v2)
[active/current-context.md](file:///C:/Users/janak/.gemini/active/current-context.md)
[shared-global/security.md](file:///C:/Users/janak/.gemini/shared-global/security.md)
[shared-global/workflow.md](file:///C:/Users/janak/.gemini/shared-global/workflow.md)
[shared-global/debugging.md](file:///C:/Users/janak/.gemini/shared-global/debugging.md)
[shared-global/performance.md](file:///C:/Users/janak/.gemini/shared-global/performance.md)
[shared-global/typescript.md](file:///C:/Users/janak/.gemini/shared-global/typescript.md)
[shared-global/project-initialization-policy.md](file:///C:/Users/janak/.gemini/shared-global/project-initialization-policy.md)
[registry/skills.json](file:///C:/Users/janak/.gemini/registry/skills.json)

## 🎨 Global Default Design Loaders
*   **[design-taste-frontend](file:///c:/Users/janak/Downloads/resume_builder_app/.agents/skills/design-taste-frontend/SKILL.md)**: Prevents default AI layouts, centered heroes, and slate themes.
*   **taste-skill**: Excludes "AI slop" patterns.
*   **[ui-ux-core](file:///c:/Users/janak/.gemini/antigravity/knowledge/skill-ui-ux-core/artifacts/skill.md)**: General accessibility, core timed actions, and light/dark parity rules.
## Scopes & Boundaries
- Workspace: Configured in active current-context.md
- Ignore: `projects/archived/`, `knowledge/archived/`
- Search: Scoped to active workspace directory (excluding node_modules).
- Blocked Frameworks: Vue, Svelte, Angular, Flutter, FastAPI.
- Blocked Domains: E-commerce, payment gateways (Razorpay).
- Anti-Hallucination: Verify database schemas before querying.

## Complexity Tiering
- **Tier 0**: Questions, explanations, reviews, discussions. No skills, no planning.
- **Tier 0.5**: Typos, import fixes, comment updates, formatting, single-line corrections. No skills, no planning.
- **Tier 1**: Small code changes, single-file fixes, project scaffolding, and documentation-only changes. Optional skill loading. Lightweight execution.
- **Tier 2**: Features, UI work, multi-file functional modifications. Required skill loading. Batch Mode. Full `implementation_plan.md` & user approval.
- **Tier 3**: Architecture, security, database, complex refactors. Required skill loading. Conditional graph query (`code_review_graph` required for system refactors; optional for migrations and local hotfixes). Strict `implementation_plan.md` approval.

