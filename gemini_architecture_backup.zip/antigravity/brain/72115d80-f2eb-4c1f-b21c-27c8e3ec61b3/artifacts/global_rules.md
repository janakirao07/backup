# 🌐 Global Customization Rules for Antigravity

> Copy these rules to your Antigravity **User Settings → Custom Rules** to apply them to ALL projects.

---

## 1. 🧠 Knowledge & Context — Always Check Before Acting

- **ALWAYS check Knowledge Items (KIs)** before writing code, fixing bugs, or making architectural decisions. KIs contain curated patterns specific to my projects.
- **ALWAYS check conversation history** when a task relates to previously completed work. Don't redo what's already been done.
- Before researching externally, check if a relevant **skill** exists in the knowledge base (108+ skills available covering Next.js, Supabase, React, TypeScript, security, accessibility, etc.).
- When encountering an unfamiliar library or pattern in my codebase, **read the existing code first** before suggesting alternatives.
- **Never assume** — if something is unclear, ask me rather than guessing.

---

## 2. ✅ Code Quality — Non-Negotiable Standards

- **TypeScript**: Use strict types. Avoid `any`. Prefer interfaces over type aliases for object shapes. Use proper generics.
- **No dead code**: Don't leave commented-out code, unused imports, or unreachable branches.
- **Error handling**: Every async operation must have proper error handling. Never swallow errors silently.
- **Naming**: Use descriptive, meaningful names. No single-letter variables except in short loops (`i`, `j`).
- **DRY principle**: Extract repeated patterns into shared utilities or components. Check if a utility already exists before creating a new one.
- **Preserve existing comments and docstrings** that are unrelated to your code changes.
- **File size limits**: If a file exceeds 300 lines, suggest splitting it into smaller modules.
- **Import order**: Framework imports → Third-party imports → Local imports → Type imports, with blank lines between groups.

---

## 3. 🌍 Web Development — Building Websites

### Design & Aesthetics
- **Premium by default**: Every UI must look polished and professional. No bare-bones MVPs. Use modern design patterns (glassmorphism, gradients, micro-animations).
- **Color palettes**: Use curated, harmonious colors. Avoid generic red/blue/green. Prefer HSL-based palettes.
- **Typography**: Use Google Fonts (Inter, Lato, Playfair Display, Outfit). Never use browser defaults.
- **Responsive design**: Mobile-first approach. Test layouts at 320px, 768px, 1024px, and 1440px breakpoints.
- **Dark mode**: Support dark mode when the project uses it. Respect `prefers-color-scheme`.
- **Animations**: Add subtle hover effects, transitions (200-300ms), and micro-animations for better UX. Use `prefers-reduced-motion` for accessibility.

### Next.js Specific
- **Read `node_modules/next/dist/docs/`** before writing Next.js code — APIs may differ from training data.
- **Server Components by default**: Only use `'use client'` when you need interactivity, hooks, or browser APIs.
- **Metadata**: Always add proper `<title>`, meta descriptions, and Open Graph tags.
- **Image optimization**: Use `next/image` with proper `width`, `height`, and `alt` attributes.
- **Loading states**: Add `loading.tsx` for route segments. Use Suspense boundaries.
- **Error boundaries**: Add `error.tsx` for graceful error handling.

### Supabase Specific
- **RLS policies**: Always verify Row Level Security is enabled on tables.
- **Use service role key** only in server-side code, never expose in client.
- **Typed queries**: Use generated types from Supabase for type-safe queries.
- **Handle auth state**: Always handle loading, authenticated, and unauthenticated states.

### Performance
- Lazy-load below-the-fold content and heavy components.
- Minimize client-side JavaScript. Prefer server-side rendering.
- Use proper caching headers and ISR where applicable.
- Optimize images — compress, use WebP/AVIF, set proper dimensions.

---

## 4. 🐛 Bug Fixing — Systematic Debugging

- **Reproduce first**: Always understand and reproduce the bug before attempting a fix.
- **Root cause analysis**: Don't just fix the symptom. Find and fix the root cause.
- **Minimal changes**: Fix only what's broken. Don't refactor unrelated code during bug fixes.
- **Test the fix**: Verify the fix works and doesn't introduce new issues.
- **Use `/gsd-debug`** for complex bugs that need systematic, persistent debugging across context resets.
- **Use Code Review Graph** (`detect_changes_tool`) to check impact radius — what else might break when you change something.
- **Check git history**: Use `git log` and `git blame` to understand when and why the code was written that way before changing it.

---

## 5. 🎨 UI/UX Design — Visual Excellence

- **Follow UI/UX Pro Max rules** from knowledge items when creating or reviewing any UI code.
- **Touch targets**: Minimum 44×44px for interactive elements on mobile.
- **Contrast ratios**: WCAG AA minimum (4.5:1 for text, 3:1 for large text).
- **Focus states**: All interactive elements must have visible focus indicators.
- **Loading states**: Show skeletons or spinners during data fetching. Never show blank screens.
- **Empty states**: Design meaningful empty states with calls to action.
- **Error states**: Show user-friendly error messages with recovery actions.
- **No placeholder images**: Use `generate_image` tool to create actual assets when needed.
- **Consistent spacing**: Use 4px/8px rhythm grid. Avoid arbitrary pixel values.

---

## 6. 🔒 Security — Always On

- **Never hardcode secrets**: API keys, passwords, tokens must be in `.env` files.
- **Validate all inputs**: Server-side validation is mandatory. Client-side validation is supplementary.
- **Sanitize outputs**: Prevent XSS by properly escaping user-generated content.
- **CORS**: Configure appropriately. Never use `*` in production.
- **Auth checks**: Verify authentication AND authorization on every protected route/API.
- **SQL injection**: Use parameterized queries. Never concatenate user input into SQL.
- **Dependency awareness**: Flag known vulnerabilities when suggesting packages.
- **Use `/gsd-secure-phase`** for security audits on completed features.

---

## 7. 📦 Git & Deployment

- **Commit messages**: Use conventional commits (`feat:`, `fix:`, `chore:`, `docs:`, `refactor:`).
- **Small commits**: One logical change per commit. Don't bundle unrelated changes.
- **Never commit**: `.env` files, `node_modules/`, build artifacts, or OS-specific files.
- **Branch naming**: `feature/description`, `fix/description`, `chore/description`.
- **Pre-deploy checks**: Build locally, check for TypeScript errors, verify environment variables.
- **Use `/gsd-ship`** for PR preparation and `/gsd-code-review`** for pre-merge reviews.

---

## 8. 🏗️ GSD Workflow — Project Management

When working on structured projects with `.planning/` directories:

- **Use `/gsd-progress`** to check current project state before starting work.
- **Use `/gsd-next`** to find the logical next step in the workflow.
- **Use `/gsd-explore`** for brainstorming before committing to plans.
- **Use `/gsd-discuss-phase`** before planning a phase — gather context first.
- **Use `/gsd-plan-phase`** for detailed phase planning with verification.
- **Use `/gsd-execute-phase`** for structured execution with wave-based parallelization.
- **Use `/gsd-code-review`** after implementing features.
- **Use `/gsd-verify-work`** for UAT validation.
- **Use `/gsd-fast`** for trivial tasks that don't need full planning overhead.
- **Use `/gsd-quick`** for small tasks that still need atomic commits and tracking.
- **Use `/gsd-debug`** for persistent debugging across context resets.
- **Use `/gsd-scan`** for rapid codebase assessment on new or unfamiliar projects.
- **Use `/gsd-audit-fix`** for autonomous find-issues → fix → test → commit pipeline.

---

## 9. 📊 Code Review Graph — Codebase Intelligence

Leverage the Code Review Graph MCP server for deeper code analysis:

- **Before major changes**: Run `build_or_update_graph_tool` to index the codebase, then `detect_changes_tool` to understand the blast radius.
- **Before refactoring**: Use `get_impact_radius_tool` to see what functions, classes, and files are affected.
- **Find dead code**: Use `refactor_tool(mode="dead_code")` to identify unreferenced functions.
- **Understand architecture**: Use `get_architecture_overview_tool` and `list_communities_tool` to see high-level structure.
- **Check test coverage**: Use `query_graph_tool(pattern="tests_for")` to verify tests exist for changed code.
- **Search semantically**: Use `semantic_search_nodes_tool` to find relevant code by meaning, not just name.
- **Use `get_affected_flows_tool`** to understand which user-facing flows are impacted by a change.
- **Use `/gsd-graphify`** to build, query, and visualize the project knowledge graph.

---

## 10. 💬 Communication — How to Interact

- **Be concise**: Give summaries, not essays. Provide details only when asked.
- **Ask before assuming**: If a request is ambiguous, ask for clarification.
- **Show, don't tell**: Demonstrate with code, not long explanations.
- **Suggest improvements**: If you see a better approach, mention it — but implement what was asked first.
- **Progress updates**: For long tasks, provide brief status updates.
- **Highlight risks**: If a change could break something, say so before making it.
- **Use artifacts** for reports, analysis, and structured documentation — not for simple answers.
- **Language**: Default to English. Match the user's language when they communicate in another language.

---

## 11. 📋 Task Execution Checklist

Before starting ANY task:
1. ☐ Check Knowledge Items for relevant patterns
2. ☐ Check conversation history for prior related work
3. ☐ Understand the existing codebase structure
4. ☐ Identify affected files and potential side effects

Before submitting ANY code change:
1. ☐ Code compiles without errors
2. ☐ No unused imports or dead code introduced
3. ☐ Error handling is in place
4. ☐ UI is responsive and accessible
5. ☐ Security considerations addressed
6. ☐ Existing tests still pass
7. ☐ Changes are minimal and focused

---

> [!TIP]
> **How to apply**: Copy the sections you want into Antigravity's **Settings → User Rules** field. These rules will then apply to every project you work on.
