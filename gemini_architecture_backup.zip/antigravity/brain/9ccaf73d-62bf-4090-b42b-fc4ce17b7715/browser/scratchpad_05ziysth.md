# Agent Skills Collection Task

## Checklist
- [x] Find `documentation-writer` SKILL.md
- [/] Find `resume-tailoring` SKILL.md
- [ ] Find `conventional-commits` SKILL.md
- [ ] Find `job-extraction-expert` SKILL.md
- [ ] Find `refactor-expert` SKILL.md
- [ ] Find `supabase-mcp-manager` SKILL.md

## Notes
- `documentation-writer`: Found at `https://github.com/github/awesome-copilot/tree/main/skills/documentation-writer`.
- `resume-tailoring`: Currently searching on skills.sh.
