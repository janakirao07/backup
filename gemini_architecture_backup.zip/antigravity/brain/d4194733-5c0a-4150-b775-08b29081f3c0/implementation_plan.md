# Implementation Plan: Fix MCP Error & 'code-review-graph' Integration

The application's AI integration is broken because the `code-review-graph` binary is not in the system's `%PATH%`. This causes terminal errors and prevents the knowledge graph from building. Additionally, several project rules files (`.cursorrules`, `CLAUDE.md`, etc.) have become redundant copies of the tool's documentation.

## User Review Required

> [!IMPORTANT]
> - I will be switching all references to `code-review-graph` to their **absolute path** on your system. This ensures the tool works regardless of your global PATH settings.
> - I will restore the project-specific rules in `.cursorrules` and `CLAUDE.md` if I can find their original content, or I will clean them up to be more concise.

## Proposed Changes

### [Component: Environment & Tooling]

#### [MODIFY] [.mcp.json](file:///c:/Users/janak/job-tracker-app/.mcp.json)
- Replace `"command": "code-review-graph"` with the absolute path to the executable.

#### [MODIFY] [settings.json](file:///c:/Users/janak/job-tracker-app/.claude/settings.json)
- Update all `hooks` (PostToolUse, SessionStart, PreCommit) to use the absolute path for the `code-review-graph` command.

#### [MODIFY] [.cursorrules](file:///c:/Users/janak/job-tracker-app/.cursorrules) / [CLAUDE.md](file:///c:/Users/janak/job-tracker-app/CLAUDE.md)
- Ensure these files contain valid project rules, not just tool documentation.

---

## Verification Plan

### Automated Tests
- Run `code-review-graph status` using the absolute path to verify it works.
- Check the Windsurf/Cursor terminal for the absence of "executable file not found" errors.

---

## Open Questions
- Do you have a preference for where the `code-review-graph` data is stored? (Currently `.code-review-graph/`).
- Do you want me to keep the `CLAUDE.md` as-is, or restore it to a general project summary?
