# Indian E-commerce Optimization

Best practices for UPI payment reliability, Razorpay webhook hardening, and GST-compliant invoicing.

## 💳 UPI Payment Success Rates

- **Always prefer intent flow** over collect flow for UPI. Intent flow (deep-linking into the user's UPI app) has 15–20% higher success rates on mobile because it avoids the "enter VPA and wait" friction.
- **Offer fallback ordering**: UPI Intent → UPI QR → Net Banking → Cards. Never show UPI as the only option.
- **Polling > Webhooks for UPI status**: UPI payment status can take up to 5 minutes to confirm. Implement a poller (GET /v1/payments/:id) every 10s for up to 5 attempts before marking as "pending" — never "failed."
- **UPI transaction limits**: ₹1 lakh per transaction for most banks. For high-ticket garment orders (designer wear, bulk), surface Net Banking prominently or allow split payment UX.
- **Time-of-day sensitivity**: UPI success rates dip between 1–4 AM due to NPCI maintenance windows. If your order confirmation rate drops overnight, this is the cause — not a bug.

## 🛡️ Razorpay Webhook Hardening

- **Always verify signature before processing**:
```javascript
const crypto = require('crypto');

function verifyRazorpayWebhook(body, signature, secret) {
  const expectedSig = crypto
    .createHmac('sha256', secret)
    .update(JSON.stringify(body))
    .digest('hex');
  return crypto.timingSafeEqual(
    Buffer.from(expectedSig),
    Buffer.from(signature)
  );
}
```
- **Idempotency is non-negotiable**: Store `payment_id` in a `processed_webhooks` table and short-circuit duplicates.
- **Events to handle**: `payment.captured`, `payment.failed`, `refund.created`, `refund.processed`, `order.paid`. Wait for `payment.captured`.
- **Webhook secret rotation**: Store in environment variables.
- **Return 200 OK fast**: Enqueue heavy processing (email, inventory) to a job queue and respond immediately to Razorpay.

## 📜 GST-Ready Invoice Patterns

- **Tax split logic**:
```javascript
function computeGST(sellerState, buyerState, baseAmount, gstRate) {
  const tax = baseAmount * (gstRate / 100);
  if (sellerState === buyerState) {
    return { cgst: tax / 2, sgst: tax / 2, igst: 0 };
  }
  return { cgst: 0, sgst: 0, igst: tax };
}
```
- **GST rates for garments**: 5% for items ≤ ₹1,000 MRP; 12% for items > ₹1,000 MRP. Applied per line item.
- **Invoice number format**: Sequential, financial-year-scoped (e.g., BSR/2025-26/00142). Reset every April 1st.
- **Retention**: Store invoices for 8 years (GST audit period).
