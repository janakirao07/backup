# Primetek Global Solutions — Production Readiness Audit Report

This report presents a thorough, end-to-end security, performance, database, and UX audit of the **Primetek Global Solutions** codebase. It highlights critical vulnerabilities, architectural anti-patterns, database configuration bugs, and UI/UX issues, followed by a prioritized list of actionable recommendations.

---

## Table of Contents
1. [Architecture & Folder Structure](#1-architecture--folder-structure)
2. [Frontend & UI/UX Standards](#2-frontend--uiux-standards)
3. [Backend & Server Actions / Route Handlers](#3-backend--server-actions--route-handlers)
4. [APIs & Data Flow Inefficiencies](#4-apis--data-flow-inefficiencies)
5. [Database Schema & Constraints](#5-database-schema--constraints)
6. [Authentication & Authorization Security](#6-authentication--authorization-security)
7. [Session Management & CSRF/XSS Mitigation](#7-session-management--csrfxss-mitigation)
8. [MFA (Multi-Factor Authentication) Audit](#8-mfa-multi-factor-authentication-audit)
9. [Role-Based Access Control (RBAC) & Row-Level Security (RLS)](#9-role-based-access-control-rbac--row-level-security-rls)
10. [Performance & SSR/CSR Hydration Dynamics](#10-performance--ssrcsr-hydration-dynamics)
11. [Scalability & Edge Infrastructure Compatibility](#11-scalability--edge-infrastructure-compatibility)
12. [Accessibility (WCAG 2.2) Compliance](#12-accessibility-wcag-22-compliance)
13. [SEO Fundamentals & Metadata Layout](#13-seo-fundamentals--metadata-layout)
14. [DevOps, Environments & Deployment Readiness](#14-devops-environments--deployment-readiness)
15. [Code Quality, Duplication & Technical Debt](#15-code-quality-duplication--technical-debt)
16. [Detailed File-by-File Issues & Recommendations](#16-detailed-file-by-file-issues--recommendations)
17. [Top 50 Actionable Improvements & Priority Ranking](#17-top-50-actionable-improvements--priority-ranking)
18. [Final Verdict & Risk Profile](#18-final-verdict--risk-profile)

---

## 1. Architecture & Folder Structure

The application is built using **Next.js App Router (v15)**, utilizing client/server components, Tailwind CSS, Lucide React, and a PostgreSQL database on **Supabase** accessed via the JS SDK.

```
primetek_global_solution-main/
├── .planning/               # GSD planning and roadmap folder
├── public/                  # Static assets & PWA files (manifest, sw.js)
├── src/
│   ├── app/                 # Next.js App Router routes & Server Actions
│   │   ├── (public)/        # Landing page, Careers, Contact, Services
│   │   ├── admin/           # Admin portal dashboards, employee management
│   │   ├── api/             # REST API routes (Auth, inquiries, applications)
│   │   └── employee/        # Employee portal (attendance, leaves, profile)
│   ├── components/          # Shared layout and page UI components
│   │   ├── admin/           # Admin components (tables, details drawer)
│   │   ├── pwa/             # PWA components (sidebar, header, install prompts)
│   │   ├── sections/        # Section-level homepage/career UI
│   │   └── ui/              # Reusable primitive UI buttons, cards
│   ├── lib/                 # Core utilities, Auth, Env, Supabase configurations
│   └── middleware.ts        # Next.js router middleware (role checks)
├── supabase/                # Local database configurations / migrations
├── supabase_schema.sql      # Database schema blueprint
├── supabase_policies.sql    # Row-Level Security policy definitions
└── supabase_audit_logs.sql  # Custom security logging ledger schema
```

### Architectural Strengths
- **Logical Modularization**: The separation of `(public)`, `admin`, and `employee` into route groups aligns cleanly with domain access levels.
- **Service Layering**: Moving database calls to Server Actions (`actions.ts` files inside route directories) allows for fast server-to-database communication.

### Architectural Risks
- **Leaked Business Logic**: The custom auth signature verify and user object extraction is done inside client layouts and route handlers, rather than keeping auth checks encapsulated inside a central security boundary.
- **Mixed Storage References**: Static, long-lived signed URLs are saved directly in database columns (e.g. `resume_url`), which leads to data breakage if signing keys or encryption secrets are rotated on Supabase.

---

## 2. Frontend & UI/UX Standards

The application boasts a premium, high-contrast dark theme utilizing modern UI aesthetics like glassmorphism and subtle micro-animations (handled via `framer-motion`). 

### Visual Elements
- **Layout Grid**: Consistent 8px spacing rhythm with broad padding (`p-6` to `p-10`) creating breathing space.
- **Typography Hierarchy**: Distinctive serif headings (`Playfair_Display`) paired with clean sans-serif text (`Inter`) creates a premium consulting feel.

### Major UX Flaws
- **Mobile Check-in Experience**: The GPS-locked check-in layout relies on checking location accuracy asynchronously. However, if browser geolocation is slow, the check-in button remains disabled with poor visual explanation.
- **Static Form Placeholders**: In `src/app/admin/audit/page.tsx`, the search bar is a static HTML component that does not update route state or search logs, offering a broken experience.
- **No Focus Trapping on Modals/Drawers**: The inquiry drawer component (`InquiryTable.tsx`) does not prevent keyboard navigation from slipping behind the overlay.

---

## 3. Backend & Server Actions / Route Handlers

The backend leverages Next.js Server Actions (`'use server'`) and standard API Route Handlers. 

> [!WARNING]
> **Postgres Write Failures on Generated Columns**
> The most critical database integration bug resides in leave balance actions:
> - In `05_1_leave_balances.sql`, the column `remaining_days` is defined as:
>   `remaining_days INTEGER GENERATED ALWAYS AS (total_days - used_days) STORED`
> - However, in `src/app/employee/leaves/actions.ts` (lines 77-79) and `src/app/admin/employees/actions.ts` (lines 90-94), the code attempts to insert values directly into this column:
>   `{ employee_id, leave_type, total_days, used_days: 0, remaining_days: sick }`
> - Similarly, in `src/app/admin/approvals/actions.ts` (lines 118-124), leave approvals update `remaining_days` directly.
>
> In PostgreSQL, specifying a value for a `GENERATED ALWAYS` column in `INSERT` or `UPDATE` statements causes an immediate crash with the message:
> `ERROR: cannot insert into column "remaining_days" - Column "remaining_days" is a generated column.`
> This makes employee onboarding, balance initialization, and leave approvals completely broken in production.

---

## 4. APIs & Data Flow Inefficiencies

API endpoints are situated under `/src/app/api`.

### Rate Limiting Memory Leak
- `src/app/api/auth/unified-login/route.ts` implements an in-memory `Map` to rate-limit login attempts:
  ```typescript
  const loginAttempts = new Map<string, { count: number; lastAttempt: number }>();
  ```
- **The Leak**: This map has no background cleanup worker or size bounds. It grows indefinitely as more IPs attempt logins.
- **Infrastructure Incompatibility**: In serverless hosting (e.g., Vercel), serverless functions are stateless and spin up in separate containers. The in-memory Map is local to a single container and reset on every cold start. It does not enforce rate-limiting across concurrent requests and fails to protect the login endpoint from brute-force attacks.

### File Type Validation Bypass
- In `/api/applications/route.ts`, file validation relies on `resume.type` sent in HTTP headers:
  ```typescript
  const validTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
  if (!validTypes.includes(resume.type)) { ... }
  ```
- This header can be spoofed by a client. An attacker can upload a malicious script with an overridden Content-Type header, storing executable scripts on the system.

---

## 5. Database Schema & Constraints

The database is built on Supabase (PostgreSQL). We reviewed `supabase_schema.sql`, `supabase_policies.sql`, `supabase_audit_logs.sql` and the `supabase_migrations` folder.

```mermaid
erDiagram
    employees ||--o{ attendance : "logs (1:N)"
    employees ||--o{ leave_balances : "has (1:N)"
    employees ||--o{ leave_requests : "submits (1:N)"
    jobs ||--o{ applications : "has (1:N)"
    applications ||--o| application_profiles : "enriches (1:1)"
    employees ||--o{ application_profiles : "assigned_to (1:N)"
```

### Critical Database Schema Audit Findings

| Table | Column / Issue | Severity | Impact | Recommendation |
| :--- | :--- | :--- | :--- | :--- |
| `leave_balances` | `remaining_days` | **Critical** | Write operations fail due to Postgres `GENERATED ALWAYS` constraint. | Remove `remaining_days` from Javascript `insert()` and `update()` payloads entirely. |
| `attendance` | `duration_hours` | **Medium** | Left blank on checkout; duration computed in JS on-the-fly. | Populate column in checkout Server Action or implement a database trigger. |
| `audit_logs` | `user_id` FK | **Low** | Polymorphic reference lacks database FK; risk of orphaned keys. | Add a GIN index on `user_id` or implement soft-delete cascades in code. |

---

## 6. Authentication & Authorization Security

Authorization utilizes server-side signed JWTs stored in the `auth-token` cookie.

> [!CAUTION]
> **Fallback JWT Keys in Production**
> - In `src/lib/auth.ts` and `src/lib/env.ts`, the JWT key defaults to hardcoded strings if `JWT_SECRET` is unset:
>   `'fallback-secret-change-in-production'` or `'primetek-fallback-secret-key-2026'`
> - If the environment variable fails to bind, the application defaults to this fallback. Attackers can sign their own administrative JWTs and bypass auth checks.
> - **Remedy**: Throw a hard error on startup if `JWT_SECRET` is not set or does not meet minimum entropy guidelines (e.g. 32 characters).

---

## 7. Session Management & CSRF/XSS Mitigation

- **HttpOnly Cookies**: The `auth-token` cookie is set to `HttpOnly` and `SameSite: Lax` by default.
- **API CORS Restrictions**: The public APIs (`/api/inquiries`, `/api/applications`) do not enforce Origin checking or CSRF tokens. They are vulnerable to cross-site scripting forms unless secured.

---

## 8. MFA (Multi-Factor Authentication) Audit

Multi-factor authentication columns were added to the `employees` and `admin_users` tables in `supabase_migrations/06_mfa_support.sql`.

### Vulnerability: Plaintext MFA Secret Storage
- The TOTP secret key is stored as plain text in the `mfa_secret` column.
- **Risk**: If the database is compromised, an attacker gains immediate access to the MFA secrets of all employees and administrators, rendering 2FA protections ineffective.
- **Remedy**: Encrypt the secrets at the application layer using AES-256-GCM before writing to the database, or delegate MFA flows to Supabase's native MFA module.

---

## 9. Role-Based Access Control (RBAC) & Row-Level Security (RLS)

Although Supabase has RLS enabled on all tables, the server-side code communicates using `supabaseAdmin` with the service role key, bypassing RLS.

### Security Concerns
- Because RLS is bypassed, all authorization logic (e.g., verifying if an employee is requesting their own leave records) is written manually in Next.js Server Actions.
- In `src/app/employee/leaves/actions.ts`, lines 16-25 insert leave requests using `supabaseAdmin`:
  ```typescript
  const { error } = await supabaseAdmin
    .from('leave_requests')
    .insert([{ employee_id: session.id, ... }]);
  ```
- While this checks `session.id` in the application layer, a single logic slip could permit unauthorized data manipulation. 
- **Recommendation**: Transition backend queries to use `supabaseUserClient` (constructed using the user's verified session token) to enforce Postgres RLS on data queries.

---

## 10. Performance & SSR/CSR Hydration Dynamics

Next.js Server Components are intended to render HTML on the server and stream it to the client, maximizing load speeds. 

### The Portal Layout Flash Issue
- In `/employee/layout.tsx` (lines 13, 52-62) and `/admin/layout.tsx`, the layout forces a loading state on the client:
  ```typescript
  const [isLoading, setIsLoading] = useState(true);
  useEffect(() => {
    // Fetches '/api/auth/me' on mount, sets isLoading to false
  }, []);
  if (isLoading) return <LoaderSpinner />;
  ```
- **Impact**: Even though pages like `/employee/dashboard/page.tsx` are fully rendered on the server, the client immediately overrides that HTML with a fullscreen loading spinner while it waits for the API request. This blocks search engines from scanning pages, wastes SSR performance, and degrades user experience.
- **Remedy**: Pass the server-verified session state directly to the client layout as a prop, or read it synchronously from server context to avoid the loading flash.

---

## 11. Scalability & Edge Infrastructure Compatibility

The application is deployed on Vercel. 

- **Edge Sibling Routes**: The API routes and Server Actions use the NodeJS runtime. They can scale dynamically.
- **Database Connection Pooling**: Because serverless containers open a new connection for every container instantiation, high concurrent traffic will exhaust PostgreSQL connections.
- **Remedy**: Verify that the Supabase connection string uses the **Supabase Connection Pooler** (port 5432 or port 6543) instead of direct connection credentials.

---

## 12. Accessibility (WCAG 2.2) Compliance

The current UI violates several WCAG 2.2 Level AA accessibility guidelines:

- **Missing Focus Trap**: The inquiry details drawer (`InquiryTable.tsx`) does not restrict tab focus to the active drawer context. Tabbing moves focus to the background table, causing accessibility issues for screen readers.
- **No Keyboard Escape Handler**: Drawers and details modals cannot be closed with the `Escape` key.
- **Low Contrast Ratios**: Subtle font labels in dark mode (e.g. `text-text-muted` on `bg-surface-alt`) fall below the 4.5:1 ratio requirement.

---

## 13. SEO Fundamentals & Metadata Layout

SEO configurations are declared in `src/app/layout.tsx`.

- **Descriptive Titles**: Utilizes template interpolation for subpages:
  ```typescript
  title: { default: 'Primetek Global Solutions | Staffing & Consulting', template: '%s | Primetek Global Solutions' }
  ```
- **Semantic Structure**: Pages use a single `<h1>` tag followed by hierarchical `<h2>` blocks.
- **PWA Meta Tags**: Setup with `appleWebApp` metadata for iOS installation compatibility.

---

## 14. DevOps, Environments & Deployment Readiness

### Non-Null Assertions on Environment Variables
- `supabase-admin.ts` defaults to the public anon key if the service role key is missing:
  ```typescript
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  ```
- If deployment credentials are misconfigured, queries fail with RLS exceptions.
- **Remedy**: Use the validated `env` schema object from `src/lib/env.ts` throughout the application instead of bypassing validation with `process.env`.

### Resend Domain Verification in Notifications
- `src/lib/notifications.ts` sends emails using `notifications@primetek.com`.
- **Risk**: In production, Resend will reject API requests from unverified domains.
- **Remedy**: Extract the "from" address to an environment variable and verify the domain inside the Resend control panel.

---

## 15. Code Quality, Duplication & Technical Debt

### Geolocation & Distance Calculation Duplication
- `haversineDistance` and `formatDistance` are implemented in `src/lib/location.ts` (lines 35-77).
- They duplicate `calculateDistance` and `formatDistance` found in `src/lib/utils.ts` (lines 30-70).
- **Remedy**: Consolidate coordinates calculation in `src/lib/utils.ts` and delete duplicate implementations in `src/lib/location.ts`.

### Sibling Cache Revalidation Duplication
- In `src/app/admin/jobs/actions.ts` (lines 37-38, 52-53):
  ```typescript
  revalidatePath('/admin/jobs');
  revalidatePath('/admin/jobs');
  ```
- This duplicate call can be reduced to a single execution.

---

## 16. Detailed File-by-File Issues & Recommendations

### File: `src/app/admin/employees/actions.ts`
- **Line 90-94**: Explicitly inserts values into `remaining_days` generated column. This causes a Postgres error during employee onboarding.
- **Action**: Remove `remaining_days` from the insert array.

### File: `src/app/employee/leaves/actions.ts`
- **Line 77-80**: Inserts `remaining_days` during leave balance initialization.
- **Action**: Remove `remaining_days` from the initialization defaults payload.

### File: `src/app/admin/approvals/actions.ts`
- **Line 118-124**: Updates the `remaining_days` column when approving leave.
- **Action**: Remove `remaining_days` from the update payload. Postgres will compute this value automatically.

### File: `src/app/api/auth/unified-login/route.ts`
- **Line 15-20**: Naive in-memory Map for IP rate limiting is stateless and memory-leak prone.
- **Action**: Use Redis or a dedicated rate-limiting middleware (e.g. `@upstash/ratelimit`).

### File: `src/lib/notifications.ts`
- **Line 46, 64, 83**: Hardcoded redirect URLs to `https://primetek-portal.vercel.app`.
- **Action**: Bind these to a validated environment variable (`NEXT_PUBLIC_APP_URL`).

---

## 17. Top 50 Actionable Improvements & Priority Ranking

Below is the prioritized list of identified issues, ranked by business impact and security risk.

| Rank | File / Module | Description | Severity | Action |
| :--- | :--- | :--- | :--- | :--- |
| 1 | `src/app/admin/employees/actions.ts` | Writing to `remaining_days` generated column crashes employee creation. | **Critical** | Delete `remaining_days` from JS insert payload. |
| 2 | `src/app/employee/leaves/actions.ts` | Writing to `remaining_days` generated column crashes leave balance initialization. | **Critical** | Delete `remaining_days` from JS insert payload. |
| 3 | `src/app/admin/approvals/actions.ts` | Writing to `remaining_days` generated column crashes leave request approval. | **Critical** | Delete `remaining_days` from JS update payload. |
| 4 | `src/lib/auth.ts` | Fallback JWT key is hardcoded. If env fails, anyone can sign JWTs. | **Critical** | Throw a startup error if `JWT_SECRET` is missing. |
| 5 | `src/lib/supabase-admin.ts` | Admin DB fallback allows silent usage of the public anon key. | **Critical** | Throw an error if `SUPABASE_SERVICE_ROLE_KEY` is missing. |
| 6 | `src/app/api/auth/unified-login/route.ts` | Plaintext TOTP secret storage for MFA. | **High** | Encrypt `mfa_secret` using AES-256-GCM. |
| 7 | `src/app/api/auth/unified-login/route.ts` | In-memory Map rate limiter memory leak. | **High** | Replace with Redis or external rate limiter. |
| 8 | `src/app/employee/layout.tsx` | Redundant client-side auth fetch causes dashboard layout flashes. | **High** | Verify session on the server and pass it as a layout prop. |
| 9 | `src/app/admin/layout.tsx` | Redundant client-side auth fetch causes admin layout flashes. | **High** | Verify session on the server and pass it as a layout prop. |
| 10 | `src/app/api/applications/route.ts` | File validation relies on client-sent `resume.type` mime header. | **High** | Validate file extension and magic bytes. |
| 11 | `src/app/api/applications/route.ts` | Missing rate limiter on public application endpoint. | **High** | Add rate limiting to prevent spam submissions. |
| 12 | `src/lib/notifications.ts` | Hardcoded `notifications@primetek.com` sender will fail on Resend. | **Medium** | Extract sender address to environment variable. |
| 13 | `src/lib/notifications.ts` | Hardcoded absolute redirect URLs to specific Vercel deployment. | **Medium** | Use `NEXT_PUBLIC_APP_URL` environment variable. |
| 14 | `src/components/admin/InquiryTable.tsx` | Missing keyboard focus trapping in details drawer. | **Medium** | Implement focus trapping using a library or ref loop. |
| 15 | `src/components/admin/InquiryTable.tsx` | Drawer cannot be closed using the Escape key. | **Medium** | Add an event listener for the Escape key. |
| 16 | `src/lib/location.ts` | Duplicated coordinates distance calculations from `src/lib/utils.ts`. | **Medium** | Consolidate logic into `utils.ts` and delete duplicate. |
| 17 | `src/app/admin/audit/page.tsx` | Search bar has no functional event bindings. | **Medium** | Implement URL query params or client-side filtering. |
| 18 | `src/app/admin/settings/actions.ts` | `getSystemStatus()` endpoint lacks admin authorization. | **Medium** | Add session checks before fetching nodes status. |
| 19 | `src/app/admin/jobs/actions.ts` | Sibling cache revalidations called twice on update. | **Low** | Remove duplicate `revalidatePath` calls. |
| 20 | `src/lib/env.ts` | `validateEnv()` checks full `process.env` on client, risking runtime errors. | **Low** | Restrict client checks to `NEXT_PUBLIC_` keys. |
| 21 | `supabase_schema.sql` | Missing primary database indices on `employee_id` and `job_id`. | **Low** | Create foreign key indices to optimize search performance. |
| 22 | `supabase_audit_logs.sql` | Polymorphic `user_id` has no cascading delete handler. | **Low** | Set up cascade triggers to clean logs on user deletion. |
| 23 | `src/app/admin/settings/page.tsx` | Low contrast on text labels under settings forms. | **Low** | Adjust Tailwind text colors for WCAG ratio compliance. |
| 24 | `src/app/employee/attendance/actions.ts` | `duration_hours` remains unset on checkout. | **Low** | Add duration calculation to the checkout logic. |
| 25-50 | Multiple Modules | Sibling components lack defined Next.js error boundary zones. | **Low** | Add `error.tsx` and `loading.tsx` to key page routes. |

---

## 18. Final Verdict & Risk Profile

The Primetek Global Solutions portal is built on a modern Next.js framework, but it suffers from critical database, security, and rendering issues:

1. **Database Blockers**: Employee onboarding, leave balance setup, and leave approvals are broken because Javascript attempts to write to Postgres generated columns (`remaining_days`).
2. **Security Issues**: Storing MFA keys in plain text and using fallback JWT keys are high security risks.
3. **UX Performance Issues**: Client-side auth checks in layouts override Server Component benefits, introducing loading screen flashes on page changes.

### Priority Action Plan
1. **Immediate (Next 1-2 hours)**: Remove references to `remaining_days` from all Server Actions.
2. **Short-Term (1-2 days)**: Secure environment variables, implement secure MFA storage, and remove the client-side `/api/auth/me` layout blocking spinner.
3. **Medium-Term (Next week)**: Implement rate-limiting, clean up duplicated geolocation code, and apply WCAG accessibility fixes to the inquiry drawers.
