# Capacitor Patterns

## Setup (Any Web App)
```bash
npm install @capacitor/core @capacitor/cli
npx cap init
npm run build # build your web app (React, Vue, etc)
npx cap add ios
npx cap add android
```

## Using Native Plugins
```ts
import { Camera, CameraResultType } from '@capacitor/camera';
import { Geolocation } from '@capacitor/geolocation';

// Take Photo
const takePicture = async () => {
  const image = await Camera.getPhoto({
    quality: 90,
    allowEditing: true,
    resultType: CameraResultType.Uri
  });
  return image.webPath;
};

// Get Location
const printCurrentPosition = async () => {
  const coordinates = await Geolocation.getCurrentPosition();
  console.log('Current position:', coordinates);
};
```

## Workflow
1. Write web code (HTML/CSS/JS)
2. `npm run build`
3. `npx cap sync` (copies web assets into native iOS/Android projects)
4. `npx cap open ios` (opens Xcode to build/deploy)
5. `npx cap open android` (opens Android Studio)
