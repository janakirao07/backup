# Drizzle ORM

## Schema
```ts
import { pgTable, text, serial } from 'drizzle-orm/pg-core';
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  name: text('name'),
});
```

## Queries
```ts
import { db } from './db';
import { eq } from 'drizzle-orm';
const result = await db.select().from(users).where(eq(users.name, 'Alice'));
await db.insert(users).values({ name: 'Bob' });
```