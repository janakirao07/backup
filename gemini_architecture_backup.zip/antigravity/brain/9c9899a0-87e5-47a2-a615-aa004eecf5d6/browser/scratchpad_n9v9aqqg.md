# Tasks
- [x] Open the resume maker URL. (Used absolute path without file:// prefix as workaround)
- [x] Enter user details. (Data was already present and matches the request)
- [x] Verify name and contact info alignment. (Confirmed that contact info is slightly lowered and aligned with the Name)
- [x] Take a screenshot for confirmation.
