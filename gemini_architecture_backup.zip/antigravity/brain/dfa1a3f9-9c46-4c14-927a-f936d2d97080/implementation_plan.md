# Resolving Gemini Model ID and API Version Conflict

The system is returning a 404 error because `gemini-3.1-flash-lite` is not found on the `v1` API endpoint. This indicates either a typo in the model ID (which was previously hardcoded at the user's request) or that the model is restricted to the `v1beta` endpoint.

To resolve this and prevent future hardcoding issues, I will implement a flexible model configuration system.

## Proposed Changes

### [Component] Settings Dashboard (`app.js`)

I will update the "AI Provider Configuration" section to include a model selector.

#### [MODIFY] [app.js](file:///c:/Users/janak/job-tracker-app/src/scripts/app.js)
- Add a `<select>` or `<input>` field for the **Gemini Model ID**.
- Default it to `gemini-1.5-flash` (stable) but include `gemini-3.1-flash-lite` as an option if the user wants to keep trying it.
- Ensure the model ID is saved to `chrome.storage.local` alongside the API key.

### [Component] Content Script (`content.js`)

I will refactor the AI calling logic to be dynamic.

#### [MODIFY] [content.js](file:///c:/Users/janak/job-tracker-app/src/scripts/content.js)
- **`callGeminiBlaze`**:
  - Instead of `const model = "gemini-3.1-flash-lite";`, fetch the model from `chrome.storage.local.get('rjd_gemini_model')`.
  - Robustify the endpoint logic:
    1. Try `v1/models/${model}`.
    2. If 404, try `v1beta/models/${model}`.
    3. If still fails, try a fallback stable model like `gemini-1.5-flash` or alert the user.
- **`renderSettings`**:
  - Update the sidebar settings UI to also include the model selector for quick parity with the dashboard.

---

## Verification Plan

### Automated/Manual Tests
- **Settings Sync**: Change model in `app.js`, verify `content.js` picks it up.
- **Error Handling**: Use an invalid model ID and verify the "Not Found" error is caught and displayed gracefully with a suggestion to use a stable model.
- **Endpoint Test**: Verify if `v1beta` works for the `3.1` model if it exists in that namespace.
