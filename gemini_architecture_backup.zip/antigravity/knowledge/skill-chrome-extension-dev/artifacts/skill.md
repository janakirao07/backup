---
name: chrome-extension-dev
description: Chrome extension development best practices using Manifest V3. Use when building, debugging, or updating Chrome extensions, content scripts, service workers, or extension APIs.
---

# Chrome Extension Development (Manifest V3)

## Project Structure
```
extension/
├── manifest.json          # Extension config (MV3)
├── service-worker.js      # Background script (replaces background.js)
├── content.js             # Injected into web pages
├── popup/
│   ├── popup.html
│   ├── popup.js
│   └── popup.css
├── options/
│   ├── options.html
│   └── options.js
├── icons/
│   ├── icon-16.png
│   ├── icon-48.png
│   └── icon-128.png
└── utils/
    └── storage.js
```

## Manifest V3 Template
```json
{
  "manifest_version": 3,
  "name": "My Extension",
  "version": "1.0.0",
  "description": "What it does",
  "permissions": ["storage", "activeTab", "tabs"],
  "host_permissions": ["https://*.example.com/*"],
  "action": {
    "default_popup": "popup/popup.html",
    "default_icon": { "16": "icons/icon-16.png", "48": "icons/icon-48.png", "128": "icons/icon-128.png" }
  },
  "background": {
    "service_worker": "service-worker.js",
    "type": "module"
  },
  "content_scripts": [{
    "matches": ["https://*.example.com/*"],
    "js": ["content.js"],
    "css": ["content.css"],
    "run_at": "document_idle"
  }],
  "icons": { "16": "icons/icon-16.png", "48": "icons/icon-48.png", "128": "icons/icon-128.png" }
}
```

## Communication Patterns

### Popup ↔ Service Worker
```javascript
// Popup → Service Worker
chrome.runtime.sendMessage({ type: 'EXTRACT_DATA' }, (response) => {
  console.log(response);
});

// Service Worker — listen
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'EXTRACT_DATA') {
    sendResponse({ data: 'result' });
  }
  return true; // Keep channel open for async
});
```

### Content Script ↔ Service Worker
```javascript
// Content → Service Worker
chrome.runtime.sendMessage({ type: 'PAGE_DATA', payload: data });

// Service Worker → Content Script
chrome.tabs.sendMessage(tabId, { type: 'HIGHLIGHT', selector: '.target' });
```

## Storage Best Practices
```javascript
// Use chrome.storage.local (persists) or chrome.storage.sync (syncs across devices)
// NEVER use localStorage in service workers

// Save
await chrome.storage.local.set({ key: value });

// Read
const result = await chrome.storage.local.get(['key']);
const value = result.key;

// Listen for changes
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.key) {
    console.log('Old:', changes.key.oldValue);
    console.log('New:', changes.key.newValue);
  }
});
```

## Service Worker Lifecycle (MV3)
- Service workers are **ephemeral** — they terminate after ~30 seconds of inactivity
- Do NOT store state in global variables — use `chrome.storage`
- Use `chrome.alarms` instead of `setInterval`
```javascript
// ❌ Dies when worker terminates
let counter = 0;

// ✅ Persists across worker restarts
chrome.storage.local.get('counter', ({ counter }) => { /* use it */ });
```

## Content Script DOM Interaction
```javascript
// Wait for element to exist
function waitForElement(selector, timeout = 5000) {
  return new Promise((resolve, reject) => {
    const el = document.querySelector(selector);
    if (el) return resolve(el);
    const observer = new MutationObserver((_, obs) => {
      const el = document.querySelector(selector);
      if (el) { obs.disconnect(); resolve(el); }
    });
    observer.observe(document.body, { childList: true, subtree: true });
    setTimeout(() => { observer.disconnect(); reject(new Error('Timeout')); }, timeout);
  });
}
```

## Rate Limiting API Calls
```javascript
class RateLimiter {
  constructor(maxCalls, windowMs) {
    this.maxCalls = maxCalls;
    this.windowMs = windowMs;
    this.calls = [];
  }
  async throttle() {
    const now = Date.now();
    this.calls = this.calls.filter(t => now - t < this.windowMs);
    if (this.calls.length >= this.maxCalls) {
      const wait = this.windowMs - (now - this.calls[0]);
      await new Promise(r => setTimeout(r, wait));
    }
    this.calls.push(Date.now());
  }
}
```

## Debugging
- `chrome://extensions` → Enable Developer Mode
- Click "Service Worker" link to open DevTools for background
- Right-click popup → Inspect to debug popup
- Content scripts appear in page DevTools under Sources → Content Scripts

## Publishing Checklist
- [ ] All permissions are justified (minimal required)
- [ ] Icons at 16, 48, 128px
- [ ] Description under 132 characters for store listing
- [ ] Screenshots at 1280x800 or 640x400
- [ ] Privacy policy if using host_permissions
- [ ] Test on Chrome stable, beta
- [ ] Version bumped in manifest.json
