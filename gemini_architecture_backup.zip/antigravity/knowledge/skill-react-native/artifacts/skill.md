# React Native Best Practices

## Project Setup (Expo — Recommended)
```bash
npx create-expo-app@latest myapp --template blank-typescript
cd myapp && npx expo start
```

## Navigation (Expo Router)
```tsx
// app/_layout.tsx
import { Stack } from 'expo-router';

export default function Layout() {
  return (
    <Stack screenOptions={{
      headerStyle: { backgroundColor: '#1a1a2e' },
      headerTintColor: '#fff',
      headerTitleStyle: { fontWeight: 'bold' },
    }}>
      <Stack.Screen name="index" options={{ title: 'Home' }} />
      <Stack.Screen name="details/[id]" options={{ title: 'Details' }} />
    </Stack>
  );
}

// app/index.tsx
import { Link } from 'expo-router';
import { View, Text, Pressable, StyleSheet } from 'react-native';

export default function Home() {
  return (
    <View style={styles.container}>
      <Link href="/details/123" asChild>
        <Pressable style={styles.button}>
          <Text style={styles.buttonText}>Go to Details</Text>
        </Pressable>
      </Link>
    </View>
  );
}
```

## Styling
```tsx
import { StyleSheet, Platform } from 'react-native';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  card: {
    borderRadius: 12,
    padding: 16,
    backgroundColor: '#f8f9fa',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
      },
      android: {
        elevation: 4,
      },
    }),
  },
  text: {
    fontSize: 16,
    color: '#333',
    fontWeight: '600',
  },
});
```

## FlatList (Performant Lists)
```tsx
import { FlatList } from 'react-native';

<FlatList
  data={items}
  keyExtractor={(item) => item.id}
  renderItem={({ item }) => <ItemCard item={item} />}
  initialNumToRender={10}
  maxToRenderPerBatch={5}
  windowSize={5}
  removeClippedSubviews={true}
  getItemLayout={(data, index) => ({
    length: ITEM_HEIGHT,
    offset: ITEM_HEIGHT * index,
    index,
  })}
/>
```

## State Management
```tsx
// Use React Context + useReducer for simple state
// Use Zustand for complex state (same as web!)
import { create } from 'zustand';

const useStore = create((set) => ({
  user: null,
  setUser: (user) => set({ user }),
  logout: () => set({ user: null }),
}));
```

## Performance Rules
- Use `React.memo()` for list items
- Use `useCallback` for event handlers passed as props
- Avoid inline styles — use `StyleSheet.create()`
- Use `FlatList` not `ScrollView` for long lists
- Minimize re-renders with proper state structure
- Use `react-native-reanimated` for 60fps animations
- Images: use `expo-image` (cached, fast) not `<Image>`

## Platform-Specific Code
```tsx
import { Platform } from 'react-native';

const paddingTop = Platform.OS === 'ios' ? 44 : 0;

// Or use Platform.select
const styles = Platform.select({
  ios: { fontFamily: 'San Francisco' },
  android: { fontFamily: 'Roboto' },
  default: { fontFamily: 'System' },
});

// Or use file extensions
// Button.ios.tsx / Button.android.tsx
```

## Common Pitfalls
- Don't use `flex: 1` without parent having defined height
- Don't use `position: fixed` — use `position: absolute`
- Don't use CSS Grid — use Flexbox only
- Avoid heavy computation on JS thread — use `InteractionManager.runAfterInteractions`
- Test on real devices, not just simulators
