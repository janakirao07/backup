# Nx Workspace

## Commands
```bash
npx create-nx-workspace@latest myorg
npx nx generate @nx/react:app myapp
npx nx serve myapp

# Run only what changed
npx nx affected -t build test
```
## Boundary Rules
Use tags in `project.json` and Enforce Module Boundaries eslint rule to prevent bad imports (e.g. UI depending on Feature).