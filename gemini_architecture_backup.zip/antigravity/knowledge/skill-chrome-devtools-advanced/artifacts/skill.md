# Chrome DevTools

## Performance Tab
- Look for long tasks (red triangle)
- Check "Bottom-Up" to find exact functions causing lag
## Memory Tab
- Take heap snapshots, filter by "Detached" to find detached DOM nodes (leaks).
## Network Tab
- Right click -> "Override content" to mock API responses locally.