# Phase 3: Employee HR & Attendance — PLAN

**Phase**: 3 of 3 (Final) | **Depends on**: Phase 2 ✅ | **Requirements**: ADM-05, ADM-06, EMP-01–05

## ✅ Success Criteria
1. Employee can **login** to their dedicated portal
2. Employee can **check-in/out** with GPS location validation
3. Admin can **manage employee records** and **export attendance** logs

---

## Plan 03-01: Employee Portal Core

### 03-01-A: Employee Auth
| File | Purpose |
|------|---------|
| `src/app/api/auth/employee-login/route.ts` | Employee-specific login endpoint |
| `src/app/employee/login/page.tsx` | Employee login page |
| `src/components/employee/EmployeeLoginForm.tsx` | Login form component |
| `src/middleware.ts` | Protect `/employee` routes, verify `role === 'employee'` |

### 03-01-B: Employee Dashboard & Layout
| File | Purpose |
|------|---------|
| `src/app/employee/(portal)/layout.tsx` | Portal layout with sidebar |
| `src/app/employee/(portal)/page.tsx` | Dashboard: today's status, monthly summary, quick check-in |
| `src/components/employee/EmployeeSidebar.tsx` | Nav: Dashboard, Attendance, Profile, Logout |

### 03-01-C: Profile Management
| File | Purpose |
|------|---------|
| `src/app/employee/(portal)/profile/page.tsx` | Profile edit page |
| `src/components/employee/ProfileForm.tsx` | Name, email, phone, photo upload |
| `src/app/api/employee/profile/route.ts` | `PATCH` profile update |

---

## Plan 03-02: Attendance Tracking

### 03-02-A: GPS Location Service
| File | Purpose |
|------|---------|
| `src/lib/location.ts` | `getCurrentPosition()`, `isWithinRadius()` (Haversine), office config |
| `src/components/employee/LocationStatus.tsx` | GPS status indicator + distance display |

### 03-02-B: Check-in/out Flow
| File | Purpose |
|------|---------|
| `src/app/employee/(portal)/attendance/page.tsx` | Main attendance page |
| `src/components/employee/AttendancePanel.tsx` | Big check-in/out button, live clock, GPS validation, duration timer |
| `src/app/api/employee/attendance/route.ts` | `POST` check-in/out, `GET` history |

### 03-02-C: History & Calendar
| File | Purpose |
|------|---------|
| `src/components/employee/AttendanceCalendar.tsx` | Monthly grid: green/red/yellow/gray days |
| `src/components/employee/AttendanceHistory.tsx` | Table view with date range filter |

---

## Plan 03-03: Admin Employee & Attendance Management

### 03-03-A: Employee CRUD
| File | Purpose |
|------|---------|
| `src/app/admin/(dashboard)/employees/page.tsx` | Employee table with search/filter |
| `src/app/admin/(dashboard)/employees/new/page.tsx` | Add employee form |
| `src/components/admin/EmployeeForm.tsx` | Shared employee form component |
| `src/app/api/admin/employees/route.ts` | `POST` create, `GET` list |
| `src/app/api/admin/employees/[id]/route.ts` | `PATCH` update |

### 03-03-B: Attendance Dashboard & Export
| File | Purpose |
|------|---------|
| `src/app/admin/(dashboard)/attendance/page.tsx` | Attendance logs with filters |
| `src/components/admin/AttendanceTable.tsx` | Filterable table + CSV export |
| `src/app/api/admin/attendance/route.ts` | `GET` attendance with filters |

---

## Impact Summary

| Category | Count |
|----------|-------|
| New files | ~25 |
| Modified files | ~5 (middleware, demo-data, validations, sidebar, dashboard) |
| New API routes | 7 |
| New pages | 9 (6 employee + 3 admin) |

## Technical Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Employee auth | Separate JWT, `role='employee'` | Reuses jose infra, clean role separation |
| GPS | Browser Geolocation API | No dependency, no API key |
| Distance | Haversine formula | Standard, accurate for short distances |
| Map preview | OpenStreetMap static tile | Free, no key required |
| Office location | Configurable constants | Multi-office support later |
| Anti-spoofing | Server-side GPS + timestamp validation | Prevents manual coordinate injection |
| Calendar | Custom CSS grid | Matches design system, no extra lib |

---

> [!IMPORTANT]
> **Ready to execute?** Say `yes` to start building Phase 3.
> Want changes? Let me know what to adjust.
