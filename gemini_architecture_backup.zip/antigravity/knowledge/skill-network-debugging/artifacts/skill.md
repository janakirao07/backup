# Network Debugging

## CORS Issues
- Preflight `OPTIONS` request must return `204` with `Access-Control-Allow-Origin: *` (or specific origin) and `Access-Control-Allow-Headers`.

## Debugging Tools
- **curl**: `curl -v http://api.com` for verbose headers.
- **HAR Files**: Export from Chrome Network tab -> Import elsewhere to inspect offline.
- **Proxyman**: Inspect mobile app traffic via Man-in-the-Middle SSL.