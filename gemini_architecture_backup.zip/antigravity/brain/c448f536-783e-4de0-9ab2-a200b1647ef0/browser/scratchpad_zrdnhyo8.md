# PWA Manifest Investigation Scratchpad

## Checklist
- [/] Initialize scratchpad
- [ ] Navigate to employee login and check manifest link
- [ ] Navigate to admin login and check manifest link
- [ ] Investigate findings

## Findings
- Employee Login Manifest: Pending
- Admin Login Manifest: Pending
