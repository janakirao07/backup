# Task Overview
Investigate why the Job Application Tracker dashboard is not showing data and fix the Gemini API error.

## Checklist
- [ ] Find and open the dashboard URL.
- [ ] Check for JavaScript errors in the console.
- [ ] Inspect DOM for `page-content` visibility.
- [ ] Check if `.main` has `full-page` class.
- [ ] Investigate Gemini 1.5 Flash "not found" error.
- [ ] Report findings and visibility state of items.

## Findings
- Tried `https://janakirao4701.github.io/job-tracker-app/` but it gave a 404.
- Found a potential major bug in `scripts/app.js`: the code uses both `apps` and `applications` as global variables for the application list.
  - `renderDashboard` specifically uses `applications`: `const apps = [...applications];`.
  - Most other functions, including `renderApplications` and state updates, use `apps`.
  - In `showApp`, `refreshData()` is called which sets `applications`, but `loadApps()` is also called later which sets `apps`.
  - If they are out of sync, the dashboard and list will show different data or no data.
  - The Gemini error `models/gemini-1.5-flash not found for v1beta` could be due to missing `models/` prefix or incorrect model ID for the specific API version.
