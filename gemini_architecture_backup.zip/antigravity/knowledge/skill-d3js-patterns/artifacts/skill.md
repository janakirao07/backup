# D3.js in React

## Setup
```tsx
import * as d3 from 'd3';
import { useRef, useEffect } from 'react';

function BarChart({ data }) {
  const ref = useRef();
  useEffect(() => {
    const svg = d3.select(ref.current);
    svg.selectAll('rect').data(data).join('rect')
      .attr('width', d => d * 10).attr('height', 20);
  }, [data]);
  return <svg ref={ref} />;
}
```