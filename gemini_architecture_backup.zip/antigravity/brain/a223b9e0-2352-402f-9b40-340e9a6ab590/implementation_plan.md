# Implementation Plan - AI Blaze v2.0 (Job Seeker AI Copilot)
# AI-Blaze Copilot v2.0 Fixes

Modernize the AI-Blaze extension into a universal AI copilot by implementing a modular v2.0 architecture and fixing missing runtime dependencies in `content.js`.

## User Review Required

> [!IMPORTANT]
> The v2.0 features (Highlight-to-Prompt and Shortcut Triggers) are currently in **Beta**. Users must enable the "v2.0 Copilot Beta" toggle in Settings to use them.

## Proposed Changes

### Core Content Script

#### [MODIFY] [content.js](file:///c:/Users/janak/job-tracker-app/src/scripts/content.js)
- Add `callGeminiBlaze` and `callOllama` functions to handle AI requests from the content script context.
- Update `processAIShortcut` to properly load profile context and use the new engine functions.
- Fix Gemini key loading logic in the shortcut processor.

### Copilot Logic

#### [MODIFY] [copilot.js](file:///c:/Users/janak/job-tracker-app/src/scripts/copilot.js)
- Refine prompt templates for shortcuts.
- Improve input detection for `contenteditable` fields.

## Verification Plan

### Automated Tests
- [ ] Verify `rjd_v2_enabled` flag correctly gates features.
- [ ] Test `/fix` shortcut in a standard input field.

### Manual Verification
- [ ] Highlight text on a random website and verify the floating toolbar appears.
- [ ] Click "✨ Fix" and verify the result appears in the sidebar.
- [ ] Type `-ans ` in a text area and verify "✦ AI generating... " appears and is replaced by AI response.
o prompt users for `{formtext}` and `{formmenu}` values.

---

### 3. Highlight-to-Prompt (Quick Actions Toolbar)
Add selection detection and a floating toolbar for immediate AI actions.

#### [MODIFY] [content.js](file:///c:/Users/janak/job-tracker-app/src/scripts/content.js)
- Add `mouseup` and `selectionchange` listeners.
- Inject a floating `div#rjd-floating-toolbar` near the selection coordinates.
- Buttons for: Fix Grammar, Summarize, Expand, Shorten, Custom Prompt.

---

### 4. Shortcut Triggers Anywhere (Slash Commands)
Listen for specific triggers in text inputs and replace them with AI results.

#### [MODIFY] [content.js](file:///c:/Users/janak/job-tracker-app/src/scripts/content.js)
- Implement `InputWatchdog` to track `input`, `textarea`, and `contenteditable`.
- Listen for triggers: `-ans`, `-cover`, `-sum`, `/fix`, `/reply`, `/translate`.
- When triggered + [Space/Enter], call AI and replace the trigger text.

---

### 5. Dual-Engine Support (Gemini 2.5 & Ollama)
Ensure both the cloud (Gemini) and local (Ollama) engines support all v2.0 features.

#### [MODIFY] [app.js](file:///c:/Users/janak/job-tracker-app/src/scripts/app.js)
- Keep only `google` (Gemini 2.5) and `ollama` in `BLAZE_PROVIDERS`.
- Optimize `callOllama` for the new Copilot prompts.
- Ensure the extraction engine toggle also affects the global Copilot engine.

---

### 6. UI Refinement & Inline Actions
Update the sidebar and responses to be more interactive.

#### [MODIFY] [sidebar.css](file:///c:/Users/janak/job-tracker-app/src/styles/sidebar.css)
- New styles for the floating toolbar, result actions, and pulse animations.
- Inline action icons: 📋 (Copy), ✏️ (Paste to active field), 🔁 (Regenerate), 👍/👎 (Feedback).

## Open Questions

- **Formatting in Textareas**: How should we handle markdown formatting in standard textareas (which don't support bold/links)?
  - *Proposal*: Strip markdown for textareas, keep it for `contenteditable`.
- **Keyboard Shortcut Conflicts**: Should we allow users to customize triggers like `-ans` if they conflict with site-specific shortcuts?

## Verification Plan

### Automated Tests
- Test `PromptParser` with various tag combinations.
- Test `scrapePageSignals` against local HTML mocks of LinkedIn/Greenhouse.

### Manual Verification
- Highlight text on Gmail and verify toolbar appearance.
- Type `-ans` in a LinkedIn application field and verify replacement.
- Switch between Gemini, Ollama, and OpenAI in the sidebar.
