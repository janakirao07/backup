# PWA Verification Plan & Progress

- [ ] Check Employee Portal (`/employee/login`)
  - [ ] Verify manifest link (`/manifest-employee.json`) exists in DOM
  - [ ] Verify service worker registers successfully for scope `/employee/` in console
- [ ] Check Admin Portal (`/admin/login`)
  - [ ] Verify manifest link (`/manifest-admin.json`) exists in DOM
  - [ ] Verify service worker registers successfully for scope `/admin/` in console

## Findings / Notes
- Opened `http://localhost:3000/employee/login` - Compilation taking a few seconds. Waiting for load.
