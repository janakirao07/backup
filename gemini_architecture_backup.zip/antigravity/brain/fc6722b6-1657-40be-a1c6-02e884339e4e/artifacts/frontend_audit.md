# BSR Shopping Mall — Full Frontend Audit Report

> **Audit Date**: 2026-05-07  
> **Scope**: All user-facing pages, layout components, hydration boundaries, rendering stability, mobile responsiveness, and performance  
> **Severity**: 🔴 Critical | 🟡 High | 🟢 Medium

---

## Executive Summary

The BSR Shopping Mall has a solid architectural foundation (Server Components for pages, client interactivity isolated to leaf components, Zustand for client state). However, the audit reveals **7 critical issues** and **9 high-priority issues** that directly impact rendering stability, Lighthouse scores, and mobile conversion rates.

The three most impactful root causes are:
1. **HeroBanner fetches data client-side**, causing inconsistent homepage rendering between refreshes (CLS + flicker)
2. **Zero `loading.tsx` files exist**, leaving users with blank screens during route transitions
3. **SmoothScroll GSAP effect hides all `<section>` elements by default** (opacity: 0), causing flash-of-invisible-content on first load

---

## 🔴 Critical Issues

### C-1: HeroBanner Client-Side Data Fetching Causes CLS + Flicker
**File**: [HeroBanner.tsx](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/src/components/sections/HeroBanner.tsx#L84-L103)  
**Symptom**: Homepage hero section shows fallback slides briefly, then "jumps" to Supabase slides after ~500ms. On slow connections, the fallback is visible for 2-3 seconds.  
**Root Cause**: `useEffect` fetches `hero_banners` from the browser Supabase client. Server never pre-renders the actual data.  
**Impact**: CLS violation, inconsistent rendering between refreshes, SEO (Google sees fallback content only), LCP delay.  
**Fix**: Fetch hero banners on the server and pass as props, or create a dedicated server action.

### C-2: SmoothScroll GSAP Sets All Sections to opacity:0
**File**: [SmoothScroll.tsx](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/src/components/providers/SmoothScroll.tsx#L14-L30)  
**Symptom**: All `<section>` elements start invisible (`opacity: 0`) and fade in via ScrollTrigger. If GSAP loads slowly or fails, content stays invisible.  
**Root Cause**: `gsap.fromTo(section, { opacity: 0 }, ...)` — this blankets every section on every page with a "hidden by default" state.  
**Impact**: Flash of invisible content, blocked Lighthouse FCP/LCP, accessibility (screen readers may announce invisible content), CLS on scroll.  
**Fix**: Remove the blanket opacity animation. If reveal effects are desired, use CSS-only `@starting-style` or limit to below-fold sections.

### C-3: No Loading States (Zero `loading.tsx` Files)
**Symptom**: Navigating between category pages (Men → Women → Kids) shows a blank white screen for 1-3 seconds while the server fetches products.  
**Root Cause**: No `loading.tsx` files exist anywhere in the `app/` directory. Next.js has no Suspense boundary to show.  
**Impact**: Poor perceived performance, user confusion (is the page broken?), bounce rate increase.  
**Fix**: Add skeleton `loading.tsx` files for storefront, category pages, product detail, and admin.

### C-4: OfferTicker Client-Side Supabase Fetch
**File**: [OfferTicker.tsx](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/src/components/layout/OfferTicker.tsx#L17-L47)  
**Symptom**: Announcement ticker doesn't render on initial load, then pops in after data fetch completes.  
**Root Cause**: Uses browser Supabase client to fetch `settings` table in `useEffect`. Server renders nothing (`active = false`).  
**Impact**: CLS (0px → 40px height shift), inconsistent rendering between refreshes.  
**Fix**: Fetch settings on the server (in the layout) and pass as props.

### C-5: CartDrawer Returns `null` Before Mount
**File**: [CartDrawer.tsx](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/src/components/cart/CartDrawer.tsx#L20)  
**Symptom**: `if (!mounted) return null;` — the CartDrawer renders nothing on the server. This is acceptable for the drawer itself, but since it's included in every page via the storefront layout, it adds a mandatory hydration checkpoint.  
**Impact**: Minor hydration delay, but compounds with other `mounted` checks in Navbar, MobileTabBar, and WishlistButton (4 separate `useState(false)` + `useEffect` patterns for hydration guards).

### C-6: Checkout Returns `null` Until Mounted
**File**: [checkout/page.tsx](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/src/app/%5Blocale%5D/%28storefront%29/checkout/page.tsx#L77)  
**Symptom**: Entire checkout page is blank white on server render, then appears after hydration.  
**Root Cause**: `if (!mounted) return null;` — the entire 530-line checkout component returns nothing until `useEffect` fires.  
**Impact**: SEO (blank page for crawlers), LCP (no content until JS executes), poor user experience.

### C-7: CSP Blocks Razorpay Checkout Script
**File**: [next.config.ts](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/next.config.ts#L54-L55)  
**Current CSP**: `script-src 'self' 'unsafe-inline' 'unsafe-eval' https://*.supabase.co https://*.googleapis.com`  
**Missing**: `https://checkout.razorpay.com` and `https://*.razorpay.com`  
**Impact**: Razorpay checkout will fail silently in production with strict CSP enforcement.

---

## 🟡 High-Priority Issues

### H-1: Category Pages Force Dynamic Rendering
**Files**: `men/page.tsx`, `women/page.tsx`, `kids/page.tsx`  
**Issue**: `export const dynamic = "force-dynamic"` forces every category page to be server-rendered on each request, bypassing Next.js ISR cache.  
**Impact**: Slower TTFB, no CDN caching, unnecessary server load. Products are already cached via `unstable_cache` (1h), so `force-dynamic` is redundant.

### H-2: StoreLocator Google Maps iframes Load Eagerly on Mobile
**File**: [StoreLocator.tsx](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/src/components/sections/StoreLocator.tsx#L55-L64)  
**Issue**: Two Google Maps `<iframe>` elements load on the homepage even though they're below the fold.  
**Impact**: ~200KB+ of third-party resources loaded before the user scrolls to them. Blocks main thread.  
**Fix**: Already has `loading="lazy"`, but the iframes still consume layout space. Consider IntersectionObserver to conditionally render.

### H-3: ProductCard Secondary Image Loads Without `loading="lazy"`
**File**: [ProductCard.tsx](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/src/components/products/ProductCard.tsx#L97-L105)  
**Issue**: The hover-reveal secondary image loads eagerly for every product card in the grid.  
**Impact**: For a page with 20 products, this means 20 additional image requests on page load that the user may never see.  
**Fix**: Add `loading="lazy"` to secondary images.

### H-4: Image Wildcard Domain in next.config.ts
**File**: [next.config.ts](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/next.config.ts#L10-L14)  
**Issue**: `hostname: "**"` allows any domain for remote images.  
**Impact**: Security risk (XSS via malicious image URLs), no domain-specific optimization.  
**Fix**: Restrict to known domains (Supabase storage, Unsplash).

### H-5: Duplicate Supabase Fetch in Admin Dashboard
**File**: [admin/page.tsx](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/src/app/%5Blocale%5D/%28admin%29/admin/page.tsx#L34-L42)  
**Issue**: `totalInquiries` is fetched separately (line 42) even though it could be derived from `inquiryRes` already fetched in the `Promise.all` (line 35).  
**Impact**: Extra database round-trip on every admin dashboard load.

### H-6: Lenis Smooth Scroll Overhead on Mobile
**File**: [SmoothScroll.tsx](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/src/components/providers/SmoothScroll.tsx)  
**Issue**: Lenis smooth scroll wraps the entire storefront (including checkout, login, etc.) and imports GSAP + ScrollTrigger on every page.  
**Impact**: ~40KB+ JS bundle overhead. On low-end mobile devices, Lenis can actually make scrolling feel *worse* by competing with native smooth scroll.

### H-7: `new Date().getFullYear()` in Footer Causes Hydration Mismatch Risk
**File**: [Footer.tsx](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/src/components/layout/Footer.tsx#L208)  
**Issue**: `new Date().getFullYear()` is a Server Component calling a time-dependent function. If the server timezone and client timezone differ at midnight on Dec 31, the year could differ.  
**Impact**: Rare but real hydration mismatch. Low priority.

### H-8: MobileTabBar Code Duplication
**File**: [MobileTabBar.tsx](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/src/components/layout/MobileTabBar.tsx#L36-L163)  
**Issue**: The tab rendering logic is copy-pasted 3 times (Home, Shop, Account) with nearly identical JSX.  
**Impact**: Maintainability nightmare, increased bundle size.

### H-9: WhatsAppWidget DOM Manipulation with IntersectionObserver
**File**: [WhatsAppWidget.tsx](file:///c:/Users/janak/Downloads/_Misc/vinay/BSR%20shopping%20mall/src/components/ui/WhatsAppWidget.tsx#L21-L29)  
**Issue**: Uses `document.getElementById("main-footer")` — direct DOM query in React component.  
**Impact**: Fragile (breaks if footer ID changes), not React-idiomatic.

---

## 🟢 Medium-Priority Issues

| # | Issue | File | Impact |
|---|-------|------|--------|
| M-1 | `isNewArrival()` uses `new Date()` — hydration risk | ProductCard.tsx:16-22 | Potential mismatch |
| M-2 | SearchOverlay uses browser Supabase for search | SearchOverlay.tsx:30 | Works but prevents server-side search optimization |
| M-3 | `formatDate` in admin creates closures in render | admin/page.tsx:54-63 | Minor GC pressure |
| M-4 | No `error.tsx` boundaries | app/ directory | Unhandled errors show blank page |
| M-5 | OfferTicker clones DOM nodes manually | OfferTicker.tsx:54-62 | React anti-pattern, memory leak risk |
| M-6 | ProductGrid imports unused `SlidersHorizontal` conditionally | ProductGrid.tsx | Minor bundle impact |

---

## Implementation Plan

### Phase 1: Critical Fixes (C-1 through C-7)

1. **Fix C-2**: Remove GSAP blanket opacity animation from SmoothScroll
2. **Fix C-3**: Add `loading.tsx` files for major routes
3. **Fix C-1 + C-4**: Refactor HeroBanner and OfferTicker to accept server-fetched props
4. **Fix C-7**: Update CSP to include Razorpay domains
5. **Fix H-1**: Remove `force-dynamic` from category pages
6. **Fix H-3**: Add `loading="lazy"` to secondary product images
7. **Fix H-5**: Remove duplicate admin dashboard fetch

### Phase 2: High-Priority Fixes (H-2 through H-9)

8. **Fix H-8**: DRY up MobileTabBar
9. **Fix H-6**: Conditionally load Lenis only on storefront pages, skip on mobile

---

> [!IMPORTANT]
> The most impactful fix is **C-2 (SmoothScroll opacity)** — it currently makes every section on every page invisible until GSAP triggers. Fixing this alone will dramatically improve FCP and LCP.
