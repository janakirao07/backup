# Job Search Page Implementation Plan

## Goal
Add a professional "Job Search" page to the dashboard that allows users to search for live job postings worldwide using the JSearch API (RapidAPI). Users will be able to search by role and location, browse results, and instantly "Track" jobs by pre-filling the existing "Add Application" modal.

## Proposed Changes

### [MODIFY] `src/pages/app.html`
- **Sidebar Navigation**: Add a "Job Search" nav item to both the desktop sidebar and mobile drawer.
- **CSS Styles**: Add styles for:
  - `.job-search-wrap`: Container for search inputs.
  - `.job-results-grid`: Grid for displaying job cards.
  - `.job-card`: Glassmorphism cards with company logo placeholders, title, location, and salary (if available).
- **Navigation Update**: Ensure the sidebar links to `data-page="jobs"`.

### [MODIFY] `src/scripts/app.js`
- **Navigation Logic**:
  - Add `'jobs'` to the `validPages` list.
  - Update `navigateTo` to handle the new page.
  - Update `renderPage` to call `renderJobSearch()`.
- **API Configuration**:
  - Implement `saveRapidAPIKey(key)` and `loadRapidAPIKey()` similar to Gemini keys.
  - Update Settings page ("AI Config" or new "Integrations" section) to allow users to input their **RapidAPI JSearch Key**.
- **Job Search Rendering (`renderJobSearch`)**:
  - State management for `jobSearchResults`.
  - Search UI: Inputs for "Role / Keyword" and "Location" + "Search" button.
  - Result UI: Map over `jobSearchResults` and render cards.
  - **Quick Track Integration**: Clicking "Track" on a job card will:
    1. Extract company name, title, and URL from the result.
    2. Open the existing `add-modal`.
    3. Pre-fill the modal fields (`m-company`, `m-title`, `m-url`).
- **Data Fetching**:
  - Implement `fetchJobs(query)` using `fetch`.
  - Handle loading states with a spinner.
  - Display helpful errors (e.g., "Missing API Key") with instructions on how to get one from RapidAPI.

## Verification Plan

### Automated Tests
- None required for this pure-UI/client logic addition.

### Manual Verification
1. **Config**: Go to Settings, enter a RapidAPI Key, and save.
2. **Navigation**: Click "Job Search" in the sidebar.
3. **Search**: Search for "React Developer in London". Verify that results appear.
4. **Tracking**: Click "Track" on a search result. Verify the "New Application" modal opens with correct fields pre-filled.
5. **Saving**: Save the application and verify it appears in the "Applications" list/Kanban board.

## Open Questions

> [!IMPORTANT]
> 1. JSearch results often include logos. Should we attempt to display company logos in the search cards? (Requires handling broken image fallbacks).
> 2. RapidAPI has a free tier for JSearch, but it's limited. Should I include a link in the UI to help users get their own free API key?
