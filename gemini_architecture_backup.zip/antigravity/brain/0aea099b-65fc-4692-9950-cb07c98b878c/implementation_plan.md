# Plan: Persistent Error Logging System

This plan implements a robust error logging system that captures runtime errors across the extension and dashboard, persists them in local storage, and provides a way for the user to download a log file for debugging.

## Proposed Changes

### Core Utility

#### [NEW] [logger.js](file:///c:/Users/janak/job-tracker-app/src/lib/logger.js)
- Implement `AppLogger` utility.
- Functions: `error(msg, meta)`, `getLogs()`, `clearLogs()`, `downloadLogs()`.
- Logic to cap logs at 200 entries to prevent storage bloat.

### Integration

#### [MODIFY] [content.js](file:///c:/Users/janak/job-tracker-app/src/scripts/content.js)
- Import/Include `logger.js`.
- Integrate `AppLogger` into `safeSendMessage`, `fetchWithRetry`, and extraction flows.

#### [MODIFY] [app.js](file:///c:/Users/janak/job-tracker-app/src/scripts/app.js)
- Integrate `AppLogger` into the dashboard.
- Add a **"Logs"** section to the Settings screen.
- Implement a "Download Error Log" button.

#### [MODIFY] [background.js](file:///c:/Users/janak/job-tracker-app/src/scripts/background.js)
- Integrate `AppLogger` into the background service worker for silent error capture.

### UI Enhancement

#### [MODIFY] [app.html](file:///c:/Users/janak/job-tracker-app/src/pages/app.html) & [index.html](file:///c:/Users/janak/job-tracker-app/index.html)
- Add the `logger.js` script tag.

## Verification Plan

### Automated Tests
- Manually trigger a mock error and verify it appears in `AppLogger.getLogs()`.
- Verify log rotation (ensuring old logs are removed once the cap is hit).

### Manual Verification
- Go to Settings → Logs and verify the list of captured errors.
- Click "Download Log File" and verify the generated `.txt` file content.
