# Windows System Performance Review

I have run diagnostics on your system to analyze hardware utilization, memory stats, and active processes. Here is a breakdown of what's currently happening on your machine and the best solutions to address heating, lag, and speed.

## 🖥️ System Profile Detected
- **Processor:** 13th Gen Intel Core i5-13420H (High-performance Laptop CPU, 8 Cores / 12 Threads)
- **Memory (RAM):** 16 GB (Currently running low: 12 GB used, ~4 GB free)
- **Storage:** ~500 GB Drive (114 GB free space remaining)
- **Graphics:** Dual GPU setup (Intel Integrated + NVIDIA Dedicated)

---

## 🔍 Key Findings (Why it's lagging & heating)

1. **High Background CPU Usage**
   I detected several background services consuming a large amount of CPU cycles. This is the primary cause of unexplained heating on laptop CPUs:
   - **OneDrive (`OneDrive.Sync.Service`):** Constantly scanning and syncing files.
   - **NVIDIA ShadowPlay (`nvcontainer`, `nvsphelper64`):** Features like in-game overlay continuously record your screen in the background.
   - **Intel Telemetry (`esrv.exe`):** Intel's System Usage Report service runs in the background.

2. **Memory (RAM) Pressure**
   With only ~4 GB of free RAM while idle, your system is very close to maximum capacity. When you open demanding applications (like training your ActionSense AI models or running heavy Web development tools), Windows will start using your SSD as "virtual RAM" (paging). This causes severe system latency, lag, and UI freezes.

3. **Thermal Constraints (H-Series CPU)**
   The `i5-13420H` is a powerful processor designed for gaming and heavy workloads, which natively runs hotter than average processors. Because the system is constantly crunching background tasks, the CPU rarely gets to "sleep," generating persistent heat.

---

## 🛠️ Recommended Solutions

### Step 1: Debloat Background Processes (Immediate Speed & Heat Fix)

> [!TIP]
> **Disable NVIDIA In-Game Overlay:** 
> Open **GeForce Experience** > Go to **Settings** (Gear icon) > Toggle OFF **In-Game Overlay**. This stops constant background screen recording.

> [!TIP]
> **Manage OneDrive:** 
> If you don't need real-time syncing, click the OneDrive cloud icon in your taskbar, click the gear icon, and select **"Pause syncing"** (e.g., for 8 hours) while you are coding or running heavy tasks.

> [!TIP]
> **Disable Intel System Usage Report (`esrv.exe`):**
> Open **Services** (Press Start, type `services.msc`) > Find **Intel System Usage Report Service** > Right-click to Properties > Set Startup type to **Disabled**.

### Step 2: Address Memory & Lag

> [!NOTE] 
> Because 16GB is slightly low for intense software development + machine learning workflows, managing background tabs is critical.

- **Browser Memory Saver:** Ensure "Memory Saver" is enabled in Chrome/Edge settings to put inactive tabs to sleep.
- **Turn off excessive Startup Apps:** Open **Task Manager** (`Ctrl + Shift + Esc`) > Go to the **Startup apps** tab > Right-click and disable anything you don't immediately need when the PC boots (e.g., Spotify, Skype, Cortana, Epic Games, etc.).

### Step 3: Heat Management (Physical & System)

> [!IMPORTANT]
> **Power Plan Adjustment:** By default, Windows might be pushing aggressive turbo boosts on your i5 processor even for small tasks, causing instant heat spikes.

- **Check OEM Software:** Do you have an app like Lenovo Vantage, Asus Armoury Crate, or Acer PredatorSense? Use it to switch your fans to "Performance" when doing heavy work, and "Quiet" when browsing.
- **Physical Airflow:** Ensure the back vents of your laptop are not obstructed. Using an angled laptop stand (even without fans) can reduce temperatures by 3°C to 5°C simply by allowing the intake fans to breathe.

### Step 4: Storage Maintenance
You have 114 GB free on your 500 GB drive. To keep SSDs running fast and prevent lag, they prefer to have about 20-25% free space. You are right on the borderline. Continue moving large models or unused videos to an external drive if possible to keep Windows running optimally.
