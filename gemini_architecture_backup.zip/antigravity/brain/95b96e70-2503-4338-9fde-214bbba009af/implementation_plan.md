# Universal Resume Builder - Project Evolution

Transforming the offline, single-file Resume Builder into a modern, professional web application platform with persistent storage and a Chrome extension for automated field-filling.

## User Review Required

> [!IMPORTANT]
> **Supabase Credentials**: I will need your Supabase URL and Anon Key to set up the authentication and database. If you don't have them yet, I can provide a mock setup, but a live one is required for the "Live URL" and persistent saving.
> 
> [!CAUTION]
> **Extension Permissions**: The Chrome extension will require `host_permissions` for job application sites (e.g., LinkedIn) to inject the "Auto-Paste" button. 

## Proposed Changes

### [Component 1] Next.js Dashboard (Web App)
Port the existing offline logic into a modern Next.js 14 project.
- **`app/login/`**: Simple, aesthetic glassmorphism login page using Supabase Auth.
- **`app/dashboard/`**:
    - **Personal Profile Editor**: Replicate and enhance the current form.
    - **Save Functionality**: Save details to a Supabase `profiles` table instead of just `localStorage`.
    - **Resume Generation**: Integrated logic using the `docx` library (migrated from the current HTML).
- **`app/api/profile/`**: Secure endpoint for the extension to fetch user details.

### [Component 2] Supabase (Backend/Database)
- **Authentication**: Set up Email/Password auth.
- **`profiles` table**: Store `id` (linked to user), `full_name`, `title`, `email`, `phone`, `location`, `linkedin`, `education`, `certifications`.

### [Component 3] Chrome Extension
A companion tool for the web app.
- **`manifest.json`**: (V3) host permissions for job sites.
- **Popup UI**: Login status and a "Go to Dashboard" button.
- **Content Script**:
    - **Smart Injection**: Detect form fields on LinkedIn/Indeed.
    - **Floating Button**: A sleek "Fill with Profile" button that appears on relevant pages.
    - **Click Interaction**: Fetches profile from the Dashboard API and fills all matching fields automatically.

## Open Questions

- **Live URL**: Which platform do you prefer for the live URL? (Vercel is recommended for Next.js).
- **Extension Layout**: Do you prefer a sidebar that stays open or a floating button that appears on form fields?
- **AI Automation**: Should the extension also help in "parsing" the job description automatically to suggest tailored content?

## Verification Plan

### Automated Tests
-   Verify Supabase authentication flow (Login/Signup).
-   Test `.docx` file generation in the Next.js environment.
-   Dry-run extension injection on a test LinkedIn page.

### Manual Verification
-   Test the end-to-end flow: Login -> Save Profile -> Open LinkedIn -> Click "Fill" -> Download Tailored Resume.
