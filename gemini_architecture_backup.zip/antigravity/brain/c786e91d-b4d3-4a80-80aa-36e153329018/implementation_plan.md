# Home Directory Cleanup Plan

Reorganize the cluttered `C:\Users\janak\` directory by moving misplaced files into proper folders.

## User Review Required

> [!CAUTION]
> This involves **moving your personal files** around. I will NOT delete anything — only move files into organized folders. Please review carefully before approving.

> [!IMPORTANT]
> I will **NOT touch** any of these system/config items:
> - Windows system files (`NTUSER.DAT`, `ntuser.*`, `AppData`, etc.)
> - Hidden dot-folders (`.ssh`, `.gitconfig`, `.conda`, `.vscode`, `.gemini`, etc.)
> - Windows default folders (`Documents`, `Music`, `Videos`, `Favorites`, `Contacts`, etc.)
> - Your active project workspace (`actionsense`)

## Current Problems

Your home folder has **128+ items** scattered everywhere:
- **~1.6 GB of installer `.exe` files** sitting in the home directory
- Loose Python scripts (`ai.chatbot.py`, `apply_jobs.py`, `from PIL import Image.py`, `import cv2.py`)
- Random images (`check.jpg`, `ghi bli.png`, `test_image.jpg`)
- Duplicate zip files alongside their extracted folders
- Personal documents (Love Letters, bank statements, resumes) loose in home
- SQL files, Jupyter notebooks, Excel files all mixed together
- An old Java error log, a battery report, and random config files

## Proposed New Structure

I will create organized folders and move files into them:

```
C:\Users\janak\
├── _Installers/               ← All .exe/.msi installer files
├── _PersonalDocs/             ← Resumes, certificates, Aadhar, bank docs
├── _PythonScripts/            ← Loose .py files
├── _DataFiles/                ← .xlsx, .csv, .json data files
├── _SQLFiles/                 ← .sql files
├── _Images/                   ← Loose image files (.jpg, .png)
├── _Archives/                 ← .zip/.rar archives
├── _Misc/                     ← Everything else (logs, .tex, .html, misc)
│
├── actionsense/               ← (UNTOUCHED - your active project)
├── Documents/                 ← (UNTOUCHED - Windows default)
├── Downloads/                 ← (Will also be cleaned similarly)
├── .gemini/                   ← (UNTOUCHED - config)
├── ... other system folders   ← (UNTOUCHED)
```

## Proposed Changes

### Home Directory (`C:\Users\janak\`)

#### Move to `_Installers/`
| File | Size |
|------|------|
| `Antigravity.exe` | 234 MB |
| `Claude Setup.exe` | 152 MB |
| `CursorUserSetup-x64-3.0.13.exe` | 179 MB |
| `Postman (x64).exe` | 142 MB |
| `QuickShareSetup.exe` | 10 MB |
| `Raindrop.io Installer.exe` | 1 MB |
| `TableauPublicDesktop-64bit-2025-2-0.exe` | 568 MB |
| `VMware-Workstation-Full-25H2u1-25219725.exe` | 278 MB |
| `VSCodeUserSetup-x64-1.99.1.exe` | 103 MB |

#### Move to `_PersonalDocs/`
- `Love_Letter.docx`, `Love_Letter_Decorated.docx`
- `clients.xlsx`
- `mini_statement_2034434943.csv`

#### Move to `_PythonScripts/`
- `ai.chatbot.py`, `apply_jobs.py`, `from PIL import Image.py`, `import cv2.py`, `test_selenium.py`

#### Move to `_DataFiles/`
- `glassdoor_demo.xlsx`, `glassdoor_results.xlsx`, `job_results.xlsx`

#### Move to `_SQLFiles/`
- `oracle 19.sql`, `oracle19c.sql`

#### Move to `_Images/`
- `check.jpg`, `ghi bli.png`, `test_image.jpg`

#### Move to `_Archives/`
- `Drug_project (2).zip`, `Drug_project.zip`
- `Production_support in 30 days.zip`, `har_project.zip`

#### Move to `_Misc/`
- `4.10.0` (stray file), `html`, `Untitled.ipynb`
- `battery-report.html`, `java_error_in_pycharm_6112.log`

---

### Downloads Folder Cleanup

> [!WARNING]
> Your Downloads folder has **209 items** including a **893 MB movie file** (`The Truman Show`), a **922 MB GPU driver**, and a **1 GB Splunk installer** from the home dir. I recommend you review what to keep vs delete there separately — I will NOT auto-delete anything.

The Downloads folder is messy too, but since it's meant to be a landing zone, I suggest we focus on the **home directory first** and tackle Downloads later if you want.

## Open Questions

1. **Delete old installers?** Files like `Antigravity.exe`, `Claude Setup.exe`, `VSCodeUserSetup.exe` — these apps are already installed. Should I **delete** them instead of moving to `_Installers/`? That would free up ~1.6 GB instantly.
2. **Downloads cleanup?** Do you want me to organize the Downloads folder too, or leave it for now?
3. **Splunk installer** (`splunk-10.2.1...msi`, 1 GB) is sitting in your home directory root. Delete or move?

## Verification Plan

### Manual Verification
- After reorganization, I will list the home directory contents to confirm it is clean
- All moved files will be verified to exist in their new locations
