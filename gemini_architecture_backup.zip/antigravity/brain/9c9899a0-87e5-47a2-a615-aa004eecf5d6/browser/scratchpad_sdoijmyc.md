# Task: Check Chakradhar Resume PDF

## Status Tracker
- [/] Open PDF in browser (file:/// blocked, localhost:3000 refused) <!-- id: 0 -->
- [ ] Capture screenshot of the resume <!-- id: 1 -->
- [ ] Inspect for visual issues (overlapping text, cut-off, contrast) <!-- id: 2 -->
- [ ] Report findings <!-- id: 3 -->

## Findings
- `file:///` access is blocked in the browser.
- `http://localhost:3000` refused connection.
- Trying other common development ports or searching for the live site.
