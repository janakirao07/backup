# Extraction Refactor Tasks

- [x] Implement recursive JSON-LD parser for nested `@graph` JobPosting elements
- [x] Implement domain-specific config mapping (LinkedIn, Naukri, Indeed, Glassdoor, etc.)
- [x] Update `scrapePageSignals()` to run domain-specific extractors first
- [x] Modify `extractWithGemini()` to hard-override Gemini's output if a verified company/title is found locally
