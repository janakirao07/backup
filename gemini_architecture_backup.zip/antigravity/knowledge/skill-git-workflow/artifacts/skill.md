---
name: git-workflow
description: Git best practices for branching, committing, merging, and collaboration. Use when working with version control, creating branches, writing commit messages, or managing releases.
---

# Git Workflow Best Practices

## Branching Strategy
- **main/master** — Always deployable. Never commit directly.
- **develop** — Integration branch for features.
- **feature/*** — One branch per feature: `feature/add-dark-mode`
- **fix/*** — Bug fixes: `fix/login-redirect-loop`
- **hotfix/*** — Emergency production fixes: `hotfix/payment-crash`

## Branch Naming Conventions
```
feature/<short-description>    # New features
fix/<issue-or-description>     # Bug fixes
hotfix/<critical-fix>          # Urgent production fixes
chore/<task>                   # Maintenance, deps, configs
refactor/<area>                # Code restructuring
docs/<topic>                   # Documentation updates
```

## Commit Message Format
Use Conventional Commits:
```
<type>(<scope>): <short description>

[optional body]

[optional footer]
```

### Types
| Type | When to use |
|------|-------------|
| `feat` | New feature |
| `fix` | Bug fix |
| `docs` | Documentation only |
| `style` | Formatting, no code change |
| `refactor` | Code change that neither fixes nor adds |
| `perf` | Performance improvement |
| `test` | Adding/fixing tests |
| `chore` | Build process, deps, configs |

### Examples
```
feat(auth): add Google OAuth login
fix(api): handle null response from Supabase
docs(readme): add deployment instructions
refactor(utils): extract date formatting to helper
```

## Commit Rules
1. **Atomic commits** — One logical change per commit
2. **Present tense** — "add feature" not "added feature"
3. **No vague messages** — Never use "fix stuff", "update", "WIP"
4. **Reference issues** — `fix(auth): resolve login loop (#42)`
5. **Keep commits small** — Easy to review, revert, bisect

## Git Workflow Steps
```bash
# Start new feature
git checkout develop
git pull origin develop
git checkout -b feature/add-dark-mode

# Work and commit
git add -A
git commit -m "feat(ui): add dark mode toggle component"

# Stay updated
git fetch origin
git rebase origin/develop

# Push and create PR
git push origin feature/add-dark-mode
```

## Merge Strategy
- **Feature → develop**: Squash merge (clean history)
- **develop → main**: Merge commit (preserve milestone)
- **hotfix → main**: Merge commit + cherry-pick to develop

## Pre-Push Checklist
- [ ] All tests pass
- [ ] No console.log / debug statements
- [ ] Code is linted and formatted
- [ ] Commit messages follow convention
- [ ] Branch is rebased on latest develop
- [ ] No merge conflicts

## Git Aliases (Productivity)
```bash
git config --global alias.st "status -sb"
git config --global alias.lg "log --oneline --graph --decorate -20"
git config --global alias.co "checkout"
git config --global alias.cm "commit -m"
git config --global alias.undo "reset HEAD~1 --mixed"
```

## .gitignore Essentials
```
node_modules/
.env
.env.local
.env.*.local
dist/
build/
.next/
*.log
.DS_Store
Thumbs.db
```

## Dangerous Commands — Always Think Twice
| Command | Risk | Safer alternative |
|---------|------|-------------------|
| `git push --force` | Overwrites remote history | `git push --force-with-lease` |
| `git reset --hard` | Loses uncommitted work | `git stash` first |
| `git clean -fd` | Deletes untracked files permanently | `git clean -fdn` (dry run first) |
| `git rebase -i` on shared branches | Rewrites shared history | Only on local/feature branches |
