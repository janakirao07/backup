﻿# Framer Motion Patterns

## Basic Animation
```tsx
import { motion } from 'framer-motion';

<motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: 0.5, ease: 'easeOut' }}
>
  Fade in and slide up
</motion.div>
```

## Variants (Orchestrated Animations)
```tsx
const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.1 } }
};
const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

<motion.ul variants={container} initial='hidden' animate='show'>
  {items.map(i => <motion.li key={i} variants={item}>{i}</motion.li>)}
</motion.ul>
```

## Exit Animations
```tsx
import { AnimatePresence } from 'framer-motion';

<AnimatePresence mode='wait'>
  {isVisible && (
    <motion.div key='modal'
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
    />
  )}
</AnimatePresence>
```

## Gestures
```tsx
<motion.button
  whileHover={{ scale: 1.05 }}
  whileTap={{ scale: 0.95 }}
  drag='x'
  dragConstraints={{ left: -100, right: 100 }}
/>
```

## Scroll Animations
```tsx
import { useScroll, useTransform, motion } from 'framer-motion';

function ParallaxSection() {
  const { scrollYProgress } = useScroll();
  const y = useTransform(scrollYProgress, [0, 1], [0, -200]);
  return <motion.div style={{ y }}>Parallax content</motion.div>;
}
```

## Layout Animations
```tsx
// Smooth layout transitions
<motion.div layout layoutId='card'>
  {isExpanded ? <ExpandedCard /> : <CompactCard />}
</motion.div>
```

## Key Rules
- Use layout prop for automatic layout animations
- AnimatePresence required for exit animations
- Use variants for parent-child orchestration
- Spring physics: type:'spring', stiffness, damping
- useInView hook for scroll-triggered animations
