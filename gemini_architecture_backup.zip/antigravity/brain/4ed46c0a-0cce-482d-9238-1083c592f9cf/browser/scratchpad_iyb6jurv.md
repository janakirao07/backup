# PageSpeed Insights Check

## Tasks
- [x] Open PageSpeed Insights
- [x] Run audit for https://sk-degree-college.vercel.app
- [x] Open PageSpeed Insights
- [x] Run audit for https://sk-degree-college.vercel.app
- [x] Wait for results
- [x] Extract Mobile metrics (Score, LCP, TBT, CLS)
- [x] Compare with previous score (49%)
- [x] Report findings

## Findings
- Previous Score: 49%
- New Score: 65%
- LCP: 4.4 s
- TBT: 780 ms
- CLS: 0
