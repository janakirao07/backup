# Implementation Plan — Optimal Code Review Graph Setup

This plan outlines the "best way" to reinstall and configure the `code-review-graph` tool to ensure it provides high-quality context for your AI assistant during code reviews.

## User Review Required

> [!TIP]
> The "best way" to use this tool is by enabling the **MCP (Model Context Protocol)** server and injecting specific instructions into your **IDE Rules** (.windsurfrules). This allows the AI to automatically query the graph before suggesting changes.

## Proposed Changes

### 1. Installation
#### [EXECUTE] [Command Line](https://github.com/tirth8205/code-review-graph)
- Run `pip install code-review-graph` to get the latest version.
- Run `code-review-graph install` to auto-detect your platform (Windsurf) and configure the MCP server.

### 2. Initialization
#### [EXECUTE] [Command Line](https://github.com/tirth8205/code-review-graph)
- Run `code-review-graph build` to generate the structural map of the `job-tracker-app`.
- Run `code-review-graph status` to verify the index is healthy.

### 3. Rule Optimization
#### [MODIFY] [.windsurfrules](file:///c:/Users/janak/job-tracker-app/.windsurfrules)
- Add a section that explicitly instructs the AI to use the `code-review-graph` tools (like `review_changes` or `get_impact_radius`) whenever performing a code review or refactoring.

## Open Questions

- **Embeddings**: Would you like to install the `[all]` extras? (e.g., `pip install code-review-graph[all]`). This enables **semantic search** and **community detection**, which makes the "Architecture Overview" much more detailed.
- **Specific Workflows**: Are there specific areas of the project (e.g., Gemini API logic, Supabase syncing) you want the graph to prioritize for reviews?

## Verification Plan

### Automated Verification
- **Status Check**: Run `code-review-graph status` to see the number of nodes/edges indexed.
- **Tool Check**: Ask the AI (me) to "Show me the architecture map of the Gemini extraction logic" to verify the MCP tools are responding.

### Manual Verification
- **MCP Sidebar**: Verify that the "MCP" error in your IDE terminal vanishes and is replaced by a green checkmark or an active status.
