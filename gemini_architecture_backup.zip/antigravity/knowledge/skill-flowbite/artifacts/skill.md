---
name: flowbite-best-practices
description: Flowbite Tailwind CSS UI component library. Use when building UI with pre-built Tailwind components like navbars, modals, cards, tables, forms, and dashboards.
---

# Flowbite Best Practices

## Installation
```bash
npm install flowbite flowbite-react
```

### Tailwind Config
```javascript
// tailwind.config.js
module.exports = {
  content: [
    './src/**/*.{js,ts,jsx,tsx}',
    'node_modules/flowbite-react/**/*.{js,ts,jsx,tsx}',
  ],
  plugins: [require('flowbite/plugin')],
};
```

## Key Components (React)
```tsx
import { Button, Modal, Card, Navbar, TextInput, Table, Badge, Alert, Dropdown, Tabs, Tooltip, Spinner } from 'flowbite-react';

// Button variants
<Button color="primary">Primary</Button>
<Button color="gray" outline>Outlined</Button>
<Button gradientDuoTone="purpleToBlue">Gradient</Button>
<Button pill size="sm">Small Pill</Button>

// Card
<Card className="max-w-sm">
  <h5 className="text-2xl font-bold">Card Title</h5>
  <p className="text-gray-500">Card description here.</p>
  <Button>Read More</Button>
</Card>

// Modal
<Modal show={openModal} onClose={() => setOpenModal(false)}>
  <Modal.Header>Terms of Service</Modal.Header>
  <Modal.Body><p>Content here</p></Modal.Body>
  <Modal.Footer>
    <Button onClick={() => setOpenModal(false)}>Accept</Button>
  </Modal.Footer>
</Modal>

// Table
<Table>
  <Table.Head>
    <Table.HeadCell>Name</Table.HeadCell>
    <Table.HeadCell>Status</Table.HeadCell>
  </Table.Head>
  <Table.Body>
    <Table.Row>
      <Table.Cell>John Doe</Table.Cell>
      <Table.Cell><Badge color="success">Active</Badge></Table.Cell>
    </Table.Row>
  </Table.Body>
</Table>
```

## Available Components (56+)
| Category | Components |
|----------|-----------|
| **Navigation** | Navbar, Sidebar, Breadcrumb, Tabs, Pagination, Footer |
| **Forms** | TextInput, Select, Textarea, Checkbox, Radio, Toggle, FileInput, RangeSlider |
| **Data Display** | Table, Card, List, Timeline, Accordion, Carousel |
| **Feedback** | Alert, Toast, Badge, Progress, Spinner, Rating |
| **Overlays** | Modal, Drawer, Dropdown, Popover, Tooltip |
| **Actions** | Button, ButtonGroup, FloatingLabel |

## Dark Mode
```tsx
// Flowbite supports Tailwind dark mode natively
<Card className="dark:bg-gray-800 dark:text-white">
  <p className="text-gray-700 dark:text-gray-300">Auto dark mode</p>
</Card>
```

## When to Use Flowbite
- ✅ Admin dashboards and internal tools
- ✅ Rapid prototyping
- ✅ Landing pages
- ✅ CRUD applications
- ❌ Highly custom designs (use Headless UI instead)
- ❌ When you need full control over animations
