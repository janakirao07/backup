# ESBuild Best Practices

## Why ESBuild?
- **10-100x faster** than Webpack/Rollup (written in Go)
- Used internally by Vite (dev server), Snowpack, and tsx
- Great for: bundling libraries, fast dev tools, simple apps

## CLI Usage
```bash
# Bundle
esbuild src/index.ts --bundle --outfile=dist/bundle.js --minify --sourcemap

# Watch mode
esbuild src/index.ts --bundle --outdir=dist --watch

# Multiple entry points
esbuild src/index.ts src/worker.ts --bundle --outdir=dist --splitting --format=esm
```

## JavaScript API
```js
const esbuild = require('esbuild');

// Build
await esbuild.build({
  entryPoints: ['src/index.ts'],
  bundle: true,
  outdir: 'dist',
  minify: true,
  sourcemap: true,
  target: ['es2020'],
  format: 'esm',
  splitting: true,
  platform: 'browser',         // or 'node'
  external: ['react', 'react-dom'],  // don't bundle these
  define: {
    'process.env.NODE_ENV': '"production"',
  },
  loader: {
    '.png': 'file',
    '.svg': 'text',
    '.css': 'css',
  },
});

// Dev server with watch
const ctx = await esbuild.context({
  entryPoints: ['src/index.ts'],
  bundle: true,
  outdir: 'dist',
  sourcemap: true,
});
await ctx.watch();
await ctx.serve({ port: 3000, servedir: 'dist' });
```

## Custom Plugin
```js
const myPlugin = {
  name: 'my-plugin',
  setup(build) {
    // Resolve custom imports
    build.onResolve({ filter: /^env$/ }, () => ({
      path: 'env', namespace: 'env-ns',
    }));

    // Load custom content
    build.onLoad({ filter: /.*/, namespace: 'env-ns' }, () => ({
      contents: `export const NODE_ENV = "${process.env.NODE_ENV}"`,
      loader: 'js',
    }));
  },
};

esbuild.build({ plugins: [myPlugin], /* ... */ });
```

## When to Use What
| Tool | Best For |
|------|----------|
| **ESBuild** | Library bundling, fast transpilation, simple apps |
| **Vite** | Full web apps (uses ESBuild for dev, Rollup for prod) |
| **Webpack** | Complex apps needing extensive plugin ecosystem |
| **Rollup** | Library packages, tree shaking critical |

## Limitations
- No TypeScript type checking (only strips types — use `tsc --noEmit` separately)
- Limited CSS modules support
- No HMR built-in (use with Vite for that)
- Plugin ecosystem smaller than Webpack
