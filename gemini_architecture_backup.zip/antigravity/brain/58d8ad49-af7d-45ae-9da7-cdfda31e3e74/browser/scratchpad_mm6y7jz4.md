# Hero Banner Analysis Task

- [x] Capture desktop hero banner screenshot
- [x] Capture mobile hero banner screenshot (Slide 1)
- [x] Capture mobile hero banner screenshot (Slide 2)
- [x] Capture mobile hero banner screenshot (Slide 3)
- [x] Analyze text overlap with faces/products
- [x] Report findings

## Observations
- **Desktop:** The text is positioned center-left. In the "New Offer" slide, the text overlaps the model's neck and shoulder. While her face is mostly clear, the composition feels crowded.
- **Mobile Slide 1 (Woman):** Text is centered and overlaps the model's face and chest.
- **Mobile Slide 2 (Couple):** Text is centered and overlaps both the male and female models' heads/faces.
- **Mobile Slide 3 (Kids):** Text is centered and overlaps the children's faces.

## Key Issues
1. **Centering on Mobile:** Centering text on mobile is the default, but since the subjects are also centered in the images, they collide.
2. **Readability:** White text on light parts of images (like the kids' clothes or the models' skin) becomes hard to read without a stronger overlay.
3. **Subject Obscurity:** The "faces" of the brand are being hidden by the promotional text.
